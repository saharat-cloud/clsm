-- Add last_active_at column to teachers and students
ALTER TABLE teachers ADD COLUMN IF NOT EXISTS last_active_at TIMESTAMPTZ;
ALTER TABLE students ADD COLUMN IF NOT EXISTS last_active_at TIMESTAMPTZ;
