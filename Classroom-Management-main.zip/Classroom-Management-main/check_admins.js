
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL, process.env.VITE_SUPABASE_ANON_KEY);

async function checkAdmins() {
    const { data, error } = await supabase.from('teachers').select('*').eq('role', 'admin');
    console.log('Admins:', data);
    if (error) console.error(error);
}

checkAdmins();
