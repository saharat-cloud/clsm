import { createClient } from '@supabase/supabase-js';

// Retrieve credentials safely or paste them temporarily for debugging
import { env } from 'process';

const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://totrmuxevrcovrtvyype.supabase.co';
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;
// Since we don't have the env vars, let's use the local base44Client
// Wait, Node.js cannot import Vite files easily due to JSX/aliases.
// We can just read the `.env` file instead.
