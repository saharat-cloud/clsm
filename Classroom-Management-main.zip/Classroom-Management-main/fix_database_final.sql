-- ก๊อปปี้โค้ดทั้งหมดนี้ไปรันใน SQL Editor ของ Supabase เพื่อแก้ปัญหา Error และเพิ่มระบบ Login ด้วยชื่อผู้ใช้ครับ
-- สคริปต์นี้จะลบตารางเดิมและสร้างใหม่เพื่อรองรับการแยกข้อมูลของครูแต่ละคน

-- 1. จัดการตาราง public.teachers (รองรับ Username/Password และ Role)
DROP TABLE IF EXISTS public.teachers CASCADE;
CREATE TABLE public.teachers (
    id TEXT PRIMARY KEY, 
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    first_name TEXT DEFAULT 'คุณครู',
    last_name TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    profile_frame TEXT DEFAULT '',
    title TEXT DEFAULT 'ครูประจำวิชา',
    name_bg_color TEXT DEFAULT '',
    role TEXT DEFAULT 'teacher', -- 'admin' หรือ 'teacher'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- เพิ่มข้อมูลบัญชี Admin พื้นฐาน (คุณ kanit)
INSERT INTO public.teachers (id, username, password, first_name, last_name, role)
VALUES ('kanit_admin', 'kanit', 'kanitkanit3939', 'KANIT', 'MANKONG', 'admin')
ON CONFLICT (id) DO NOTHING;

-- 2. เพิ่มคอลัมน์ teacher_id ในตารางอื่นๆ เพื่อแยกข้อมูลของแต่ละบัญชี
-- ตารางห้องเรียน (Classrooms)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='classrooms' AND column_name='teacher_id') THEN
        ALTER TABLE classrooms ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางรายวิชา (Subjects)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='subjects' AND column_name='teacher_id') THEN
        ALTER TABLE subjects ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางงานมอบหมาย (Assignments)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='assignments' AND column_name='teacher_id') THEN
        ALTER TABLE assignments ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางเนื้อหาบทเรียน (Materials)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='materials' AND column_name='teacher_id') THEN
        ALTER TABLE materials ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางรางวัล (Rewards)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='teacher_id') THEN
        ALTER TABLE rewards ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางปีการศึกษา (Semesters)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='semesters' AND column_name='teacher_id') THEN
        ALTER TABLE semesters ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางคะแนน (Score Records)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='score_records' AND column_name='teacher_id') THEN
        ALTER TABLE score_records ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางประวัติแต้ม (Point Transactions)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='point_transactions' AND column_name='teacher_id') THEN
        ALTER TABLE point_transactions ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางการแจ้งเตือน (Notifications)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notifications' AND column_name='teacher_id') THEN
        ALTER TABLE notifications ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางการแลกรางวัล (Reward Claims)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='reward_claims' AND column_name='teacher_id') THEN
        ALTER TABLE reward_claims ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางนักเรียน (Students - สำหรับดึงรายชื่อแยกตามครู)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='students' AND column_name='teacher_id') THEN
        ALTER TABLE students ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางระบบไวรัส (Infections & Item Requests)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='infections' AND column_name='teacher_id') THEN
        ALTER TABLE infections ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='item_requests' AND column_name='teacher_id') THEN
        ALTER TABLE item_requests ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางไอเทมนักเรียน (Student Items)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='student_items' AND column_name='teacher_id') THEN
        ALTER TABLE student_items ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- ตารางการส่งงาน (Submissions)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='submissions' AND column_name='teacher_id') THEN
        ALTER TABLE submissions ADD COLUMN teacher_id TEXT DEFAULT 'kanit_admin';
    END IF;
END $$;

-- 3. จัดการตาราง rewards (เพิ่มคอลัมน์ที่ขาดหายไป)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='reward_type') THEN
        ALTER TABLE rewards ADD COLUMN reward_type TEXT DEFAULT 'item';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='score_amount') THEN
        ALTER TABLE rewards ADD COLUMN score_amount INTEGER DEFAULT 0;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='customization_type') THEN
        ALTER TABLE rewards ADD COLUMN customization_type TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='customization_value') THEN
        ALTER TABLE rewards ADD COLUMN customization_value TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='rarity') THEN
        ALTER TABLE rewards ADD COLUMN rarity TEXT DEFAULT 'common';    
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='sale_end_date') THEN
        ALTER TABLE rewards ADD COLUMN sale_end_date TIMESTAMP WITH TIME ZONE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='status') THEN
        ALTER TABLE rewards ADD COLUMN status TEXT DEFAULT 'active';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rewards' AND column_name='exp_required') THEN
        ALTER TABLE rewards ADD COLUMN exp_required INTEGER DEFAULT 0;
    END IF;
END $$;

-- 4. ตั้งค่าความปลอดภัย (RLS) สำหรับทุกตารางที่เกี่ยวกับครู
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public access to teachers" ON public.teachers;
CREATE POLICY "Allow public access to teachers" ON public.teachers FOR ALL USING (true) WITH CHECK (true);

-- 5. ตระเตรียมตารางอื่นๆ (เผื่อขาด)
DO $$ BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='reward_claims' AND column_name='note') THEN
        ALTER TABLE reward_claims ADD COLUMN note TEXT;
    END IF;
END $$;

-- รีเฟรช Schema Cache
NOTIFY pgrst, 'reload schema';
