-- ก๊อปปี้โค้ดทั้งหมดนี้ไปรันใน SQL Editor ของ Supabase อีกครั้งครับ
-- สคริปต์นี้จะตรวจสอบและเพิ่มคอลัมน์ที่ขาดหายไปทั้งหมดให้โดยอัตโนมัติ

-- 1. จัดการตาราง infections
DO $$ 
BEGIN 
    -- ตรวจสอบ created_at
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='infections' AND column_name='created_at') THEN
        ALTER TABLE infections ADD COLUMN created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now());
    END IF;
    -- ตรวจสอบ classroom_id
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='infections' AND column_name='classroom_id') THEN
        ALTER TABLE infections ADD COLUMN classroom_id UUID;
    END IF;
END $$;

-- 2. จัดการตาราง item_requests
DO $$ 
BEGIN 
    -- ตรวจสอบ created_at
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='item_requests' AND column_name='created_at') THEN
        ALTER TABLE item_requests ADD COLUMN created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now());
    END IF;
    -- ตรวจสอบ classroom_id
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='item_requests' AND column_name='classroom_id') THEN
        ALTER TABLE item_requests ADD COLUMN classroom_id UUID;
    END IF;
    -- ตรวจสอบ requester_id (ถ้ามี student_id ให้เปลี่ยนชื่อ หรือถ้าไม่มีทั้งคู่ให้สร้างใหม่)
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='item_requests' AND column_name='student_id') 
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='item_requests' AND column_name='requester_id') THEN
        ALTER TABLE item_requests RENAME COLUMN student_id TO requester_id;
    ELSIF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='item_requests' AND column_name='requester_id') THEN
        ALTER TABLE item_requests ADD COLUMN requester_id TEXT;
    END IF;
    -- ตรวจสอบ target_student_id
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='item_requests' AND column_name='target_student_id') THEN
        ALTER TABLE item_requests ADD COLUMN target_student_id TEXT;
    END IF;
END $$;

-- 3. จัดการตาราง student_items
DO $$ 
BEGIN 
    -- ตรวจสอบ created_at
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='student_items' AND column_name='created_at') THEN
        ALTER TABLE student_items ADD COLUMN created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now());
    END IF;
END $$;

-- เปิด RLS และนโยบายพื้นฐาน
ALTER TABLE infections ENABLE ROW LEVEL SECURITY;
ALTER TABLE item_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE student_items ENABLE ROW LEVEL SECURITY;

-- ลบและสร้าง Policy ใหม่เพื่อให้แน่ใจว่าเข้าถึงได้
DROP POLICY IF EXISTS "Allow all infections" ON infections;
CREATE POLICY "Allow all infections" ON infections FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all item_requests" ON item_requests;
CREATE POLICY "Allow all item_requests" ON item_requests FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all student_items" ON student_items;
CREATE POLICY "Allow all student_items" ON student_items FOR ALL USING (true) WITH CHECK (true);
