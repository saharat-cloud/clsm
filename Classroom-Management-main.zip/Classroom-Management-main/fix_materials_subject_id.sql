-- สคริปต์สำหรับเพิ่มคอลัมน์ subject_id ในตาราง materials
-- ก๊อปปี้ไปวางใน SQL Editor ของ Supabase แล้วรันได้เลยครับ

DO $$ 
BEGIN 
    -- ตรวจสอบว่าคอลัมน์ subject_id มีอยู่แล้วหรือไม่
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='materials' AND column_name='subject_id') THEN
        ALTER TABLE materials ADD COLUMN subject_id UUID REFERENCES subjects(id) ON DELETE SET NULL;
    END IF;
END $$;

-- อัปเดตนโยบายความปลอดภัย (Policy) เพื่อให้แน่ใจว่าเข้าถึงได้
-- (ปกติตาราง materials มักจะมี policy แบบกว้างอยู่แล้วถ้ารันสคริปต์ก่อนหน้า)
DROP POLICY IF EXISTS "Allow all materials" ON materials;
CREATE POLICY "Allow all materials" ON materials FOR ALL USING (true) WITH CHECK (true);
