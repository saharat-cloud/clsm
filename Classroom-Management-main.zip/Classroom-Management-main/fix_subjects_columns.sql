-- Fix: Add missing columns to subjects table
-- Run this in Supabase SQL Editor

-- Add grading_criteria column (for grade weights and cut-offs)
ALTER TABLE public.subjects
    ADD COLUMN IF NOT EXISTS grading_criteria JSONB;

-- Add semester columns if not already added by semester_management.sql
ALTER TABLE public.subjects
    ADD COLUMN IF NOT EXISTS semester_academic_year TEXT,
    ADD COLUMN IF NOT EXISTS semester_number INTEGER;

-- Add is_archived if not exists
ALTER TABLE public.subjects
    ADD COLUMN IF NOT EXISTS is_archived BOOLEAN DEFAULT false;
