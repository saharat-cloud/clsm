-- ============================================================
-- Semester Management System - SQL Migration Script
-- Run in Supabase SQL Editor
-- ============================================================

-- 1. Create the semesters table
CREATE TABLE IF NOT EXISTS public.semesters (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    academic_year TEXT NOT NULL,           -- e.g. '2567'
    semester INTEGER NOT NULL CHECK (semester IN (1, 2)),
    label TEXT,                            -- e.g. 'ปีการศึกษา 2567 เทอม 1'
    is_active BOOLEAN DEFAULT false,       -- current active semester
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (academic_year, semester)
);

ALTER TABLE public.semesters ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public access to semesters" ON public.semesters;
CREATE POLICY "Allow public access to semesters" ON public.semesters FOR ALL USING (true);

-- 2. Add academic_year + semester columns to classrooms
ALTER TABLE public.classrooms
    ADD COLUMN IF NOT EXISTS semester_academic_year TEXT,
    ADD COLUMN IF NOT EXISTS semester_number INTEGER,
    ADD COLUMN IF NOT EXISTS level TEXT,           -- e.g. 'ปวช.1', 'ปวส.2 สมทบ'
    ADD COLUMN IF NOT EXISTS room_number INTEGER;  -- 1-20

-- 3. Add academic_year + semester to students
ALTER TABLE public.students
    ADD COLUMN IF NOT EXISTS semester_academic_year TEXT,
    ADD COLUMN IF NOT EXISTS semester_number INTEGER;

-- 4. Add academic_year + semester to subjects
ALTER TABLE public.subjects
    ADD COLUMN IF NOT EXISTS semester_academic_year TEXT,
    ADD COLUMN IF NOT EXISTS semester_number INTEGER;

-- 5. Create a default semester for existing data (2566/1)
INSERT INTO public.semesters (academic_year, semester, label, is_active)
VALUES ('2566', 1, 'ปีการศึกษา 2566 เทอม 1', false)
ON CONFLICT (academic_year, semester) DO NOTHING;

-- 6. Backfill existing classrooms/students/subjects with a default semester
UPDATE public.classrooms
SET semester_academic_year = '2566', semester_number = 1
WHERE semester_academic_year IS NULL;

UPDATE public.students
SET semester_academic_year = '2566', semester_number = 1
WHERE semester_academic_year IS NULL;

UPDATE public.subjects
SET semester_academic_year = '2566', semester_number = 1
WHERE semester_academic_year IS NULL;

-- Done! Apply this in Supabase SQL Editor before deploying.
