-- ให้ครูก็อปปี้โค้ดนี้ไปรันใน SQL Editor ของ Supabase ครับ

-- 1. Table สำหรับเนื้อหาบทเรียน (Materials)
CREATE TABLE IF NOT EXISTS materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    title TEXT NOT NULL,
    content TEXT,
    attachment_urls TEXT[] DEFAULT '{}',
    classroom_ids UUID[] DEFAULT '{}',
    teacher_id TEXT
);

-- 2. Table สำหรับระบบไวรัส (Infections)
CREATE TABLE IF NOT EXISTS infections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    student_id TEXT NOT NULL,
    classroom_id UUID NOT NULL,
    assignment_id UUID NOT NULL,
    spread_count INTEGER DEFAULT 1,
    penalty_type TEXT DEFAULT 'points', -- 'points' or 'score'
    penalty_amount INTEGER DEFAULT 10,
    reward_type TEXT DEFAULT 'points',
    reward_amount INTEGER DEFAULT 5,
    is_active BOOLEAN DEFAULT true,
    cured_at TIMESTAMP WITH TIME ZONE,
    source_infection_id UUID -- สำหรับกรณีระเบิดเชื้อต่อ
);

-- 3. Table สำหรับไอเทมของนักเรียน (Student Items)
CREATE TABLE IF NOT EXISTS student_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    student_id TEXT NOT NULL,
    item_type TEXT NOT NULL, -- e.g. 'antivirus'
    quantity INTEGER DEFAULT 0
);

-- 4. Table สำหรับคำขอยา (Item Requests)
CREATE TABLE IF NOT EXISTS item_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
    student_id TEXT NOT NULL,
    classroom_id UUID NOT NULL,
    item_type TEXT DEFAULT 'antivirus',
    status TEXT DEFAULT 'pending', -- 'pending', 'fulfilled'
    helper_id TEXT
);

-- เปิด RLS (หากต้องการความปลอดภัยสูงขึ้น)
ALTER TABLE materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE infections ENABLE ROW LEVEL SECURITY;
ALTER TABLE student_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE item_requests ENABLE ROW LEVEL SECURITY;

-- นโยบายการเข้าถึงข้อมูลแบบง่าย (Allow all for development)
CREATE POLICY "Allow all materials" ON materials FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all infections" ON infections FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all student_items" ON student_items FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all item_requests" ON item_requests FOR ALL USING (true) WITH CHECK (true);
