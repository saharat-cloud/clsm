import { useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import SettingsBar from '@/components/SettingBar';
import { initTheme } from '@/lib/theme';
import { playClick } from '@/lib/sound';

import TeacherLogin from './pages/TeacherLogin';
import TeacherDashboard from './pages/TeacherDashboard';
import StudentLogin from './pages/StudentLogin';
import StudentDashboard from './pages/StudentDashboard';
import Subjects from './pages/teacher/Subjects';
import Students from './pages/teacher/Students';
import Classrooms from './pages/teacher/Classrooms';
import ClassroomDetail from './pages/teacher/ClassroomDetail';
import Assignments from './pages/teacher/Assignments';
import AssignmentForm from './pages/teacher/AssignmentForm';
import AssignmentDetail from './pages/teacher/AssignmentDetail';
import AssignmentTracker from './pages/teacher/AssignmentTracker';
import Scores from './pages/teacher/Scores';
import Points from './pages/teacher/Points';
import Ranking from './pages/teacher/Ranking';
import StudentStatus from './pages/teacher/StudentStatus';
import TeacherNotifications from './pages/teacher/TeacherNotifications';
import StudentAssignments from './pages/student/StudentAssignments';
import StudentScores from './pages/student/StudentScores';
import StudentPoints from './pages/student/StudentPoints';
import StudentRanking from './pages/student/StudentRanking';
import StudentNotifications from './pages/student/StudentNotifications';
import StudentProfile from './pages/student/StudentProfile';
import TeacherProfile from './pages/teacher/TeacherProfile';
import SemesterManager from './pages/teacher/SemesterManager';
import ManageAccounts from './pages/teacher/ManageAccounts';

import TeacherMaterials from './pages/teacher/TeacherMaterials';
import VirusDashboard from './pages/teacher/VirusDashboard';
import StudentMaterials from './pages/student/StudentMaterials';
import StudentInventory from './pages/student/StudentInventory';
import ItemRequests from './pages/student/ItemRequests';

import TeacherLayout from './components/layout/TeacherLayout';
import StudentLayout from './components/layout/StudentLayout';

// Init theme and global click sound
initTheme();

const AuthenticatedApp = () => {
    const { isLoadingAuth, isLoadingPublicSettings, authError } = useAuth();
    const location = useLocation();
    
    // Check if the current route is for teachers (not students)
    const isTeacherRoute = location.pathname === '/' || location.pathname.startsWith('/teacher');
    const isTeacherLogin = location.pathname === '/teacher/login';

    if (isLoadingPublicSettings || isLoadingAuth) {
        return (
            <div className="fixed inset-0 flex items-center justify-center bg-background">
                <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin"></div>
            </div>
        );
    }

    if (authError && isTeacherRoute && !isTeacherLogin) {
        if (authError.type === 'user_not_registered') {
            return <UserNotRegisteredError />;
        } else if (authError.type === 'auth_required') {
            if (location.pathname === '/') {
                return <Navigate to="/student/login" replace />;
            }
            return <Navigate to="/teacher/login" replace />;
        }
    }

    if (!authError && isTeacherLogin) {
        return <Navigate to="/" replace />;
    }

    return (
        <Routes>
            <Route path="/teacher/login" element={<TeacherLogin />} />
            <Route path="/student/login" element={<StudentLogin />} />
            
            <Route path="/" element={<TeacherLayout><TeacherDashboard /></TeacherLayout>} />
            <Route path="/teacher" element={<TeacherLayout><TeacherDashboard /></TeacherLayout>} />
            <Route path="/teacher/subjects" element={<TeacherLayout><Subjects /></TeacherLayout>} />
            <Route path="/teacher/students" element={<TeacherLayout><Students /></TeacherLayout>} />
            <Route path="/teacher/classrooms" element={<TeacherLayout><Classrooms /></TeacherLayout>} />
            <Route path="/teacher/classrooms/:id" element={<TeacherLayout><ClassroomDetail /></TeacherLayout>} />
            <Route path="/teacher/assignments" element={<TeacherLayout><Assignments /></TeacherLayout>} />
            <Route path="/teacher/assignments/new" element={<TeacherLayout><AssignmentForm /></TeacherLayout>} />
            <Route path="/teacher/assignments/:id" element={<TeacherLayout><AssignmentDetail /></TeacherLayout>} />
            <Route path="/teacher/assignments/:id/edit" element={<TeacherLayout><AssignmentForm /></TeacherLayout>} />
            <Route path="/teacher/assignment-tracker" element={<TeacherLayout><AssignmentTracker /></TeacherLayout>} />
            <Route path="/teacher/scores" element={<TeacherLayout><Scores /></TeacherLayout>} />
            <Route path="/teacher/points" element={<TeacherLayout><Points /></TeacherLayout>} />
            <Route path="/teacher/ranking" element={<TeacherLayout><Ranking /></TeacherLayout>} />
            <Route path="/teacher/student-status" element={<TeacherLayout><StudentStatus /></TeacherLayout>} />
            <Route path="/teacher/profile" element={<TeacherLayout><TeacherProfile /></TeacherLayout>} />
            <Route path="/teacher/notifications" element={<TeacherLayout><TeacherNotifications /></TeacherLayout>} />
            <Route path="/teacher/semesters" element={<TeacherLayout><SemesterManager /></TeacherLayout>} />
            <Route path="/teacher/materials" element={<TeacherLayout><TeacherMaterials /></TeacherLayout>} />
            <Route path="/teacher/virus" element={<TeacherLayout><VirusDashboard /></TeacherLayout>} />
            <Route path="/teacher/manage-accounts" element={<TeacherLayout><ManageAccounts /></TeacherLayout>} />
            
            {/* Admin Routes */}
            <Route path="/teacher/admin/classrooms" element={<TeacherLayout><Classrooms adminMode={true} /></TeacherLayout>} />
            <Route path="/teacher/admin/students" element={<TeacherLayout><Students adminMode={true} /></TeacherLayout>} />
            <Route path="/teacher/admin/subjects" element={<TeacherLayout><Subjects adminMode={true} /></TeacherLayout>} />
            <Route path="/teacher/admin/semesters" element={<TeacherLayout><SemesterManager /></TeacherLayout>} />
            
            <Route path="/student" element={<StudentLayout><StudentPoints /></StudentLayout>} />
            <Route path="/student/dashboard" element={<StudentLayout><StudentDashboard /></StudentLayout>} />
            <Route path="/student/assignments" element={<StudentLayout><StudentAssignments /></StudentLayout>} />
            <Route path="/student/scores" element={<StudentLayout><StudentScores /></StudentLayout>} />
            <Route path="/student/points" element={<StudentLayout><StudentPoints /></StudentLayout>} />
            <Route path="/student/ranking" element={<StudentLayout><StudentRanking /></StudentLayout>} />
            <Route path="/student/notifications" element={<StudentLayout><StudentNotifications /></StudentLayout>} />
            <Route path="/student/materials" element={<StudentLayout><StudentMaterials /></StudentLayout>} />
            <Route path="/student/inventory" element={<StudentLayout><StudentInventory /></StudentLayout>} />
            <Route path="/student/item-requests" element={<StudentLayout><ItemRequests /></StudentLayout>} />
            <Route path="/student/profile" element={<StudentLayout><StudentProfile /></StudentLayout>} />
            
            <Route path="*" element={<PageNotFound />} />
        </Routes>
    );
};

// Global click sound listener
if (typeof window !== 'undefined') {
    document.addEventListener('click', (e) => {
        const el = e.target.closest('button, a, [role="button"]');
        if (el) playClick();
    }, { capture: true });
}

function App() {
    return (
        <AuthProvider>
            <QueryClientProvider client={queryClientInstance}>
                <Router>
                    <AuthenticatedApp />
                </Router>
                <Toaster />
                <SettingsBar />
            </QueryClientProvider>
        </AuthProvider>
    );
}

export default App;