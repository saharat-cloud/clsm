import { entities } from './entities';

/**
 * Drop-in replacement for base44 SDK.
 * All pages using base44.entities.X.list/create/update/delete/filter()
 * will work without modification.
 */
export const base44 = {
    entities,
    auth: {
        me: async () => ({ id: 'teacher', email: 'teacher@classroom.local', full_name: 'Teacher' }),
        logout: () => {},
        redirectToLogin: () => {},
    },
};
