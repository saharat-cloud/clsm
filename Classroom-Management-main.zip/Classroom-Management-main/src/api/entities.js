/**
 * Data Access Layer — Supabase
 *
 * Mirrors the base44 SDK pattern:
 *   base44.entities.Student.list()
 *   base44.entities.Student.create({ ... })
 *   base44.entities.Student.update(id, { ... })
 *   base44.entities.Student.delete(id)
 *   base44.entities.Student.get(id)
 *   base44.entities.Student.filter({ key: { operator: value } })
 *
 * All existing page files continue to work unchanged.
 */
import { supabase } from './supabaseClient';

/**
 * Creates a CRUD entity helper for a given Supabase table.
 * @param {string} tableName - The Supabase table name (snake_case)
 */
function createEntity(tableName) {
    return {
        /**
         * List all records, optionally sorted.
         * @param {string} [orderBy] - e.g. '-created_at' (prefix '-' for desc)
         */
        async list(orderBy) {
            let query = supabase.from(tableName).select('*');

            if (orderBy) {
                const desc = orderBy.startsWith('-');
                const column = desc ? orderBy.slice(1) : orderBy;
                // Map base44 field names to Supabase column names
                const col = mapField(tableName, column);
                query = query.order(col, { ascending: !desc });
            } else {
                query = query.order('created_at', { ascending: false });
            }

            const { data, error } = await query;
            if (error) throw error;
            return data || [];
        },

        /**
         * Get a single record by id.
         */
        async get(id) {
            const { data, error } = await supabase
                .from(tableName)
                .select('*')
                .eq('id', id)
                .single();
            if (error) throw error;
            return data;
        },

        /**
         * Create a new record.
         */
        async create(payload) {
            const { data, error } = await supabase
                .from(tableName)
                .insert([payload])
                .select()
                .single();
            if (error) throw error;
            return data;
        },

        /**
         * Upsert a single record.
         */
        async upsert(payload, onConflict = 'id') {
            const { data, error } = await supabase
                .from(tableName)
                .upsert(payload, { onConflict })
                .select()
                .single();
            if (error) throw error;
            return data;
        },

        /**
         * Update an existing record by id.
         */
        async update(id, payload) {
            const { data, error } = await supabase
                .from(tableName)
                .update(payload)
                .eq('id', id)
                .select()
                .single();
            if (error) throw error;
            return data;
        },

        /**
         * Delete a record by id.
         */
        async delete(id) {
            const { error } = await supabase
                .from(tableName)
                .delete()
                .eq('id', id);
            if (error) throw error;
            return { success: true };
        },

        /**
         * Create multiple records at once.
         */
        async bulkCreate(records) {
            const { data, error } = await supabase
                .from(tableName)
                .insert(records)
                .select();
            if (error) throw error;
            return data;
        },

        /**
         * Upsert multiple records at once to handle conflicts.
         */
        async bulkUpsert(records, onConflict = 'id') {
            const { data, error } = await supabase
                .from(tableName)
                .upsert(records, { onConflict })
                .select();
            if (error) throw error;
            return data;
        },

        /**
         * Filter records by conditions.
         * Supports base44-style filter objects:
         *   { classroom_id: { equals: 'abc' } }
         *   { student_id: { in: ['a', 'b'] } }
         *   { is_read: { equals: false } }
         */
        async filter(filters = {}) {
            let query = supabase.from(tableName).select('*');

            for (const [field, condition] of Object.entries(filters)) {
                if (condition === null || condition === undefined) continue;

                if (typeof condition === 'object' && !Array.isArray(condition)) {
                    const { equals, not_equals, in: inList, contains, gte, lte, gt, lt, is: isVal } = condition;

                    if (equals !== undefined) query = query.eq(field, equals);
                    if (not_equals !== undefined) query = query.neq(field, not_equals);
                    if (inList !== undefined) query = query.in(field, inList);
                    if (contains !== undefined) query = query.contains(field, contains);
                    if (gte !== undefined) query = query.gte(field, gte);
                    if (lte !== undefined) query = query.lte(field, lte);
                    if (gt !== undefined) query = query.gt(field, gt);
                    if (lt !== undefined) query = query.lt(field, lt);
                    if (isVal !== undefined) query = query.is(field, isVal);
                } else {
                    // Simple equality shorthand: { field: value }
                    query = query.eq(field, condition);
                }
            }

            query = query.order('created_at', { ascending: false });
            const { data, error } = await query;
            if (error) throw error;
            return data || [];
        },
    };
}

/**
 * Maps base44 field names to Supabase column names when needed.
 * base44 uses 'created_date', Supabase uses 'created_at'
 */
function mapField(tableName, field) {
    const mapping = {
        'created_date': 'created_at',
        'updated_date': 'updated_at',
    };
    return mapping[field] || field;
}

// ── Entity Definitions ───────────────────────────────────────────────────────

export const Teacher = createEntity('teachers');
export const Student = createEntity('students');
export const Classroom = createEntity('classrooms');
export const Subject = createEntity('subjects');
export const Assignment = createEntity('assignments');
export const Submission = createEntity('submissions');
export const ScoreRecord = createEntity('score_records');
export const PointTransaction = createEntity('point_transactions');
export const Notification = createEntity('notifications');
export const Reward = createEntity('rewards');
export const RewardClaim = createEntity('reward_claims');
export const Semester = createEntity('semesters');
export const Material = createEntity('materials');
export const Infection = createEntity('infections');
export const StudentItem = createEntity('student_items');
export const ItemRequest = createEntity('item_requests');

// ── Combined export (matches base44.entities shape) ─────────────────────────

export const entities = {
    Teacher,
    Student,
    Classroom,
    Subject,
    Assignment,
    Submission,
    ScoreRecord,
    PointTransaction,
    Notification,
    Reward,
    RewardClaim,
    Semester,
    Material,
    Infection,
    StudentItem,
    ItemRequest,
};

