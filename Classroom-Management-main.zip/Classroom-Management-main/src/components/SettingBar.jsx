import { useState, useEffect } from 'react';
import { Moon, Sun, Volume2, VolumeX } from 'lucide-react';
import { toggleTheme, isDarkMode } from '@/lib/theme';
import { isSoundEnabled, setSoundEnabled, playClick } from '@/lib/sound';

export default function SettingsBar() {
    const [dark, setDark] = useState(false);
    const [sound, setSound] = useState(true);

    useEffect(() => {
        setDark(isDarkMode());
        setSound(isSoundEnabled());
    }, []);

    function handleTheme() {
        playClick();
        const d = toggleTheme();
        setDark(d);
    }

    function handleSound() {
        const newVal = !sound;
        setSoundEnabled(newVal);
        setSound(newVal);
        if (newVal) playClick();
    }

    return (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2">
            <button
                onClick={handleTheme}
                title={dark ? 'โหมดสว่าง' : 'โหมดมืด'}
                className="w-10 h-10 rounded-full bg-card border border-border shadow-lg flex items-center justify-center hover:bg-muted transition-all hover:scale-110"
            >
                {dark ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-slate-600" />}
            </button>
            <button
                onClick={handleSound}
                title={sound ? 'ปิดเสียง' : 'เปิดเสียง'}
                className="w-10 h-10 rounded-full bg-card border border-border shadow-lg flex items-center justify-center hover:bg-muted transition-all hover:scale-110"
            >
                {sound ? <Volume2 size={18} className="text-primary" /> : <VolumeX size={18} className="text-muted-foreground" />}
            </button>
        </div>
    );
}