import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { BarChart3, Trophy, ClipboardList, LogOut, Bell, Menu, LayoutDashboard, FileText, Package, HandHeart, ShoppingBag } from 'lucide-react';
import RealtimeNotificationToast from '@/components/ui/RealtimeNotificationToast';
import ZombieTheme from '@/components/ui/ZombieTheme';
import { calculateLevel, calculateProgress } from '@/lib/levelUtils';
import StudentAvatar from '@/components/ui/StudentAvatar';

export default function StudentLayout({ children }) {
    const location = useLocation();
    const navigate = useNavigate();
    const [isMobileOpen, setIsMobileOpen] = useState(false);
    const [student, setStudent] = useState(null);
    const [pendingCount, setPendingCount] = useState(0);

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) { navigate('/student/login'); return; }
        const std = JSON.parse(session);

        async function load() {
            try {
                // Core data for students and classrooms is now managed by the admin
                const freshStudent = await base44.entities.Student.filter({ 
                    student_id: std.student_id,
                    teacher_id: 'kanit_admin' 
                });
                const s = freshStudent[0] || std;
                setStudent(s);
                localStorage.setItem('student_session', JSON.stringify(s));

                const rooms = await base44.entities.Classroom.filter({ teacher_id: 'kanit_admin' });
                const myCls = rooms.filter(c => (c.student_ids || []).includes(s.id));
                const myClsIds = myCls.map(c => c.id);

                if (myClsIds.length > 0) {
                    const [asgns, subs] = await Promise.all([
                        base44.entities.Assignment.filter({ classroom_id: { in: myClsIds } }),
                        base44.entities.Submission.filter({ student_id: s.student_id }),
                    ]);
                    
                    const submittedIds = new Set(subs.map(sub => sub.assignment_id));
                    const pending = asgns.filter(a => !submittedIds.has(a.id) && new Date(a.due_date) > new Date());
                    setPendingCount(pending.length);
                } else {
                    setPendingCount(0);
                }
            } catch (err) {
                console.error(err);
            }
        }
        load();

        // Real-time listener for student data changes
        const channel = supabase.channel(`student-data-${std.student_id}`)
            .on('postgres_changes', { 
                event: 'UPDATE', 
                schema: 'public', 
                table: 'students', 
                filter: `student_id=eq.${std.student_id}` 
            }, (payload) => {
                setStudent(payload.new);
                localStorage.setItem('student_session', JSON.stringify(payload.new));
            })
            .subscribe();

        // Online Status Heartbeat
        async function updatePresence() {
            if (std?.id) {
                try {
                    await base44.entities.Student.update(std.id, { last_active_at: new Date().toISOString() });
                } catch (e) { console.error('Student presence error:', e); }
            }
        }
        updatePresence();
        const interval = setInterval(updatePresence, 5 * 60 * 1000);

        return () => { 
            supabase.removeChannel(channel); 
            clearInterval(interval);
        };
    }, [location.pathname]);

    const menuItems = [
        { to: '/student/dashboard', icon: LayoutDashboard, label: 'หน้าแรก' },
        { to: '/student/materials', icon: FileText, label: 'บทเรียน' },
        { to: '/student/assignments', icon: ClipboardList, label: 'งานของฉัน', badge: pendingCount },
        { to: '/student/scores', icon: BarChart3, label: 'คะแนนเก็บ' },
        { to: '/student/points', icon: ShoppingBag, label: 'ร้านค้า' },
        { to: '/student/inventory', icon: Package, label: 'กระเป๋าไอเทม' },
        { to: '/student/item-requests', icon: HandHeart, label: 'คำขอยา(เพื่อน)' },
        { to: '/student/ranking', icon: Trophy, label: 'แรงค์กิ้ง' },
        { to: '/student/notifications', icon: Bell, label: 'การแจ้งเตือน' },
    ];

    const isActive = (item) => {
        if (item.exact) return location.pathname === item.to;
        return location.pathname.startsWith(item.to);
    };

    const handleLogout = () => {
        localStorage.removeItem('student_session');
        navigate('/student/login');
    };

    const SidebarContent = () => (
        <div className="flex flex-col h-full bg-card border-r border-border">
            <div className="p-6">
                <Link to="/student/profile" className="flex items-center gap-3 mb-6 p-2 rounded-2xl hover:bg-muted transition group">
                    <StudentAvatar student={student} size={48} showTitle={false} />
                    <div className="overflow-hidden flex-1">
                        <h2 className={`font-bold truncate student-name-${student?.student_id}`} title={`${student?.first_name} ${student?.last_name}`}>
                            {student?.first_name} {student?.last_name}
                        </h2>
                        <p className="text-[10px] text-muted-foreground font-mono flex items-center gap-1">
                            <span className="bg-blue-100 text-blue-600 px-1 rounded-sm text-[9px]">LV. {calculateLevel(student?.total_exp)}</span>
                            {student?.student_id}
                        </p>
                    </div>
                </Link>

                <div className="mb-6 px-1">
                    <div className="flex justify-between text-[10px] font-bold uppercase text-muted-foreground mb-1">
                        <span>EXP Progress</span>
                        <span>{calculateProgress(student?.total_exp).toFixed(0)}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full transition-all duration-1000" style={{ width: `${calculateProgress(student?.total_exp)}%` }} />
                    </div>
                </div>

                <div className="bg-muted rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-amber-600">
                        <Trophy size={18} />
                    </div>
                    <div>
                        <p className="text-xs text-muted-foreground">แต้มสะสม</p>
                        <p className="font-bold text-lg leading-tight">{student?.total_points || 0}</p>
                    </div>
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto px-4 py-2 space-y-1">
                <p className="px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 mt-4">เมนูหลัก</p>
                {menuItems.map((item) => (
                    <Link
                        key={item.to}
                        to={item.to}
                        onClick={() => setIsMobileOpen(false)}
                        className={`flex items-center justify-between px-3 py-2.5 rounded-xl transition-all ${
                            isActive(item) 
                                ? 'bg-primary/10 text-primary font-medium' 
                                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                        }`}
                    >
                        <div className="flex items-center gap-3">
                            <item.icon size={18} className={isActive(item) ? 'text-primary' : ''} />
                            <span className="text-sm">{item.label}</span>
                        </div>
                        {item.badge > 0 && (
                            <span className="bg-destructive text-destructive-foreground text-[10px] font-bold px-2 py-0.5 rounded-full">
                                {item.badge}
                            </span>
                        )}
                    </Link>
                ))}
            </div>

            <div className="p-4 mt-auto border-t border-border">
                <button
                    onClick={handleLogout}
                    className="flex w-full items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all font-medium"
                >
                    <LogOut size={18} />
                    ออกจากระบบ
                </button>
            </div>
        </div>
    );

    return (
        <>
        <RealtimeNotificationToast />
        <ZombieTheme />
        <div className="flex h-screen bg-background overflow-hidden">
            {/* Desktop Sidebar */}
            <div className="hidden md:block w-72 flex-shrink-0 h-full">
                <SidebarContent />
            </div>

            {/* Mobile Sidebar Overlay */}
            {isMobileOpen && (
                <div className="fixed inset-0 z-50 md:hidden">
                    <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsMobileOpen(false)} />
                    <div className="absolute inset-y-0 left-0 w-72 shadow-2xl animate-in slide-in-from-left">
                        <SidebarContent />
                    </div>
                </div>
            )}

            {/* Main Content */}
            <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
                {/* Mobile Header */}
                <div className="md:hidden flex items-center justify-between p-4 bg-card border-b border-border">
                    <Link to="/student/profile" className="flex items-center gap-2">
                        <StudentAvatar student={student} size={32} showTitle={false} />
                        <span className={`font-bold text-sm student-name-${student?.student_id}`}>{student?.total_points || 0} แต้ม</span>
                    </Link>
                    <button onClick={() => setIsMobileOpen(true)} className="p-2 text-muted-foreground">
                        <Menu size={20} />
                    </button>
                </div>

                {/* Page Content */}
                <main className="flex-1 overflow-y-auto">
                    {children}
                </main>
            </div>
        </div>
        </>
    );
}
