import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import {
    BookOpen, Users, ClipboardList, Trophy, BarChart3, LogOut, Layers, Bell,
    Table, Menu, LayoutDashboard, CalendarDays, ChevronDown, ChevronLeft, ChevronRight, X,
    FileText, Bug, User, Shield
} from 'lucide-react';
import { SemesterProvider, useSemester } from '@/lib/SemesterContext';
import TeacherRealtimeToast from '@/components/ui/TeacherRealtimeToast';
import StudentAvatar from '@/components/ui/StudentAvatar';

function SemesterBadge() {
    const { activeSemester, allSemesters, setActiveSemester, semesterLabel } = useSemester();
    const [open, setOpen] = useState(false);
    if (!activeSemester) return null;
    return (
        <div className="relative">
            <button onClick={() => setOpen(!open)}
                className="flex items-center gap-1.5 bg-primary/10 text-primary text-xs font-semibold px-2.5 py-1 rounded-full hover:bg-primary/20 transition">
                <CalendarDays size={11} />
                <span className="max-w-[120px] truncate">{semesterLabel(activeSemester)}</span>
                <ChevronDown size={11} />
            </button>
            {open && (
                <>
                    <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
                    <div className="absolute left-0 top-8 z-50 bg-card border border-border rounded-xl shadow-lg py-1 min-w-[200px]">
                        {allSemesters.map(s => (
                            <button key={s.id} onClick={() => { setActiveSemester(s); setOpen(false); }}
                                className={`w-full text-left px-3 py-2 text-sm hover:bg-muted transition ${s.id === activeSemester?.id ? 'text-primary font-bold' : ''}`}>
                                {semesterLabel(s)}
                            </button>
                        ))}
                        <div className="border-t border-border mt-1 pt-1">
                            <Link to="/teacher/semesters" onClick={() => setOpen(false)}
                                className="block px-3 py-2 text-xs text-muted-foreground hover:bg-muted">
                                ⚙️ จัดการปีการศึกษา
                            </Link>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}

const MENU_GROUPS = [
    {
        label: null,
        items: [
            { to: '/teacher', icon: LayoutDashboard, label: 'หน้าหลัก', exact: true },
        ],
    },
    {
        label: 'การเรียนการสอน',
        items: [
            { to: '/teacher/materials', icon: FileText, label: 'เนื้อหาบทเรียน' },
            { to: '/teacher/assignments', icon: ClipboardList, label: 'งานมอบหมาย' },
            { to: '/teacher/scores', icon: BarChart3, label: 'คะแนนเก็บ' },
            { to: '/teacher/assignment-tracker', icon: Table, label: 'ติดตามงาน' },
        ],
    },
    {
        label: 'แต้มและรางวัล',
        items: [
            { to: '/teacher/points', icon: Trophy, label: 'แต้มสะสม & รางวัล' },
            { to: '/teacher/ranking', icon: Trophy, label: 'แรงค์กิ้ง' },
            { to: '/teacher/virus', icon: Bug, label: 'ห้องทดลองไวรัส' },
        ],
    },
    {
        label: 'สถานะ',
        items: [
            { to: '/teacher/student-status', icon: Bell, label: 'สถานะงาน' },
            { to: '/teacher/notifications', icon: Bell, label: 'รอตรวจ', badgeKey: 'ungraded' },
        ],
    },
    {
        label: 'จัดการ',
        hideForAdmin: true,
        items: [
            { to: '/teacher/classrooms', icon: Layers, label: 'ชั้นเรียน & ห้องเรียน' },
            { to: '/teacher/students', icon: Users, label: 'นักเรียน' },
            { to: '/teacher/subjects', icon: BookOpen, label: 'รายวิชา' },
            { to: '/teacher/semesters', icon: CalendarDays, label: 'ปีการศึกษา' },
        ],
    },
    {
        label: 'ระบบส่วนกลาง (ADMIN)',
        adminOnly: true,
        items: [
            { to: '/teacher/admin/classrooms', icon: Layers, label: 'จัดการชั้นเรียน (ALL)' },
            { to: '/teacher/admin/students', icon: Users, label: 'จัดการนักเรียน (ALL)' },
            { to: '/teacher/admin/subjects', icon: BookOpen, label: 'จัดการรายวิชา (ALL)' },
            { to: '/teacher/admin/semesters', icon: CalendarDays, label: 'จัดการปีการศึกษา (ALL)' },
            { to: '/teacher/manage-accounts', icon: Shield, label: 'จัดการบัญชีครู' },
        ],
    },
    {
        label: 'บัญชีผู้ใช้',
        items: [
            { to: '/teacher/profile', icon: User, label: 'โปรไฟล์ของฉัน' },
        ],
    },
];

const SIDEBAR_COLLAPSED_KEY = 'teacher_sidebar_collapsed';

function TeacherLayoutInner({ children }) {
    const { user, logout } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();
    const [isMobileOpen, setIsMobileOpen] = useState(false);
    const [collapsed, setCollapsed] = useState(() => {
        try { return localStorage.getItem(SIDEBAR_COLLAPSED_KEY) === 'true'; } catch { return false; }
    });
    const [stats, setStats] = useState({ ungraded: 0 });
    const teacher = user;

    useEffect(() => {
        localStorage.setItem(SIDEBAR_COLLAPSED_KEY, collapsed);
    }, [collapsed]);

    useEffect(() => {
        async function loadStats() {
            try {
                const [classrooms, assignments, submissions] = await Promise.all([
                    base44.entities.Classroom.filter({ teacher_id: user.id }),
                    base44.entities.Assignment.filter({ teacher_id: user.id }),
                    base44.entities.Submission.filter({ status: 'submitted', teacher_id: user.id })
                ]);
                const cMap = Object.fromEntries(classrooms.map(c => [c.id, true]));
                const aMap = Object.fromEntries(assignments.map(a => [a.id, a]));
                const pendingCount = submissions.filter(sub => {
                    const a = aMap[sub.assignment_id];
                    return a && cMap[a.classroom_id];
                }).length;
                setStats({ ungraded: pendingCount });
            } catch {}
        }
        loadStats();

        // Online Status Heartbeat
        async function updatePresence() {
            if (user?.id) {
                try {
                    await base44.entities.Teacher.update(user.id, { last_active_at: new Date().toISOString() });
                } catch (e) { console.error('Presence error:', e); }
            }
        }
        updatePresence();
        const interval = setInterval(updatePresence, 5 * 60 * 1000); // Every 5 mins
        return () => clearInterval(interval);
    }, [location.pathname]);

    const isActive = (item) => item.exact ? location.pathname === item.to : location.pathname.startsWith(item.to);
    
    const handleLogout = () => { logout(); navigate('/teacher/login'); };

    const SidebarItem = ({ item, mobile = false }) => {
        const active = isActive(item);
        const Icon = item.icon;
        
        if (item.onClick) {
            return (
                <button onClick={handleLogout}
                    className={`w-full group flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 text-red-500 hover:bg-red-50 mb-0.5`}>
                    <div className="flex-shrink-0"><Icon size={18} /></div>
                    <span className="truncate">ออกจากระบบ</span>
                </button>
            );
        }

        return (
            <Link to={item.to} onClick={() => mobile && setIsMobileOpen(false)}
                className={`group flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 mb-0.5 ${
                    active ? 'bg-primary text-primary-foreground shadow-md shadow-primary/20 ring-1 ring-primary/10' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                } ${collapsed && !mobile ? 'justify-center px-0' : ''}`}>
                <div className="flex-shrink-0"><Icon size={18} /></div>
                {(!collapsed || mobile) && (
                    <>
                        <span className="truncate flex-1">{item.label}</span>
                        {item.badgeKey && stats[item.badgeKey] > 0 && (
                            <span className="flex-shrink-0 w-5 h-5 bg-red-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full animate-pulse">
                                {stats[item.badgeKey]}
                            </span>
                        )}
                    </>
                )}
            </Link>
        );
    };
    const SidebarContent = ({ mobile = false }) => (
        <div className="flex flex-col h-full bg-card border-r border-border overflow-hidden">
            {/* Header */}
            <div className={`flex items-center justify-between p-4 border-b border-border flex-shrink-0 ${collapsed && !mobile ? 'px-3' : 'px-5 py-4'}`}>
                {(!collapsed || mobile) && (
                    <Link to="/teacher" className="flex items-center gap-2 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold flex-shrink-0">T</div>
                        <div className="min-w-0">
                            <h2 className="font-bold text-sm tracking-tight truncate">ระบบจัดการชั้นเรียน</h2>
                            <p className="text-[10px] text-muted-foreground">สำหรับครูผู้สอน</p>
                        </div>
                    </Link>
                )}
                {collapsed && !mobile && (
                    <Link to="/teacher" className="mx-auto">
                        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold">T</div>
                    </Link>
                )}
                {mobile && (
                    <button onClick={() => setIsMobileOpen(false)} className="p-1 text-muted-foreground hover:text-foreground">
                        <X size={18} />
                    </button>
                )}
            </div>

            {/* Semester badge */}
            {(!collapsed || mobile) && (
                <div className="px-5 py-2 border-b border-border flex-shrink-0">
                    <SemesterBadge />
                </div>
            )}

            {/* Menu */}
            <div className="flex-1 overflow-y-auto py-3">
                {MENU_GROUPS.map((group, gi) => {
                    if (group.adminOnly && user?.role !== 'admin') return null;
                    if (group.hideForAdmin && user?.role === 'admin') return null;

                    const filteredItems = group.items.filter(item => {
                        if (item.adminOnly) return user?.role === 'admin';
                        return true;
                    });
                    if (filteredItems.length === 0) return null;
                    
                    return (
                        <div key={gi} className={gi > 0 ? 'mt-1' : ''}>
                            {group.label && (!collapsed || mobile) && (
                                <p className="px-5 pt-3 pb-1 text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
                                    {group.label}
                                </p>
                            )}
                            {group.label && (collapsed && !mobile) && <div className="mx-3 my-2 border-t border-border" />}
                            <div className={`space-y-0.5 ${collapsed && !mobile ? 'px-2' : 'px-3'}`}>
                                {filteredItems.map(item => (
                                    <SidebarItem key={item.to} item={item} mobile={mobile} />
                                ))}
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Footer */}
            <div className={`border-t border-border flex-shrink-0 ${collapsed && !mobile ? 'p-2' : 'p-3'}`}>
                {!mobile && (
                    <button
                        onClick={() => setCollapsed(c => !c)}
                        className={`flex items-center gap-2 w-full rounded-xl py-2 px-3 text-xs text-muted-foreground hover:bg-muted transition mb-1
                            ${collapsed ? 'justify-center px-2' : ''}`}
                        title={collapsed ? 'ขยาย sidebar' : 'ย่อ sidebar'}
                    >
                        {collapsed ? <ChevronRight size={16} /> : <><ChevronLeft size={16} /><span>ย่อเมนู</span></>}
                    </button>
                )}
                <button onClick={handleLogout}
                    className={`flex items-center gap-3 w-full rounded-xl py-2 px-3 text-sm text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition font-medium
                        ${collapsed && !mobile ? 'justify-center' : ''}`}
                    title={collapsed && !mobile ? 'ออกจากระบบ' : undefined}>
                    <LogOut size={18} />
                    {(!collapsed || mobile) && <span>ออกจากระบบ</span>}
                </button>
            </div>
        </div>
    );

    return (
        <SemesterProvider>
            <TeacherRealtimeToast />
            <div className="flex h-screen bg-background overflow-hidden">
                {/* Desktop Sidebar */}
                <div
                    className="hidden md:flex flex-col flex-shrink-0 h-full transition-all duration-300"
                    style={{ width: collapsed ? '68px' : '256px' }}
                >
                    <SidebarContent />
                </div>

                {/* Mobile Sidebar Overlay */}
                {isMobileOpen && (
                    <div className="fixed inset-0 z-50 md:hidden">
                        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsMobileOpen(false)} />
                        <div className="absolute inset-y-0 left-0 w-72 shadow-2xl">
                            <SidebarContent mobile />
                        </div>
                    </div>
                )}

                {/* Main Content */}
                <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
                    {/* Mobile Header */}
                    <div className="md:hidden flex items-center justify-between px-4 py-3 bg-card border-b border-border flex-shrink-0">
                        <button onClick={() => setIsMobileOpen(true)} className="p-2 -ml-2 text-muted-foreground hover:text-foreground">
                            <Menu size={22} />
                        </button>
                        <Link to="/teacher" className="font-bold flex items-center gap-2">
                            <div className="w-7 h-7 rounded bg-primary flex items-center justify-center text-primary-foreground text-xs">T</div>
                            <span className="text-sm">ระบบจัดการชั้นเรียน</span>
                        </Link>
                        <div className="w-9" />
                    </div>

                    {/* Desktop Header */}
                    <header className="hidden md:flex items-center justify-between px-8 py-4 bg-card/50 backdrop-blur-md border-b border-border flex-shrink-0 sticky top-0 z-30">
                        <div className="flex items-center gap-3">
                        </div>
                        <div className="flex items-center gap-4">
                            {teacher && (
                                <Link to="/teacher/profile" className="flex items-center gap-3 p-1.5 pr-4 rounded-full bg-muted/40 hover:bg-muted transition-all group overflow-hidden border border-border/50">
                                    <div className="scale-75 origin-center -ml-2 -mb-1">
                                        <StudentAvatar student={teacher} size={40} showTitle={false} />
                                    </div>
                                    <div className="flex flex-col -ml-1">
                                        <span className={`text-xs font-black student-name-${teacher.id} truncate max-w-[120px]`}>
                                            {teacher.first_name} {teacher.last_name}
                                        </span>
                                        <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest">{teacher.title || 'Teacher'}</span>
                                    </div>
                                </Link>
                            )}
                            <button onClick={handleLogout} className="p-2 text-muted-foreground hover:text-red-500 hover:bg-red-50 rounded-full transition-colors" title="ออกจากระบบ">
                                <LogOut size={20} />
                            </button>
                        </div>
                    </header>

                    {/* Page Content */}
                    <main className="flex-1 overflow-y-auto">
                        {children}
                    </main>
                </div>
            </div>
        </SemesterProvider>
    );
}

export default function TeacherLayout({ children }) {
    return (
        <TeacherLayoutInner>{children}</TeacherLayoutInner>
    );
}
