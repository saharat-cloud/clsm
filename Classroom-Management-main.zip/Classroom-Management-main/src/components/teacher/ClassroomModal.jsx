import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { X } from 'lucide-react';
import { playClick } from '@/lib/sound';
import { useSemester } from '@/lib/SemesterContext';
import { useAuth } from '@/lib/AuthContext';

const LEVELS = ['ปวช.1', 'ปวช.2', 'ปวช.3', 'ปวส.1', 'ปวส.2'];
const TYPES = ['ปกติ', 'สมทบ'];

function buildName(level, room, type) {
    if (!level || !room) return '';
    const suffix = type === 'สมทบ' ? ' (สมทบ)' : '';
    return `${level}/${room}${suffix}`;
}

export default function ClassroomModal({ classroom, onClose, onSaved }) {
    const { user } = useAuth();
    const { activeSemester } = useSemester();

    // Parse existing classroom name back to parts if editing
    const [level, setLevel] = useState(() => classroom?.level || 'ปวช.1');
    const [roomNumber, setRoomNumber] = useState(() => classroom?.room_number || 1);
    const [type, setType] = useState(() => {
        if (classroom?.name?.includes('สมทบ')) return 'สมทบ';
        return 'ปกติ';
    });
    const [preview, setPreview] = useState(buildName(level, roomNumber, type));

    useEffect(() => {
        setPreview(buildName(level, roomNumber, type));
    }, [level, roomNumber, type]);

    async function handleSubmit(e) {
        e.preventDefault();
        playClick();
        const name = buildName(level, roomNumber, type);
        const payload = {
            name,
            level,
            room_number: Number(roomNumber),
            semester_academic_year: activeSemester?.academic_year || classroom?.semester_academic_year || null,
            semester_number: activeSemester?.semester || classroom?.semester_number || null,
        };
        if (classroom?.id) {
            await base44.entities.Classroom.update(classroom.id, payload);
        } else {
            await base44.entities.Classroom.create({ 
                ...payload, 
                teacher_id: user?.id || 'kanit_admin',
                student_ids: [], 
                subject_ids: [] 
            });
        }
        onSaved();
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
            <div className="bg-card rounded-2xl shadow-2xl w-full max-w-md p-6 border border-border">
                <div className="flex items-center justify-between mb-5">
                    <div>
                        <h2 className="text-lg font-bold">{classroom ? 'แก้ไขห้องเรียน' : 'เพิ่มห้องเรียนใหม่'}</h2>
                        <p className="text-xs text-muted-foreground mt-0.5">
                            {activeSemester ? `ปีการศึกษา ${activeSemester.academic_year} เทอม ${activeSemester.semester}` : 'กำหนดรายวิชาได้ในขั้นตอนถัดไป'}
                        </p>
                    </div>
                    <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1"><X size={20} /></button>
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Level */}
                    <div>
                        <label className="block text-sm font-medium mb-1">ระดับชั้น *</label>
                        <select required value={level} onChange={e => setLevel(e.target.value)}
                            className="w-full border border-input rounded-xl px-3 py-2.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                            {LEVELS.map(l => <option key={l} value={l}>{l}</option>)}
                        </select>
                    </div>
                    {/* Room + Type */}
                    <div className="grid grid-cols-2 gap-3">
                        <div>
                            <label className="block text-sm font-medium mb-1">หมายเลขห้อง *</label>
                            <select required value={roomNumber} onChange={e => setRoomNumber(e.target.value)}
                                className="w-full border border-input rounded-xl px-3 py-2.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                                {Array.from({ length: 20 }, (_, i) => i + 1).map(n => (
                                    <option key={n} value={n}>{n}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">ประเภท</label>
                            <select value={type} onChange={e => setType(e.target.value)}
                                className="w-full border border-input rounded-xl px-3 py-2.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                                {TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                        </div>
                    </div>
                    {/* Preview */}
                    <div className="bg-muted rounded-xl px-4 py-3 text-center">
                        <p className="text-xs text-muted-foreground mb-0.5">ชื่อห้องที่จะแสดง</p>
                        <p className="text-lg font-bold text-primary">{preview || '--'}</p>
                    </div>
                    <div className="flex gap-3 pt-2">
                        <button type="button" onClick={onClose}
                            className="flex-1 border border-border rounded-xl py-2.5 text-sm hover:bg-muted transition">ยกเลิก</button>
                        <button type="submit"
                            className="flex-1 bg-primary text-primary-foreground rounded-xl py-2.5 text-sm font-semibold hover:opacity-90 transition">บันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    );
}