import { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { base44 } from '@/api/base44Client';
import { X, Upload, CheckCircle } from 'lucide-react';
import { useSemester } from '@/lib/SemesterContext';
import { useAuth } from '@/lib/AuthContext';

export default function ImportStudentsModal({ onClose, onSaved }) {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [file, setFile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [preview, setPreview] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [selectedClassroom, setSelectedClassroom] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        async function loadClassrooms() {
            if (!user) return;
            try {
                const filter = {
                    ...(activeSemester ? { 
                        semester_academic_year: activeSemester.academic_year, 
                        semester_number: activeSemester.semester 
                    } : {}),
                    teacher_id: 'kanit_admin'
                };
                const res = await base44.entities.Classroom.filter(filter);
                setClassrooms(res || []);
            } catch (err) {
                console.error('Failed to load classrooms:', err);
            }
        }
        loadClassrooms();
    }, [user, activeSemester]);

    async function handleFile(e) {
        const f = e.target.files[0];
        if (!f) return;
        setFile(f);
        setError('');
        setLoading(true);

        try {
            const reader = new FileReader();
            reader.onload = (event) => {
                const arrayBuffer = event.target.result;
                if (!(arrayBuffer instanceof ArrayBuffer)) return;
                
                try {
                    const data = new Uint8Array(arrayBuffer);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const sheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[sheetName];
                    const json = XLSX.utils.sheet_to_json(worksheet);

                    if (json.length === 0) {
                        setError('ไม่พบข้อมูลในไฟล์');
                        setLoading(false);
                        return;
                    }

                    // Map fields to match our expectations
                    const mappedData = json.map(row => ({
                        student_id: row.student_id || row['รหัสนักเรียน'] || row['รหัส'] || '',
                        password: row.password || row['รหัสผ่าน'] || '',
                        first_name: row.first_name || row['ชื่อ'] || '',
                        last_name: row.last_name || row['นามสกุล'] || '',
                        nickname: row.nickname || row['ชื่อเล่น'] || '',
                    }));

                    setPreview(mappedData);
                    setLoading(false);
                } catch (err) {
                    setError('เกิดข้อผิดพลาดในการอ่านข้อมูล: ' + err.message);
                    setLoading(false);
                }
            };
            reader.readAsArrayBuffer(f);
        } catch {
            setError('ไม่สามารถอ่านไฟล์ได้');
            setLoading(false);
        }
    }

    async function handleImport() {
        if (preview.length === 0) return;
        setLoading(true);
        try {
            const records = preview
                .filter(r => r.student_id && r.first_name) // nickname is optional
                .map(r => ({
                    student_id: String(r.student_id).trim(),
                    password: String(r.password || r.student_id).trim(), // default to student_id if no password
                    first_name: String(r.first_name).trim(),
                    last_name: String(r.last_name || '').trim(),
                    nickname: String(r.nickname || '').trim(), // can be empty
                    teacher_id: user.id,
                    total_points: 0,
                    semester_academic_year: activeSemester?.academic_year || null,
                    semester_number: activeSemester?.semester || null,
                    classroom_ids: selectedClassroom ? [selectedClassroom] : [],
                }));

            if (records.length === 0) {
                setError('ไม่มีข้อมูลที่ถูกต้อง (ต้องมีรหัสนักเรียนและชื่อ)');
                setLoading(false);
                return;
            }

            // Use bulkUpsert to handle existing students gracefully
            const upsertedStudents = await base44.entities.Student.bulkUpsert(records, 'student_id');

            // If a classroom is selected, add these students to it
            if (selectedClassroom && upsertedStudents?.length > 0) {
                const newStudentDbIds = upsertedStudents.map(s => String(s.id));
                const classroom = await base44.entities.Classroom.get(selectedClassroom);
                if (classroom) {
                    const existingIds = (classroom.student_ids || []).map(id => String(id));
                    const combinedIds = Array.from(new Set([...existingIds, ...newStudentDbIds]));
                    await base44.entities.Classroom.update(selectedClassroom, { student_ids: combinedIds });
                }
            }

            onSaved();
        } catch (err) {
            setError('เกิดข้อผิดพลาดในการบันทึก: ' + err.message);
            setLoading(false);
        }
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
            <div className="bg-card rounded-2xl shadow-xl w-full max-w-2xl p-6 max-h-[80vh] flex flex-col">
                <div className="flex items-center justify-between mb-5">
                    <h2 className="text-lg font-bold">นำเข้านักเรียนจากไฟล์</h2>
                    <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
                </div>

                <div className="mb-4 p-3 bg-blue-50 rounded-xl text-sm text-blue-700">
                    รองรับไฟล์ Excel (.xlsx) หรือ CSV มีคอลัมน์: student_id, password, first_name, last_name, nickname
                </div>

                <div className="mb-6">
                    <label className="block text-sm font-bold mb-2 text-foreground/80">
                        เลือกห้องเรียนที่จะเพิ่มนักเรียนเข้าไป (ไม่บังคับ)
                    </label>
                    <select 
                        value={selectedClassroom}
                        onChange={e => setSelectedClassroom(e.target.value)}
                        className="w-full bg-background border border-border rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition"
                    >
                        <option value="">-- ไม่ระบุห้องเรียน (เพิ่มลงรายชื่อรวมเท่านั้น) --</option>
                        {classrooms.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                    </select>
                </div>

                <label className="block">
                    <div className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-muted/30 transition">
                        <Upload size={32} className="mx-auto text-muted-foreground mb-2" />
                        <p className="text-sm text-muted-foreground">{file ? file.name : 'คลิกเพื่อเลือกไฟล์ Excel หรือ CSV'}</p>
                    </div>
                    <input type="file" accept=".xlsx,.csv,.xls" className="hidden" onChange={handleFile} />
                </label>

                {loading && <p className="text-center text-sm text-muted-foreground mt-4">กำลังประมวลผล...</p>}
                {error && <p className="text-center text-sm text-destructive mt-4">{error}</p>}

                {preview.length > 0 && (
                    <div className="mt-4 flex-1 overflow-auto">
                        <p className="text-sm font-medium mb-2 flex items-center gap-2">
                            <CheckCircle size={16} className="text-green-600" />
                            พบข้อมูล {preview.length} คน
                        </p>
                        <div className="border border-border rounded-xl overflow-hidden">
                            <table className="w-full text-xs">
                                <thead className="bg-muted/50">
                                    <tr>
                                        {['รหัส', 'ชื่อ', 'นามสกุล', 'ชื่อเล่น'].map(h => (
                                            <th key={h} className="px-3 py-2 text-left text-muted-foreground">{h}</th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-border">
                                    {preview.slice(0, 5).map((r, i) => (
                                        <tr key={i}>
                                            <td className="px-3 py-2 font-mono">{r.student_id}</td>
                                            <td className="px-3 py-2">{r.first_name}</td>
                                            <td className="px-3 py-2">{r.last_name}</td>
                                            <td className="px-3 py-2">{r.nickname}</td>
                                        </tr>
                                    ))}
                                    {preview.length > 5 && (
                                        <tr><td colSpan={4} className="px-3 py-2 text-center text-muted-foreground">... และอีก {preview.length - 5} คน</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                <div className="flex gap-3 mt-4">
                    <button onClick={onClose} className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted transition">ยกเลิก</button>
                    {preview.length > 0 && (
                        <button onClick={handleImport} disabled={loading}
                            className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition disabled:opacity-50">
                            นำเข้า {preview.length} คน
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}