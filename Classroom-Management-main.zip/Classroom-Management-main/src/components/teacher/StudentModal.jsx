import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { X, Check } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { playClick } from '@/lib/sound';
import { useSemester } from '@/lib/SemesterContext';

export default function StudentModal({ student, onClose, onSaved }) {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [form, setForm] = useState({
        student_id: student?.student_id || '',
        password: student?.password || '',
        first_name: student?.first_name || '',
        last_name: student?.last_name || '',
        nickname: student?.nickname || '',
    });
    const [classrooms, setClassrooms] = useState([]);
    const [selectedClassrooms, setSelectedClassrooms] = useState(student?.classroom_ids || []);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (user && activeSemester) {
            const filter = {
                ...(activeSemester ? { semester_academic_year: activeSemester.academic_year, semester_number: activeSemester.semester } : {}),
                teacher_id: 'kanit_admin'
            };
            base44.entities.Classroom.filter(filter).then(setClassrooms);
        }
    }, [user, activeSemester]);

    function toggleClassroom(id) {
        playClick();
        setSelectedClassrooms(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        let studentRecordId = student?.id;

        if (studentRecordId) {
            await base44.entities.Student.update(studentRecordId, { ...form, teacher_id: 'kanit_admin', classroom_ids: selectedClassrooms });
        } else {
            // Use upsert to handle if this student already exists in the system
            const created = await base44.entities.Student.upsert({ 
                ...form, 
                teacher_id: 'kanit_admin',
                total_points: student?.total_points || 0, // Preserve total points if they exist
                classroom_ids: selectedClassrooms,
                semester_academic_year: activeSemester?.academic_year || null,
                semester_number: activeSemester?.semester || null,
            }, 'student_id');
            studentRecordId = created.id;
        }

        // Sync classroom.student_ids
        const oldClassrooms = student?.classroom_ids || [];
        const removed = oldClassrooms.filter(id => !selectedClassrooms.includes(id));
        const added = selectedClassrooms.filter(id => !oldClassrooms.includes(id));

        await Promise.all([
            ...removed.map(async clsId => {
                const cls = classrooms.find(c => c.id === clsId);
                if (cls) await base44.entities.Classroom.update(clsId, {
                    student_ids: (cls.student_ids || []).filter(id => id !== studentRecordId)
                });
            }),
            ...added.map(async clsId => {
                const cls = classrooms.find(c => c.id === clsId);
                if (cls && !(cls.student_ids || []).includes(studentRecordId)) {
                    await base44.entities.Classroom.update(clsId, {
                        student_ids: [...(cls.student_ids || []), studentRecordId]
                    });
                }
            }),
        ]);

        setLoading(false);
        onSaved();
    }

    const fields = [
        { key: 'student_id', label: 'รหัสนักเรียน *', required: true },
        { key: 'password', label: 'Password *', required: true },
        { key: 'first_name', label: 'ชื่อ *', required: true },
        { key: 'last_name', label: 'นามสกุล *', required: true },
        { key: 'nickname', label: 'ชื่อเล่น', required: false },
    ];

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
            <div className="bg-card rounded-2xl shadow-2xl w-full max-w-lg p-6 border border-border max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-5">
                    <h2 className="text-lg font-bold">{student ? 'แก้ไขข้อมูลนักเรียน' : 'เพิ่มนักเรียน'}</h2>
                    <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1"><X size={20} /></button>
                </div>
                <form onSubmit={handleSubmit} className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                        {fields.map(f => (
                            <div key={f.key} className={f.key === 'student_id' || f.key === 'password' ? '' : ''}>
                                <label className="block text-sm font-medium mb-1">{f.label}</label>
                                <input
                                    required={f.required}
                                    value={form[f.key]}
                                    type={f.key === 'password' ? 'text' : 'text'}
                                    onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                                />
                            </div>
                        ))}
                    </div>

                    <div>
                        <label className="block text-sm font-medium mb-2">
                            ห้องเรียน <span className="text-muted-foreground font-normal">(เลือกได้หลายห้อง)</span>
                        </label>
                        {classrooms.length === 0 ? (
                            <p className="text-sm text-muted-foreground p-3 bg-muted/50 rounded-xl">
                                ยังไม่มีห้องเรียน — <a href="/teacher/classrooms" className="text-primary underline">เพิ่มห้องเรียนก่อน</a>
                            </p>
                        ) : (
                            <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                                {classrooms.map(c => {
                                    const selected = selectedClassrooms.includes(c.id);
                                    return (
                                        <button
                                            key={c.id}
                                            type="button"
                                            onClick={() => toggleClassroom(c.id)}
                                            className={`flex items-center gap-2 p-2.5 rounded-xl border text-sm text-left transition-all ${selected ? 'border-primary bg-accent text-accent-foreground' : 'border-border hover:bg-muted/50'
                                                }`}
                                        >
                                            <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-all ${selected ? 'bg-primary border-primary' : 'border-muted-foreground/50'
                                                }`}>
                                                {selected && <Check size={12} className="text-white" strokeWidth={3} />}
                                            </div>
                                            <div className="min-w-0">
                                                <p className="font-medium truncate">{c.name}</p>
                                                {c.academic_year && <p className="text-xs text-muted-foreground">ปี {c.academic_year}{c.semester ? ` เทอม ${c.semester}` : ''}</p>}
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                    </div>

                    <div className="flex gap-3 pt-2">
                        <button type="button" onClick={onClose}
                            className="flex-1 border border-border rounded-xl py-2.5 text-sm hover:bg-muted transition">ยกเลิก</button>
                        <button type="submit" disabled={loading}
                            className="flex-1 bg-primary text-primary-foreground rounded-xl py-2.5 text-sm font-semibold hover:opacity-90 transition disabled:opacity-50">
                            {loading ? 'กำลังบันทึก...' : 'บันทึก'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}