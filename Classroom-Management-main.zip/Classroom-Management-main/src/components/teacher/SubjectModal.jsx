import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { X } from 'lucide-react';
import { alerts } from '@/utils/alerts';
import { useSemester } from '@/lib/SemesterContext';
import { useAuth } from '@/lib/AuthContext';

export default function SubjectModal({ subject: initialSubject, onClose, onSaved }) {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [subject, setSubject] = useState(initialSubject); // Use internal state for subject to allow modification
    const [form, setForm] = useState({
        name: subject?.name || '',
        code: subject?.code || '',
        description: subject?.description || '',
        credit: subject?.credit || '',
        classroom_ids: [], // We'll populate this from classrooms
    });

    const [classrooms, setClassrooms] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setLoading(true);
        const filter = {
            teacher_id: 'kanit_admin',
            ...(activeSemester ? { 
                semester_academic_year: activeSemester.academic_year, 
                semester_number: activeSemester.semester 
            } : {})
        };
        base44.entities.Classroom.filter(filter)
            .then(clsList => {
                setClassrooms(clsList);
                if (subject?.id) {
                    const linkedIds = clsList.filter(c => (c.subject_ids || []).includes(subject.id)).map(c => c.id);
                    setForm(f => ({ ...f, classroom_ids: linkedIds }));
                }
            })
            .finally(() => setLoading(false));
    }, [activeSemester, subject?.id]);

    const [grading, setGrading] = useState(subject?.grading_criteria || {
        assignment: 20,
        affective: 10,
        midterm: 30,
        final: 40,
        grades: { 4: 80, 3.5: 75, 3: 70, 2.5: 65, 2: 60, 1.5: 55, 1: 50, 0: 0 }
    });

    const totalWeight = (grading.assignment || 0) + (grading.affective || 0) + (grading.midterm || 0) + (grading.final || 0);

    async function handleSubmit(e) {
        e.preventDefault();
        if (totalWeight > 100) {
            alerts.error('สัดส่วนคะแนนผิดพลาด', 'ผลรวมสัดส่วนคะแนนต้องไม่เกิน 100');
            return;
        }
        const data = { 
            ...form, 
            credit: form.credit ? Number(form.credit) : undefined,
            grading_criteria: grading
        };
        const { classroom_ids: _, ...cleanData } = data;
        let finalizedSubject = subject;
        if (subject?.id) {
            await base44.entities.Subject.update(subject.id, {
                ...cleanData,
                teacher_id: user?.id || 'kanit_admin',
                semester_academic_year: activeSemester?.academic_year || null,
                semester_number: activeSemester?.semester || null,
            });
        } else {
            finalizedSubject = await base44.entities.Subject.create({
                ...cleanData,
                teacher_id: user?.id || 'kanit_admin',
                semester_academic_year: activeSemester?.academic_year || null,
                semester_number: activeSemester?.semester || null,
            });
            setSubject(finalizedSubject);
        }

        // Sync classrooms: Link/Unlink this subject
        const syncPromises = classrooms.map(async (cls) => {
            const isSelected = form.classroom_ids.includes(cls.id);
            const currentIds = cls.subject_ids || [];
            const hasSubject = currentIds.includes(finalizedSubject.id);

            if (isSelected && !hasSubject) {
                // Add
                await base44.entities.Classroom.update(cls.id, {
                    subject_ids: [...currentIds, finalizedSubject.id],
                    subject_id: currentIds[0] || finalizedSubject.id
                });
            } else if (!isSelected && hasSubject) {
                // Remove
                const nextIds = currentIds.filter(id => id !== finalizedSubject.id);
                await base44.entities.Classroom.update(cls.id, {
                    subject_ids: nextIds,
                    subject_id: nextIds[0] || null
                });
            }
        });
        await Promise.all(syncPromises);

        onSaved();
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 overflow-y-auto">
            <div className="bg-card rounded-2xl shadow-xl w-full max-w-2xl p-6 my-auto max-h-[90vh] flex flex-col">
                <div className="flex items-center justify-between mb-5 flex-shrink-0">
                    <h2 className="text-lg font-bold">{subject ? 'แก้ไขวิชา' : 'เพิ่มวิชาใหม่'}</h2>
                    <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
                </div>
                <form onSubmit={handleSubmit} className="flex flex-col overflow-hidden">
                    <div className="overflow-y-auto pr-2 space-y-4">
                    <div>
                        <label className="block text-sm font-medium mb-1">รหัสวิชา *</label>
                        <input required value={form.code} onChange={e => setForm({ ...form, code: e.target.value })}
                            className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">ชื่อวิชา *</label>
                        <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                            className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-2">เลือกห้องเรียนที่สอน *</label>
                        <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto p-1">
                            {classrooms.map(c => (
                                <label key={c.id} className={`flex items-center gap-2 p-2 border rounded-xl cursor-pointer transition ${form.classroom_ids.includes(c.id) ? 'bg-primary/5 border-primary text-primary font-medium' : 'bg-background border-border text-muted-foreground'}`}>
                                    <input type="checkbox" className="w-4 h-4 rounded text-primary focus:ring-primary border-gray-300"
                                        checked={form.classroom_ids.includes(c.id)}
                                        onChange={() => {
                                            setForm(f => {
                                                const ids = f.classroom_ids.includes(c.id)
                                                    ? f.classroom_ids.filter(id => id !== c.id)
                                                    : [...f.classroom_ids, c.id];
                                                return { ...f, classroom_ids: ids };
                                            });
                                        }} />
                                    <span className="text-sm">{c.name}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">หน่วยกิต</label>
                        <input type="number" value={form.credit} onChange={e => setForm({ ...form, credit: e.target.value })}
                            className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">คำอธิบาย</label>
                        <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                            rows={3} className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
                    </div>
                    
                    <div className="border-t border-border pt-4 mt-4">
                        <div className="flex items-center justify-between mb-3">
                            <h3 className="font-bold text-sm">สัดส่วนคะแนน</h3>
                            <span className={`text-xs font-bold px-2 py-1 rounded-full ${totalWeight === 100 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                รวม: {totalWeight}/100
                            </span>
                        </div>
                        <div className="grid grid-cols-4 gap-3">
                            <div>
                                <label className="block text-xs font-medium mb-1">งานที่สั่ง</label>
                                <input type="number" min={0} value={grading.assignment} onChange={e => setGrading({...grading, assignment: Number(e.target.value)})}
                                    className="w-full border border-input rounded-xl px-2 py-1.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div>
                                <label className="block text-xs font-medium mb-1">จิตพิสัย</label>
                                <input type="number" min={0} value={grading.affective} onChange={e => setGrading({...grading, affective: Number(e.target.value)})}
                                    className="w-full border border-input rounded-xl px-2 py-1.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div>
                                <label className="block text-xs font-medium mb-1">สอบกลางภาค</label>
                                <input type="number" min={0} value={grading.midterm} onChange={e => setGrading({...grading, midterm: Number(e.target.value)})}
                                    className="w-full border border-input rounded-xl px-2 py-1.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div>
                                <label className="block text-xs font-medium mb-1">สอบปลายภาค</label>
                                <input type="number" min={0} value={grading.final} onChange={e => setGrading({...grading, final: Number(e.target.value)})}
                                    className="w-full border border-input rounded-xl px-2 py-1.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                        </div>
                    </div>

                    <div className="border-t border-border pt-4 mt-4">
                        <h3 className="font-bold text-sm mb-3">เกณฑ์การตัดเกรด (ขั้นต่ำ)</h3>
                        <div className="grid grid-cols-4 gap-3">
                            {Object.entries(grading.grades).map(([grade, minScore]) => (
                                <div key={grade} className="flex items-center gap-2">
                                    <span className="text-sm font-bold w-6">เกรด {grade}:</span>
                                    <input type="number" min={0} max={100} value={minScore} 
                                        onChange={e => setGrading({...grading, grades: {...grading.grades, [grade]: Number(e.target.value)}})}
                                        className="w-full border border-input rounded-xl px-2 py-1.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                            ))}
                        </div>
                    </div>

                    </div>
                    <div className="flex gap-3 pt-4 mt-4 border-t border-border flex-shrink-0">
                        <button type="button" onClick={onClose} className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted transition">ยกเลิก</button>
                        <button type="submit" disabled={totalWeight > 100} className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition disabled:opacity-50">บันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    );
}