import '@/components/ui/loading-spinner.css';

export function LoadingSpinner({ size = 'default', className = '' }) {
    const cls = {
        default: 'loading-spinner',
        sm: 'loading-spinner loading-spinner-sm',
        xs: 'loading-spinner loading-spinner-xs',
    }[size] || 'loading-spinner';
    return <div className={`${cls} ${className}`} role="status" aria-label="กำลังโหลด..." />;
}

export function PageLoading() {
    return (
        <div className="page-loading">
            <div className="flex flex-col items-center gap-3">
                <LoadingSpinner />
                <p className="text-sm text-muted-foreground animate-pulse">กำลังโหลด...</p>
            </div>
        </div>
    );
}
