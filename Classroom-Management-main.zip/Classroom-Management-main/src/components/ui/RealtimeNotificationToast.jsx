import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/api/supabaseClient';
import { Bell, X, Star, Trophy, CheckCircle, AlertTriangle, Gift, Skull, HeartPulse } from 'lucide-react';

const TYPE_CONFIG = {
    grade_received: {
        icon: CheckCircle,
        gradient: 'from-emerald-500 to-teal-600',
        bg: '#f0fdf4',
        border: '#bbf7d0',
    },
    points_added: {
        icon: Star,
        gradient: 'from-amber-400 to-orange-500',
        bg: '#fffbeb',
        border: '#fde68a',
    },
    points_deducted: {
        icon: Star,
        gradient: 'from-red-400 to-rose-600',
        bg: '#fef2f2',
        border: '#fecaca',
    },
    reward_approved: {
        icon: Gift,
        gradient: 'from-purple-500 to-violet-600',
        bg: '#faf5ff',
        border: '#d8b4fe',
    },
    edit_approved: {
        icon: CheckCircle,
        gradient: 'from-blue-500 to-indigo-600',
        bg: '#eff6ff',
        border: '#bfdbfe',
    },
    edit_rejected: {
        icon: AlertTriangle,
        gradient: 'from-red-400 to-rose-500',
        bg: '#fef2f2',
        border: '#fecaca',
    },
    rank_changed_score: {
        icon: Trophy,
        gradient: 'from-yellow-400 to-amber-500',
        bg: '#fefce8',
        border: '#fde047',
    },
    rank_changed_points: {
        icon: Trophy,
        gradient: 'from-amber-400 to-yellow-500',
        bg: '#fffbeb',
        border: '#fcd34d',
    },
    assignment_reminder: {
        icon: AlertTriangle,
        gradient: 'from-orange-400 to-red-500',
        bg: '#fff7ed',
        border: '#fdba74',
    },
    virus_infected: {
        icon: Skull,
        gradient: 'from-red-600 to-red-900',
        bg: '#fef2f2',
        border: '#ef4444',
    },
    virus_cured: {
        icon: HeartPulse,
        gradient: 'from-green-400 to-emerald-600',
        bg: '#f0fdf4',
        border: '#10b981',
    },
    default: {
        icon: Bell,
        gradient: 'from-indigo-500 to-purple-600',
        bg: '#eef2ff',
        border: '#a5b4fc',
    },
};

const DURATION = 7000;

function NotificationToast({ notif, onDismiss }) {
    const [progress, setProgress] = useState(100);
    const [visible, setVisible] = useState(false);
    const intervalRef = useRef(null);
    const timeoutRef = useRef(null);

    const cfg = TYPE_CONFIG[notif.type] || TYPE_CONFIG.default;
    const Icon = cfg.icon;

    const dismiss = useCallback(() => {
        setVisible(false);
        clearInterval(intervalRef.current);
        clearTimeout(timeoutRef.current);
        setTimeout(() => onDismiss(notif.id), 400);
    }, [notif.id, onDismiss]);

    useEffect(() => {
        const raf = requestAnimationFrame(() => setVisible(true));
        const start = Date.now();
        intervalRef.current = setInterval(() => {
            const elapsed = Date.now() - start;
            setProgress(Math.max(0, 100 - (elapsed / DURATION) * 100));
        }, 40);
        timeoutRef.current = setTimeout(dismiss, DURATION);
        return () => {
            cancelAnimationFrame(raf);
            clearInterval(intervalRef.current);
            clearTimeout(timeoutRef.current);
        };
    }, [dismiss]);

    return (
        <div
            style={{
                transition: 'all 0.4s cubic-bezier(0.34,1.56,0.64,1)',
                opacity: visible ? 1 : 0,
                transform: visible ? 'translateY(0) scale(1)' : 'translateY(-20px) scale(0.92)',
                width: '100%',
                pointerEvents: 'all',
            }}
        >
            <div
                style={{
                    background: cfg.bg,
                    border: `1.5px solid ${cfg.border}`,
                    borderRadius: '16px',
                    boxShadow: '0 8px 32px rgba(0,0,0,0.18), 0 2px 8px rgba(0,0,0,0.10)',
                    overflow: 'hidden',
                }}
            >
                {/* Gradient bar */}
                <div style={{
                    height: '3px',
                    background: `linear-gradient(to right, var(--tw-gradient-from,#6366f1), var(--tw-gradient-to,#8b5cf6))`,
                    backgroundImage: `linear-gradient(to right, ${cfg.gradient.includes('emerald') ? '#10b981,#0d9488' : cfg.gradient.includes('amber') ? '#f59e0b,#f97316' : cfg.gradient.includes('purple') ? '#a855f7,#7c3aed' : cfg.gradient.includes('blue') ? '#3b82f6,#4338ca' : cfg.gradient.includes('yellow') ? '#eab308,#f59e0b' : cfg.gradient.includes('orange') ? '#fb923c,#ef4444' : cfg.gradient.includes('red') ? '#f87171,#f43f5e' : '#6366f1,#8b5cf6'})`,
                }} />

                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', padding: '14px 14px 10px' }}>
                    {/* Icon bubble */}
                    <div style={{
                        flexShrink: 0,
                        width: 40, height: 40,
                        borderRadius: '12px',
                        background: `linear-gradient(135deg, ${cfg.gradient.includes('emerald') ? '#10b981,#0d9488' : cfg.gradient.includes('amber') ? '#f59e0b,#f97316' : cfg.gradient.includes('purple') ? '#a855f7,#7c3aed' : cfg.gradient.includes('blue') ? '#3b82f6,#4338ca' : cfg.gradient.includes('yellow') ? '#eab308,#f59e0b' : cfg.gradient.includes('orange') ? '#fb923c,#ef4444' : cfg.gradient.includes('red') ? '#f87171,#f43f5e' : '#6366f1,#8b5cf6'})`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                    }}>
                        <Icon size={20} color="white" />
                    </div>

                    {/* Text */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontWeight: 700, fontSize: '14px', margin: 0, lineHeight: 1.3, color: '#111827' }}>
                            {notif.title}
                        </p>
                        {notif.message && (
                            <p style={{ fontSize: '12px', color: '#6b7280', margin: '3px 0 0', lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                                {notif.message}
                            </p>
                        )}
                    </div>

                    {/* Close */}
                    <button
                        onClick={dismiss}
                        style={{
                            flexShrink: 0, width: 24, height: 24, borderRadius: '50%',
                            border: 'none', background: 'rgba(0,0,0,0.06)',
                            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                            color: '#9ca3af',
                        }}
                    >
                        <X size={13} />
                    </button>
                </div>

                {/* Progress bar */}
                <div style={{ height: '3px', background: 'rgba(0,0,0,0.06)', margin: '0 14px 10px' }}>
                    <div style={{
                        height: '100%', borderRadius: '2px',
                        backgroundImage: `linear-gradient(to right, ${cfg.gradient.includes('emerald') ? '#10b981,#0d9488' : cfg.gradient.includes('amber') ? '#f59e0b,#f97316' : cfg.gradient.includes('purple') ? '#a855f7,#7c3aed' : cfg.gradient.includes('blue') ? '#3b82f6,#4338ca' : cfg.gradient.includes('yellow') ? '#eab308,#f59e0b' : cfg.gradient.includes('orange') ? '#fb923c,#ef4444' : cfg.gradient.includes('red') ? '#f87171,#f43f5e' : '#6366f1,#8b5cf6'})`,
                        width: `${progress}%`,
                        transition: 'width 40ms linear',
                    }} />
                </div>
            </div>
        </div>
    );
}

export default function RealtimeNotificationToast() {
    const [toasts, setToasts] = useState([]);

    const dismiss = useCallback((id) => {
        setToasts(prev => prev.filter(t => t.id !== id));
    }, []);

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) return;
        let std;
        try { std = JSON.parse(session); } catch { return; }
        if (!std?.student_id) return;

        const studentId = std.student_id;

        // Subscribe to ALL inserts on notifications table, then filter client-side.
        // This avoids needing server-side filter replication to be enabled.
        const channel = supabase
            .channel('realtime-notifications-global')
            .on(
                'postgres_changes',
                { event: 'INSERT', schema: 'public', table: 'notifications' },
                (payload) => {
                    const notif = payload.new;
                    // Only show if this notification belongs to the logged-in student
                    if (notif.student_id === studentId) {
                        setToasts(prev => [...prev, notif]);
                    }
                }
            )
            .subscribe((status) => {
                console.log('[RealtimeNotif] status:', status);
            });

        return () => {
            supabase.removeChannel(channel);
        };
    }, []);

    if (toasts.length === 0) return null;

    return (
        <div
            style={{
                position: 'fixed',
                top: '16px',
                left: '50%',
                transform: 'translateX(-50%)',
                zIndex: 99999,
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
                alignItems: 'center',
                pointerEvents: 'none',
                width: 'min(calc(100vw - 32px), 420px)',
            }}
        >
            {toasts.map(t => (
                <NotificationToast key={t.id} notif={t} onDismiss={dismiss} />
            ))}
        </div>
    );
}
