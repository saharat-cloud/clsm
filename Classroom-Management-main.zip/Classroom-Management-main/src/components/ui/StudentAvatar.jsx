import React from 'react';

/**
 * StudentAvatar Component
 * Renders a student's avatar with profile frames and titles.
 * @param {Object} props
 * @param {Object} props.student - The student object from database
 * @param {number} [props.size=40] - Base size of the avatar circle
 * @param {boolean} [props.showTitle=false] - Whether to display the student title text
 * @param {string} [props.className=""] - Additional CSS classes
 */
export default function StudentAvatar({ student, size = 40, showTitle = false, className = "" }) {
    if (!student) return null;

    const { 
        first_name, 
        avatar_url, 
        profile_frame, 
        title, 
        name_bg_color 
    } = student;

    const userId = student.student_id || student.id || 'unknown';
    const initials = first_name?.charAt(0) || '?';
    
    return (
        <div className={`relative flex flex-col items-center gap-1 ${className}`} style={{ width: size + 16 }}>
            {/* Profile Frame Container */}
            <div 
                className="relative flex items-center justify-center"
                style={{ width: size + 8, height: size + 8 }}
            >
                {/* The Frame Image (Absolute positioned behind or around) */}
                {profile_frame && !profile_frame.startsWith('animated:') && (
                    <img 
                        src={profile_frame} 
                        alt="Frame" 
                        className="absolute inset-0 w-full h-full object-contain z-10 pointer-events-none scale-125"
                    />
                )}

                {/* Animated Frames */}
                {profile_frame && profile_frame.startsWith('animated:') && (
                    <div className={`absolute inset-0 z-10 pointer-events-none scale-125 rounded-full frame-${profile_frame.split(':')[1]}`} />
                )}

                {/* The Actual Avatar */}
                <div 
                    className="relative z-20 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-background shadow-sm"
                    style={{ width: size, height: size }}
                >
                    {avatar_url ? (
                        <img src={avatar_url} alt={first_name} className="w-full h-full object-cover" />
                    ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/10 text-primary font-bold">
                            {initials}
                        </div>
                    )}
                </div>
            </div>

            {/* Title Text */}
            {showTitle && title && (
                <span className="text-[10px] font-black uppercase tracking-tighter text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20 whitespace-nowrap">
                    {title}
                </span>
            )}
            
            {/* Custom Styles and Animations */}
            <style dangerouslySetInnerHTML={{ __html: `
                ${name_bg_color ? `
                    .student-name-${userId} { 
                        background: ${name_bg_color.includes('gradient') ? name_bg_color : `${name_bg_color}22`} !important; 
                        color: ${name_bg_color.includes('gradient') ? 'white' : name_bg_color} !important;
                        padding: 2px 8px;
                        border-radius: 6px;
                        display: inline-block;
                        font-weight: 800;
                        text-shadow: ${name_bg_color.includes('gradient') ? '0 1px 2px rgba(0,0,0,0.2)' : 'none'};
                        box-shadow: ${name_bg_color.includes('gradient') ? '0 2px 4px rgba(0,0,0,0.1)' : 'none'};
                    }
                ` : ''}

                /* Animated Frames CSS */
                .frame-glow-gold {
                    border: 4px solid #f59e0b;
                    box-shadow: 0 0 15px #f59e0b, inset 0 0 10px #f59e0b;
                    animation: frame-glow 2s ease-in-out infinite;
                }
                .frame-rainbow-spin {
                    border: 4px solid transparent;
                    background: linear-gradient(white, white) padding-box,
                                linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet) border-box;
                    animation: frame-rotate 3s linear infinite;
                }
                .frame-fire {
                    border: 4px solid #ef4444;
                    box-shadow: 0 0 20px #f97316, 0 0 40px #ef4444;
                    animation: frame-fire-pulse 1.5s ease-in-out infinite;
                }
                .frame-cyberpunk {
                    border: 4px solid #06b6d4;
                    box-shadow: 0 0 10px #06b6d4, 0 0 20px #ec4899;
                    animation: frame-cyber-flicker 2s linear infinite;
                }
                .frame-stars {
                    border: 4px solid #3b82f6;
                    background: radial-gradient(circle at center, transparent 60%, #60a5fa 100%);
                    box-shadow: 0 0 15px #60a5fa;
                    animation: frame-stars-twinkle 3s ease-in-out infinite;
                    overflow: hidden;
                }
                .frame-stars::after {
                    content: '✨';
                    position: absolute;
                    font-size: 10px;
                    animation: star-float 4s linear infinite;
                }
                .frame-void-pulse {
                    border: 4px solid #7c3aed;
                    background: radial-gradient(circle, #2e1065 0%, transparent 70%);
                    box-shadow: 0 0 20px #7c3aed, inset 0 0 15px #000;
                    animation: frame-void 3s ease-in-out infinite;
                }
                .frame-emerald-glow {
                    border: 4px solid #10b981;
                    box-shadow: 0 0 15px #10b981, 0 0 30px #059669;
                    animation: frame-glow 1.5s infinite;
                }
                .frame-ice-crystal {
                    border: 4px solid #bae6fd;
                    background: linear-gradient(135deg, rgba(255,255,255,0.4) 0%, transparent 50%);
                    box-shadow: 0 0 15px #7dd3fc, inset 0 0 10px #e0f2fe;
                    animation: frame-ice 4s linear infinite;
                }
                .frame-neon-wave {
                    border: 4px solid #22d3ee;
                    animation: frame-wave 3s linear infinite;
                    box-shadow: 0 0 10px #22d3ee, 0 0 20px #d946ef;
                }
                .frame-lightning-bolt {
                    border: 4px solid #fff;
                    box-shadow: 0 0 10px #60a5fa, 0 0 25px #3b82f6;
                    animation: frame-lightning 0.5s step-end infinite;
                }
                .frame-gold-royal {
                    border: 4px solid #fbbf24;
                    background: linear-gradient(45deg, #fbbf24 0%, #f59e0b 50%, #fbbf24 100%);
                    box-shadow: 0 0 10px #d97706;
                    animation: frame-gold-shine 2s linear infinite;
                }
                .frame-ruby-flare {
                    border: 4px solid #be123c;
                    box-shadow: 0 0 20px #e11d48;
                    animation: frame-fire-pulse 1s ease-in-out infinite;
                }
                .frame-phantom-fade {
                    border: 4px solid #94a3b8;
                    box-shadow: 0 0 15px #cbd5e1;
                    animation: frame-phantom 4s ease-in-out infinite;
                }
                .frame-cyber-orange {
                    border: 4px solid #f97316;
                    box-shadow: 0 0 15px #f97316, 0 0 5px #fff;
                    animation: frame-cyber-flicker 1.5s infinite;
                }
                .frame-magic-pink {
                    border: 4px solid #f472b6;
                    box-shadow: 0 0 15px #f472b6;
                    background: radial-gradient(circle, #fdf2f8 0%, transparent 60%);
                    animation: frame-stars-twinkle 2s infinite;
                }

                @keyframes frame-glow {
                    0%, 100% { opacity: 0.8; transform: scale(1.25); }
                    50% { opacity: 1; transform: scale(1.35); }
                }
                @keyframes frame-rotate {
                    from { transform: rotate(0deg) scale(1.25); }
                    to { transform: rotate(360deg) scale(1.25); }
                }
                @keyframes frame-fire-pulse {
                    0%, 100% { box-shadow: 0 0 15px #f97316, 0 0 30px #ef4444; }
                    50% { box-shadow: 0 0 25px #fbbf24, 0 0 50px #f97316; }
                }
                @keyframes frame-cyber-flicker {
                    0%, 100% { border-color: #06b6d4; box-shadow: 0 0 10px #06b6d4; }
                    50% { border-color: #ec4899; box-shadow: 0 0 15px #ec4899; }
                    20%, 80% { opacity: 1; }
                    25%, 75% { opacity: 0.7; }
                }
                @keyframes frame-stars-twinkle {
                    0%, 100% { opacity: 0.6; }
                    50% { opacity: 1; }
                }
                @keyframes star-float {
                    0% { transform: translate(-100%, -100%) rotate(0deg); }
                    100% { transform: translate(200%, 200%) rotate(360deg); }
                }
                @keyframes frame-void {
                    0%, 100% { transform: scale(1.25); box-shadow: 0 0 20px #7c3aed; }
                    50% { transform: scale(1.35); box-shadow: 0 0 40px #4c1d95; }
                }
                @keyframes frame-ice {
                    0% { filter: hue-rotate(0deg); }
                    100% { filter: hue-rotate(20deg); }
                }
                @keyframes frame-wave {
                    0% { border-color: #22d3ee; }
                    50% { border-color: #d946ef; }
                    100% { border-color: #22d3ee; }
                }
                @keyframes frame-lightning {
                    0%, 90% { opacity: 1; }
                    95% { opacity: 0.2; box-shadow: 0 0 80px #fff; }
                }
                @keyframes frame-gold-shine {
                    0% { filter: brightness(1); }
                    50% { filter: brightness(1.5); }
                    100% { filter: brightness(1); }
                }
                @keyframes frame-phantom {
                    0%, 100% { opacity: 0.3; transform: scale(1.2); }
                    50% { opacity: 0.9; transform: scale(1.3); }
                }
            `}} />
        </div>
    );
}
