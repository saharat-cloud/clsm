import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/api/supabaseClient';
import { Bell, X, Upload, Gift, Pencil } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

const TYPE_CONFIG = {
    new_submission: {
        icon: Upload,
        bg: '#eff6ff',
        border: '#bfdbfe',
        barColor: '#3b82f6',
        iconBg: 'linear-gradient(135deg,#3b82f6,#4338ca)',
    },
    edit_request: {
        icon: Pencil,
        bg: '#fffbeb',
        border: '#fde68a',
        barColor: '#f59e0b',
        iconBg: 'linear-gradient(135deg,#f59e0b,#f97316)',
    },
    new_claim: {
        icon: Gift,
        bg: '#faf5ff',
        border: '#d8b4fe',
        barColor: '#a855f7',
        iconBg: 'linear-gradient(135deg,#a855f7,#7c3aed)',
    },
    default: {
        icon: Bell,
        bg: '#eef2ff',
        border: '#a5b4fc',
        barColor: '#6366f1',
        iconBg: 'linear-gradient(135deg,#6366f1,#8b5cf6)',
    },
};

const DURATION = 7000;

function TeacherToast({ notif, onDismiss }) {
    const navigate = useNavigate();
    const [progress, setProgress] = useState(100);
    const [visible, setVisible] = useState(false);
    const intervalRef = useRef(null);
    const timeoutRef = useRef(null);

    const cfg = TYPE_CONFIG[notif.type] || TYPE_CONFIG.default;
    const Icon = cfg.icon;

    const dismiss = useCallback(() => {
        setVisible(false);
        clearInterval(intervalRef.current);
        clearTimeout(timeoutRef.current);
        setTimeout(() => onDismiss(notif._key), 400);
    }, [notif._key, onDismiss]);

    useEffect(() => {
        requestAnimationFrame(() => setVisible(true));
        const start = Date.now();
        intervalRef.current = setInterval(() => {
            setProgress(Math.max(0, 100 - ((Date.now() - start) / DURATION) * 100));
        }, 40);
        timeoutRef.current = setTimeout(dismiss, DURATION);
        return () => {
            clearInterval(intervalRef.current);
            clearTimeout(timeoutRef.current);
        };
    }, [dismiss]);

    const handleClick = () => {
        if (notif.type === 'new_submission' || notif.type === 'edit_request') {
            navigate('/teacher/notifications');
        } else if (notif.type === 'new_claim') {
            navigate('/teacher/points');
        }
        dismiss();
    };

    return (
        <div 
            onClick={handleClick}
            style={{
                transition: 'all 0.4s cubic-bezier(0.34,1.56,0.64,1)',
                opacity: visible ? 1 : 0,
                transform: visible ? 'translateY(0) scale(1)' : 'translateY(-20px) scale(0.92)',
                width: '100%',
                pointerEvents: 'all',
                cursor: 'pointer',
            }}
        >
            <div style={{
                background: cfg.bg,
                border: `1.5px solid ${cfg.border}`,
                borderRadius: '16px',
                boxShadow: '0 8px 32px rgba(0,0,0,0.18)',
                overflow: 'hidden',
            }}>
                <div style={{ height: '3px', background: cfg.barColor }} />
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', padding: '14px 14px 10px' }}>
                    <div style={{
                        flexShrink: 0, width: 40, height: 40, borderRadius: '12px',
                        background: cfg.iconBg, display: 'flex', alignItems: 'center',
                        justifyContent: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                    }}>
                        <Icon size={20} color="white" />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontWeight: 700, fontSize: '14px', margin: 0, color: '#111827', lineHeight: 1.3 }}>
                            {notif.title}
                        </p>
                        {notif.message && (
                            <p style={{ fontSize: '12px', color: '#6b7280', margin: '3px 0 0', lineHeight: 1.5 }}>
                                {notif.message}
                            </p>
                        )}
                    </div>
                    <button onClick={dismiss} style={{
                        flexShrink: 0, width: 24, height: 24, borderRadius: '50%',
                        border: 'none', background: 'rgba(0,0,0,0.06)', cursor: 'pointer',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9ca3af',
                    }}>
                        <X size={13} />
                    </button>
                </div>
                <div style={{ height: '3px', background: 'rgba(0,0,0,0.06)', margin: '0 14px 10px' }}>
                    <div style={{
                        height: '100%', borderRadius: '2px', background: cfg.barColor,
                        width: `${progress}%`, transition: 'width 40ms linear',
                    }} />
                </div>
            </div>
        </div>
    );
}

export default function TeacherRealtimeToast() {
    const { user } = useAuth();
    const [toasts, setToasts] = useState([]);

    const dismiss = useCallback((key) => {
        setToasts(prev => prev.filter(t => t._key !== key));
    }, []);

    const addToast = useCallback((type, title, message) => {
        const _key = `${Date.now()}_${Math.random()}`;
        setToasts(prev => [...prev, { _key, type, title, message }]);
    }, []);

    useEffect(() => {
        // Cache of known IDs so we don't show on initial load
        let knownSubmissions = null;
        let knownClaims = null;
        let initialized = false;

        // Pre-load existing IDs so we only notify for NEW ones
        async function init() {
            try {
                const [subs, claims] = await Promise.all([
                    base44.entities.Submission.filter({ teacher_id: user.id }),
                    base44.entities.RewardClaim.filter({ teacher_id: user.id }),
                ]);
                knownSubmissions = new Set(subs.map(s => s.id));
                knownClaims = new Set(claims.map(c => c.id));
                initialized = true;
            } catch {
                initialized = true;
            }
        }
        init();

        // Listen for new submissions
        const subChannel = supabase
            .channel(`teacher-realtime-submissions-${user.id}`)
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'submissions', filter: `teacher_id=eq.${user.id}` }, async (payload) => {
                if (!initialized) return;
                const sub = payload.new;
                if (knownSubmissions?.has(sub.id)) return;
                knownSubmissions?.add(sub.id);

                // Fetch student info
                try {
                    const students = await base44.entities.Student.filter({ student_id: sub.student_id });
                    const std = students[0];
                    const assignments = await base44.entities.Assignment.filter({ id: sub.assignment_id });
                    const asgn = assignments[0];
                    const name = std ? `${std.first_name} ${std.last_name}` : sub.student_id;
                    addToast('new_submission', '📥 นักเรียนส่งงานใหม่', `${name} ส่งงาน "${asgn?.title || ''}"`);
                } catch {
                    addToast('new_submission', '📥 นักเรียนส่งงานใหม่', `รหัส ${sub.student_id}`);
                }
            })
            // Listen for edit requests AND resubmissions (UPDATE)
            .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'submissions', filter: `teacher_id=eq.${user.id}` }, async (payload) => {
                if (!initialized) return;
                const sub = payload.new;
                const old = payload.old;
                
                const isNewEditReq = sub.edit_request_status === 'pending' && old.edit_request_status !== 'pending';
                const isResubmission = sub.status === 'submitted' && old.status !== 'submitted';
                
                if (!isNewEditReq && !isResubmission) return;

                try {
                    const students = await base44.entities.Student.filter({ student_id: sub.student_id });
                    const std = students[0];
                    const assignments = await base44.entities.Assignment.filter({ id: sub.assignment_id });
                    const asgn = assignments[0];
                    const name = std ? `${std.first_name} ${std.last_name}` : sub.student_id;
                    
                    if (isNewEditReq) {
                        addToast('edit_request', '✏️ นักเรียนขอแก้ไขงาน', `${name} ขอแก้ไขงาน "${asgn?.title || ''}"`);
                    } else if (isResubmission) {
                        addToast('new_submission', '📥 นักเรียนส่งงาน (แก้ไข)', `${name} ส่งงาน "${asgn?.title || ''}" แล้ว`);
                    }
                } catch {
                    if (isNewEditReq) {
                        addToast('edit_request', '✏️ นักเรียนขอแก้ไขงาน', `รหัส ${sub.student_id}`);
                    } else if (isResubmission) {
                        addToast('new_submission', '📥 นักเรียนส่งงาน (แก้ไข)', `รหัส ${sub.student_id}`);
                    }
                }
            })
            .subscribe();

        // Listen for new reward claims
        const claimChannel = supabase
            .channel(`teacher-realtime-claims-${user.id}`)
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'reward_claims', filter: `teacher_id=eq.${user.id}` }, async (payload) => {
                if (!initialized) return;
                const claim = payload.new;
                if (knownClaims?.has(claim.id)) return;
                knownClaims?.add(claim.id);

                try {
                    const students = await base44.entities.Student.filter({ student_id: claim.student_id });
                    const std = students[0];
                    const name = std ? `${std.first_name} ${std.last_name}` : claim.student_id;
                    addToast('new_claim', '🎁 คำขอแลกรางวัลใหม่', `${name} ต้องการแลกรางวัล `);
                } catch {
                    addToast('new_claim', '🎁 คำขอแลกรางวัลใหม่', `รหัส ${claim.student_id}`);
                }
            })
            .subscribe();

        return () => {
            supabase.removeChannel(subChannel);
            supabase.removeChannel(claimChannel);
        };
    }, [addToast]);

    if (toasts.length === 0) return null;

    return (
        <div style={{
            position: 'fixed', top: '16px', left: '50%', transform: 'translateX(-50%)',
            zIndex: 99999, display: 'flex', flexDirection: 'column', gap: '10px',
            alignItems: 'center', pointerEvents: 'none',
            width: 'min(calc(100vw - 32px), 420px)',
        }}>
            {toasts.map(t => (
                <TeacherToast key={t._key} notif={t} onDismiss={dismiss} />
            ))}
        </div>
    );
}
