import { useEffect, useState } from 'react';

/**
 * VirusTheme component for the Teacher's Virus Laboratory.
 * Applies a toxic green/black aesthetic to the entire page when mounted.
 */
export default function VirusTheme({ active = true }) {
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        if (active) {
            // Short delay to trigger fade in after mount
            const timer = setTimeout(() => setVisible(true), 50);
            document.body.classList.add('virus-theme-active');
            return () => {
                clearTimeout(timer);
                setVisible(false);
                document.body.classList.remove('virus-theme-active');
            };
        }
    }, [active]);

    return (
        <>
            <style dangerouslySetInnerHTML={{ __html: `
                :root {
                    --virus-green: 142 70% 50%;
                    --virus-bg: 144 30% 2%;
                    --virus-border: 142 70% 30%;
                }

                body.virus-theme-active {
                    background-color: hsl(var(--virus-bg)) !important;
                    transition: background-color 1.0s ease-in-out !important;
                }

                /* Layout overrides */
                .virus-theme-active .bg-background,
                .virus-theme-active .bg-card,
                .virus-theme-active header,
                .virus-theme-active aside,
                .virus-theme-active [class*="bg-card"] {
                    background-color: hsl(var(--virus-bg)) !important;
                    border-color: hsl(var(--virus-green) / 0.2) !important;
                }

                .virus-theme-active header {
                    backdrop-filter: blur(12px) !important;
                    background-color: hsl(var(--virus-bg) / 0.8) !important;
                }

                .virus-theme-active {
                    --background: var(--virus-bg) !important;
                    --foreground: 0 0% 100% !important; /* Brighter for readability */
                    --card: 144 30% 4% !important;
                    --card-foreground: 142 70% 95% !important;
                    --popover: 144 30% 5% !important;
                    --popover-foreground: 0 0% 100% !important;
                    --primary: var(--virus-green) !important;
                    --primary-foreground: 144 30% 5% !important;
                    --secondary: 144 30% 10% !important;
                    --secondary-foreground: 142 70% 90% !important;
                    --muted: 144 30% 8% !important;
                    --muted-foreground: 142 20% 60% !important;
                    --accent: 144 30% 12% !important;
                    --accent-foreground: 142 70% 80% !important;
                    --destructive: 0 84% 60% !important;
                    --destructive-foreground: 0 0% 100% !important;
                    --border: 142 40% 15% !important;
                    --input: 142 40% 15% !important;
                    --ring: var(--virus-green) !important;
                }

                /* Improve specific text elements */
                .virus-theme-active .text-muted-foreground {
                    color: hsl(142 20% 70%) !important;
                }
                
                .virus-theme-active h1, 
                .virus-theme-active h2, 
                .virus-theme-active h3, 
                .virus-theme-active .font-bold {
                    color: hsl(var(--virus-green)) !important;
                    text-shadow: 0 0 10px hsl(var(--virus-green) / 0.3);
                }

                .virus-theme-active .text-foreground,
                .virus-theme-active p {
                    color: #ffffff !important;
                    font-weight: 500 !important;
                }

                /* Ensure icons are visible */
                .virus-theme-active .lucide {
                    filter: drop-shadow(0 0 5px hsl(var(--virus-green) / 0.5));
                }

                /* Custom scrollbar for theme */
                .virus-theme-active ::-webkit-scrollbar {
                    width: 6px;
                    height: 6px;
                }
                .virus-theme-active ::-webkit-scrollbar-track {
                    background: hsl(var(--virus-bg));
                }
                .virus-theme-active ::-webkit-scrollbar-thumb {
                    background: hsl(var(--virus-green) / 0.3);
                    border-radius: 10px;
                }
                .virus-theme-active ::-webkit-scrollbar-thumb:hover {
                    background: hsl(var(--virus-green) / 0.5);
                }

                /* Overlay effects */
                .virus-overlay {
                    position: fixed;
                    inset: 0;
                    pointer-events: none;
                    z-index: 9999;
                    background: radial-gradient(circle at center, transparent 30%, hsl(var(--virus-bg) / 0.7) 100%);
                    opacity: ${visible ? 1 : 0};
                    transition: opacity 1.5s ease-in-out;
                }

                .virus-scanlines {
                    position: fixed;
                    inset: 0;
                    pointer-events: none;
                    z-index: 9998;
                    background: linear-gradient(
                        rgba(18, 16, 16, 0) 50%,
                        rgba(0, 0, 0, 0.1) 50%
                    ), linear-gradient(
                        90deg,
                        rgba(255, 0, 0, 0.02),
                        rgba(0, 255, 0, 0.01),
                        rgba(0, 0, 255, 0.02)
                    );
                    background-size: 100% 4px, 3px 100%;
                    opacity: ${visible ? 0.3 : 0};
                    transition: opacity 2s ease-in-out;
                }

                @keyframes virus-pulse {
                    0% { box-shadow: 0 0 0 0 hsl(var(--virus-green) / 0.4); }
                    70% { box-shadow: 0 0 0 10px hsl(var(--virus-green) / 0); }
                    100% { box-shadow: 0 0 0 0 hsl(var(--virus-green) / 0); }
                }

                .virus-theme-active .virus-card-pulse {
                    animation: virus-pulse 2s infinite;
                }
            `}} />
            <div className="virus-overlay" />
            <div className="virus-scanlines" />
        </>
    );
}
