import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { Skull, AlertTriangle } from 'lucide-react';
import { alerts } from '@/utils/alerts';

export default function ZombieTheme() {
    const [isInfected, setIsInfected] = useState(false);
    const [infections, setInfections] = useState([]);

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) return;
        const std = JSON.parse(session);

        async function checkInfection() {
            try {
                // Get student ID from session, handle potential case differences
                const studentId = std.student_id?.toString().trim();
                if (!studentId) return;

                const { data: infs, error } = await supabase
                    .from('infections')
                    .select('*')
                    .eq('is_active', true)
                    .or(`student_id.eq.${studentId},student_id.ilike.${studentId}`);
                
                if (error) throw error;
                
                setInfections(infs || []);
                setIsInfected((infs || []).length > 0);
            } catch (err) {
                console.error('CheckInfection error:', err);
            }
        }
        
        checkInfection();

        // Listen for realtime infections or cures
        const channel = supabase.channel('student-zombie-theme')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'infections' }, () => {
                checkInfection();
            })
            .subscribe();

        return () => { supabase.removeChannel(channel); };
    }, []);

    // Show center-screen notification when status changes
    useEffect(() => {
        if (isInfected) {
            const session = localStorage.getItem('student_session');
            const studentId = JSON.parse(session || '{}')?.student_id;
            
            base44.entities.Student.filter({ student_id: studentId })
                .then(res => {
                    const name = res[0]?.first_name || 'คุณ';
                    alerts.error(
                        '☣️ ตรวจพบเชื้อไวรัส!',
                        `${name} ติดเชื้อไวรัสในระบบแล้ว! รีบเคลียร์งานที่ได้รับมอบหมายเพื่อกำจัดไวรัสก่อนจะสายเกินไป`
                    );
                });
        }
    }, [isInfected]);

    // Track previous state to catch the "Cure" event
    useEffect(() => {
        if (isInfected) {
            document.body.classList.add('zombie-infected');
        } else {
            document.body.classList.remove('zombie-infected');
        }
        
        // Cleanup on unmount
        return () => {
            document.body.classList.remove('zombie-infected');
        };
    }, [isInfected]);

    const prevInfected = useRef(false);
    useEffect(() => {
        if (prevInfected.current === true && isInfected === false) {
            alerts.success(
                '🎉 คุณหายเป็นปกติแล้ว!',
                'ยินดีด้วย! คุณได้รับการรักษาพยาบาลและพ้นขีดอันตรายแล้ว รักษาสุขภาพด้วยนะ'
            );
        }
        prevInfected.current = isInfected;
    }, [isInfected]);

    return (
        <div className={`fixed inset-0 pointer-events-none z-[9997] transition-all duration-1000 ${isInfected ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
            {/* Persistent Global Styles with Transitions */}
            <style dangerouslySetInnerHTML={{ __html: `
                body {
                    transition: padding-top 0.5s ease, background-color 1.0s ease, color 1.0s ease !important;
                }

                /* Ensure all themed elements transition smoothly */
                body.zombie-infected *, body:not(.zombie-infected) * {
                    transition: background-color 1.0s ease, border-color 1.0s ease, color 1.0s ease, box-shadow 1.0s ease !important;
                }
                
                body.zombie-infected {
                    padding-top: 32px !important;
                    --background: 140 30% 6% !important;
                    --foreground: 120 60% 80% !important;
                    --card: 140 40% 8% !important;
                    --card-foreground: 120 60% 80% !important;
                    --popover: 140 40% 8% !important;
                    --popover-foreground: 120 60% 80% !important;
                    --primary: 142 70% 40% !important;
                    --primary-foreground: 144 0% 0% !important;
                    --secondary: 144 30% 12% !important;
                    --secondary-foreground: 120 60% 80% !important;
                    --muted: 144 30% 10% !important;
                    --muted-foreground: 120 20% 50% !important;
                    --accent: 144 40% 15% !important;
                    --accent-foreground: 142 70% 60% !important;
                    --destructive: 0 80% 50% !important;
                    --destructive-foreground: 0 0% 100% !important;
                    --border: 144 40% 15% !important;
                    --input: 144 40% 15% !important;
                    --ring: 142 70% 40% !important;
                }

                @keyframes glitch {
                    0% { transform: translate(0) }
                    20% { transform: translate(-2px, 2px) }
                    40% { transform: translate(-2px, -2px) }
                    60% { transform: translate(2px, 2px) }
                    80% { transform: translate(2px, -2px) }
                    100% { transform: translate(0) }
                }
                .zombie-glitch { animation: glitch 0.3s ease infinite alternate; }
            `}} />

            {/* Zombie Overlay Effects */}
            <div className="absolute inset-0 pointer-events-none z-0" 
                style={{ background: 'radial-gradient(circle at center, transparent 40%, rgba(10, 30, 10, 0.8) 100%)' }} />
            
            <div className="absolute inset-0 opacity-10 pointer-events-none z-0" 
                style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }} />

            {/* Persistent Warning Banner */}
            <div className="fixed top-0 left-0 right-0 z-[10000] bg-red-600 text-white backdrop-blur-md border-b-2 border-green-500 border-dashed p-1.5 shadow-[0_5px_20px_rgba(220,38,38,0.5)] pointer-events-auto">
                <div className="flex items-center justify-center gap-4 animate-pulse text-xs">
                    <Skull size={18} className="text-white" />
                    <p className="font-black tracking-[0.2em] uppercase">
                        🚨 คุณติดไวรัส! รีบเคลียร์งานเดี๋ยวนี้ 🚨
                    </p>
                    <Skull size={18} className="text-white" />
                </div>
            </div>

            {/* Status Floating Widget */}
            <div className="fixed bottom-24 right-4 z-[9990] bg-black/80 border-2 border-primary text-primary backdrop-blur-md p-4 rounded-2xl shadow-[0_0_30px_rgba(34,197,94,0.3)] max-w-xs pointer-events-auto">
                <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center zombie-glitch">
                        <AlertTriangle size={24} className="text-primary" />
                    </div>
                    <div>
                        <h3 className="font-black text-sm text-primary/90">ติดเชื้อ (INFECTED)</h3>
                        <p className="text-xs text-primary/70">{infections.length} อาการแทรกซ้อน</p>
                    </div>
                </div>
                <div className="text-xs text-primary/60 mt-2 space-y-1">
                    {infections.map((inf, i) => (
                        <div key={i} className="flex justify-between border-t border-primary/20 pt-1">
                            <span>หากไม่แก้วันนี้:</span>
                            <span className="text-red-500 font-bold">หัก {inf.penalty_amount} {inf.penalty_type === 'points' ? 'แต้ม' : 'คะแนน'}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
