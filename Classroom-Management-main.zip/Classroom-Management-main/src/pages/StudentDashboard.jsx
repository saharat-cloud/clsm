import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Clock } from 'lucide-react';

export default function StudentDashboard() {
    const navigate = useNavigate();
    const [student, setStudent] = useState(null);
    const [classrooms, setClassrooms] = useState([]);
    const [pendingCount, setPendingCount] = useState(0);

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) { navigate('/student/login'); return; }
        const std = JSON.parse(session);

        async function load() {
            // 1. Fetch semesters first to know which one is active
            const allSemesters = await base44.entities.Semester.filter({ teacher_id: 'kanit_admin' });
            const activeSem = allSemesters.find(s => s.is_active) || allSemesters[0];

            const adminFilter = {
                ...(activeSem ? { 
                    semester_academic_year: activeSem.academic_year, 
                    semester_number: activeSem.semester 
                } : {}),
                teacher_id: 'kanit_admin'
            };

            // 2. Fetch student data and classrooms managed by admin
            const freshStudent = await base44.entities.Student.filter({ 
                student_id: std.student_id,
                teacher_id: 'kanit_admin'
            });
            const s = freshStudent[0] || std;
            setStudent(s);
            localStorage.setItem('student_session', JSON.stringify(s));

            const myCls = await base44.entities.Classroom.filter(adminFilter);
            const myEnrolledCls = myCls.filter(c => (c.student_ids || []).includes(s.id));
            const myClsIds = myEnrolledCls.map(c => c.id);
            setClassrooms(myEnrolledCls);

            if (myClsIds.length > 0) {
                const [asgns, subs] = await Promise.all([
                    base44.entities.Assignment.filter({ classroom_id: { in: myClsIds } }),
                    base44.entities.Submission.filter({ student_id: s.student_id }),
                ]);
                const submittedIds = new Set(subs.map(sub => sub.assignment_id));
                const pending = asgns.filter(a => !submittedIds.has(a.id) && new Date(a.due_date) > new Date());
                setPendingCount(pending.length);
            } else {
                setPendingCount(0);
            }
        }
        load();
    }, []);

    if (!student) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-3xl mx-auto px-4 py-8">
                <div className="flex items-start justify-between mb-8">
                    <div>
                        <p className="text-muted-foreground text-sm">ยินดีต้อนรับ</p>
                        <h1 className="text-2xl font-bold">{student.first_name} {student.last_name}</h1>
                        <p className="text-muted-foreground text-sm font-mono">{student.student_id}</p>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl p-6 mb-6">
                    <p className="text-sm opacity-80">แต้มสะสมของคุณ</p>
                    <p className="text-5xl font-bold mt-1">{student.total_points || 0}</p>
                    <p className="text-sm opacity-80 mt-1">แต้ม</p>
                    {pendingCount > 0 && (
                        <div className="mt-4 flex items-center gap-2 bg-white/20 rounded-xl px-3 py-2">
                            <Clock size={16} />
                            <p className="text-sm">มี {pendingCount} งานที่ยังไม่ส่ง</p>
                        </div>
                    )}
                </div>

                <div className="mb-4">
                    <p className="text-sm text-muted-foreground mb-2">ห้องเรียนของฉัน ({classrooms.length} ห้อง)</p>
                    <div className="flex flex-wrap gap-2">
                        {classrooms.map(c => (
                            <span key={c.id} className="px-3 py-1 bg-accent text-accent-foreground rounded-full text-sm">{c.name}</span>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}