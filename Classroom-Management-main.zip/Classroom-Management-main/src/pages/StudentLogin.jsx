import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { BookOpen } from 'lucide-react';

export default function StudentLogin() {
    const [form, setForm] = useState({ student_id: '', password: '' });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    async function handleSubmit(e) {
        e.preventDefault();
        setError(''); setLoading(true);
        const students = await base44.entities.Student.filter({ 
            student_id: form.student_id,
            teacher_id: 'kanit_admin' 
        });
        const student = students[0];
        if (!student || student.password !== form.password) {
            setError('รหัสนักเรียนหรือรหัสผ่านไม่ถูกต้อง');
            setLoading(false);
            return;
        }
        localStorage.setItem('student_session', JSON.stringify(student));
        navigate('/student');
        setLoading(false);
    }

    return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
            <div className="w-full max-w-sm">
                <div className="text-center mb-8">
                    <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                        <BookOpen size={32} className="text-primary" />
                    </div>
                    <h1 className="text-2xl font-bold">เข้าสู่ระบบนักเรียน</h1>
                    <p className="text-muted-foreground text-sm mt-1">กรุณาใส่รหัสนักเรียนและรหัสผ่าน</p>
                </div>

                <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium mb-1">รหัสนักเรียน</label>
                            <input required value={form.student_id} onChange={e => setForm({ ...form, student_id: e.target.value })}
                                placeholder="เช่น 12345"
                                className="w-full border border-input rounded-xl px-3 py-2.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">รหัสผ่าน</label>
                            <input type="password" required value={form.password} onChange={e => setForm({ ...form, password: e.target.value })}
                                className="w-full border border-input rounded-xl px-3 py-2.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                        </div>
                        {error && <p className="text-destructive text-sm text-center">{error}</p>}
                        <button type="submit" disabled={loading}
                            className="w-full bg-primary text-primary-foreground rounded-xl py-2.5 text-sm font-medium hover:opacity-90 transition disabled:opacity-50 mt-2">
                            {loading ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบ'}
                        </button>
                    </form>
                </div>

                <p className="text-center text-xs text-muted-foreground mt-6">
                    <a href="/teacher/login" className="hover:text-foreground transition">เข้าสู่ระบบครู →</a>
                </p>
            </div>
        </div>
    );
}