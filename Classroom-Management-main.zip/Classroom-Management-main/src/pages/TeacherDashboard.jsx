import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { BookOpen, Users, ChevronRight, Layers, CalendarDays, Settings, ClipboardList, BarChart3, Table, Trophy, Bell, Bug, Shield } from 'lucide-react';
import { useSemester } from '@/lib/SemesterContext';
import { useAuth } from '@/lib/AuthContext';

export default function TeacherDashboard() {
    const { user } = useAuth();
    const { activeSemester, allSemesters, setActiveSemester, semesterLabel, loading: semLoading } = useSemester();
    const [stats, setStats] = useState({ subjects: 0, classrooms: 0, students: 0, assignments: 0, ungraded: 0 });

    useEffect(() => {
        async function loadStats() {
            if (!user) return;
            const isAdmin = user.role === 'admin';
            
            // If no semester is active, we should probably show 0 or only orphaned data.
            // For now, let's show 0 to encourage selecting a semester.
            if (!activeSemester) {
                setStats({ subjects: 0, classrooms: 0, students: 0, assignments: 0, ungraded: 0 });
                return;
            }

            const baseFilter = {
                semester_academic_year: activeSemester.academic_year, 
                semester_number: activeSemester.semester 
            };

            const userFilter = {
                ...baseFilter,
                teacher_id: user.id
            };

            // Admin sees everything in the semester, Teacher sees only their own
            const statsFilter = isAdmin ? baseFilter : userFilter;

            const [subjects, classrooms, students, assignments, submissions] = await Promise.all([
                base44.entities.Subject.filter(statsFilter),
                base44.entities.Classroom.filter(statsFilter),
                base44.entities.Student.filter(statsFilter),
                base44.entities.Assignment.filter(statsFilter),
                base44.entities.Submission.filter({ ...statsFilter, status: 'submitted' }),
            ]);

            const clsIds = new Set(classrooms.map(c => c.id));
            const aMap = Object.fromEntries(assignments.map(a => [a.id, a]));
            const pendingCount = submissions.filter(sub => {
                const a = aMap[sub.assignment_id];
                return a && clsIds.has(a.classroom_id);
            }).length;

            setStats({
                subjects: subjects.length,
                classrooms: classrooms.length,
                students: students.length,
                assignments: assignments.filter(a => clsIds.has(a.classroom_id)).length,
                ungraded: pendingCount,
            });
        }
        if (!semLoading) loadStats();
    }, [activeSemester, semLoading, user]);

    const steps = [
        { step: 1, to: '/teacher/classrooms', icon: Layers, label: 'ระดับชั้น & ห้องเรียน', desc: 'เพิ่มห้องเรียนก่อน', count: stats.classrooms, unit: 'ห้อง', color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-900/20', badge: 'bg-emerald-100 text-emerald-700' },
        { step: 2, to: '/teacher/students', icon: Users, label: 'นักเรียน', desc: 'เพิ่มนักเรียนและเลือกห้อง', count: stats.students, unit: 'คน', color: 'text-blue-600', bg: 'bg-blue-50 dark:bg-blue-900/20', badge: 'bg-blue-100 text-blue-700' },
        { step: 3, to: '/teacher/subjects', icon: BookOpen, label: 'รายวิชา', desc: 'เพิ่มวิชาให้ห้องเรียน', count: stats.subjects, unit: 'วิชา', color: 'text-violet-600', bg: 'bg-violet-50 dark:bg-violet-900/20', badge: 'bg-violet-100 text-violet-700' },
    ];

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-5xl mx-auto px-4 py-8 pb-8">
                {/* Semester Banner */}
                <div className="bg-gradient-to-r from-primary/10 to-violet-500/10 border border-primary/20 rounded-2xl px-5 py-4 mb-6 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                            <CalendarDays size={20} className="text-primary" />
                        </div>
                        <div>
                            <p className="text-xs text-muted-foreground">ปีการศึกษาปัจจุบัน</p>
                            <p className="font-bold text-foreground">
                                {semLoading ? '...' : (semesterLabel(activeSemester) || 'ยังไม่ได้เลือกปีการศึกษา')}
                            </p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap justify-end">
                        {allSemesters.filter(s => s.id !== activeSemester?.id).slice(0, 2).map(s => (
                            <button key={s.id} onClick={() => setActiveSemester(s)}
                                className="text-xs border border-border bg-card px-3 py-1.5 rounded-xl hover:bg-muted transition">
                                {semesterLabel(s)}
                            </button>
                        ))}
                        <Link to="/teacher/semesters"
                            className="flex items-center gap-1 text-xs border border-border bg-card px-3 py-1.5 rounded-xl hover:bg-muted transition">
                            <Settings size={12} /> จัดการ
                        </Link>
                    </div>
                </div>

                {/* Header */}
                <div className="flex items-center justify-between mb-10">
                    <div>
                        <p className="text-sm text-muted-foreground mb-1">ยินดีต้อนรับ, {user?.first_name || 'คุณครู'}</p>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-violet-600 bg-clip-text text-transparent">
                            ระบบจัดการชั้นเรียน
                        </h1>
                    </div>
                </div>

                {/* Stats row */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
                    {[
                        { label: 'ห้องเรียน', value: stats.classrooms, color: 'text-emerald-600' },
                        { label: 'นักเรียน', value: stats.students, color: 'text-blue-600' },
                        { label: 'รายวิชา', value: stats.subjects, color: 'text-violet-600' },
                        { label: 'งานมอบหมาย', value: stats.assignments, color: 'text-orange-600' },
                    ].map(s => (
                        <div key={s.label} className="bg-card rounded-2xl p-4 shadow-sm border border-border">
                            <p className="text-muted-foreground text-xs mb-1">{s.label}</p>
                            <p className={`text-3xl font-bold ${s.color}`}>{s.value}</p>
                        </div>
                    ))}
                </div>

                {/* Quick Action Shortcuts */}
                <div className="mb-8">
                    <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">ทางลัด</p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                        {[
                            { to: '/teacher/assignments', icon: ClipboardList, label: 'งานมอบหมาย', color: 'text-blue-600', bg: 'bg-blue-50 dark:bg-blue-950/30' },
                            { to: '/teacher/scores', icon: BarChart3, label: 'คะแนนเก็บ', color: 'text-violet-600', bg: 'bg-violet-50 dark:bg-violet-950/30' },
                            { to: '/teacher/assignment-tracker', icon: Table, label: 'ติดตามงาน', color: 'text-teal-600', bg: 'bg-teal-50 dark:bg-teal-950/30' },
                            { to: '/teacher/points', icon: Trophy, label: 'แต้มสะสมรางวัล', color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-950/30' },
                            { to: '/teacher/ranking', icon: Trophy, label: 'แรงค์กิ้ง', color: 'text-yellow-600', bg: 'bg-yellow-50 dark:bg-yellow-950/30' },
                            { to: '/teacher/student-status', icon: Bell, label: 'สถานะงาน', color: 'text-orange-600', bg: 'bg-orange-50 dark:bg-orange-950/30' },
                            { to: '/teacher/notifications', icon: Bell, label: 'รอตรวจ', color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-950/30', badge: stats.ungraded },
                        ].map(item => (
                            <Link key={item.to} to={item.to}
                                className="group bg-card border border-border rounded-2xl p-4 flex items-center gap-3 hover:shadow-md hover:border-primary/30 transition-all">
                                <div className={`w-9 h-9 rounded-xl ${item.bg} flex items-center justify-center flex-shrink-0`}>
                                    <item.icon size={18} className={item.color} />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-semibold truncate">{item.label}</p>
                                </div>
                                {item.badge > 0 && (
                                    <span className="bg-destructive text-destructive-foreground text-[10px] font-bold px-1.5 py-0.5 rounded-full flex-shrink-0">
                                        {item.badge}
                                    </span>
                                )}
                            </Link>
                        ))}
                        <Link to="/teacher/virus"
                            className="group bg-zinc-950 border border-green-500/30 rounded-2xl p-4 flex items-center gap-3 hover:shadow-lg hover:border-green-500/50 transition-all relative overflow-hidden">
                            <div className="absolute inset-0 bg-green-500/5 pointer-events-none" />
                            <div className={`w-9 h-9 rounded-xl bg-green-500/20 flex items-center justify-center flex-shrink-0 border border-green-500/30`}>
                                <Bug size={18} className="text-green-500" />
                            </div>
                            <div className="flex-1 min-w-0 relative z-10">
                                <p className="text-sm font-bold text-green-500 truncate">ห้องทดลองไวรัส</p>
                                <p className="text-[10px] text-green-500/60 font-medium">ควบคุม & วิจัย</p>
                            </div>
                            <ChevronRight size={14} className="text-green-500/40" />
                        </Link>
                    </div>
                </div>

                {/* Admin Section */}
                {user?.role === 'admin' && (
                    <div className="mb-8">
                        <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">ส่วนผู้ดูแลระบบ</p>
                        <div className="grid md:grid-cols-3 gap-4">
                            <Link to="/teacher/manage-accounts"
                                className="group bg-primary/5 rounded-2xl p-5 shadow-sm border border-primary/20 hover:shadow-lg hover:border-primary transition-all relative overflow-hidden"
                            >
                                <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
                                <div className="flex items-start gap-3 pl-2">
                                    <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                                        <Shield size={22} className="text-primary" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="font-semibold text-foreground">จัดการบัญชีครู</p>
                                        <p className="text-xs text-muted-foreground">เพิ่ม ลบ หรือแก้ไขข้อมูลครูคนอื่น</p>
                                    </div>
                                    <ChevronRight size={16} className="text-muted-foreground group-hover:text-primary transition mt-1" />
                                </div>
                            </Link>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}