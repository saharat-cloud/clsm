import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Lock } from 'lucide-react';

export default function TeacherLogin() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const { login } = useAuth();
    const navigate = useNavigate();

    async function handleSubmit(e) {
        e.preventDefault();
        setError(''); 
        setLoading(true);
        
        try {
            // Find teacher by username
            const [teacher] = await base44.entities.Teacher.filter({ username });
            
            if (!teacher || teacher.password !== password) {
                setError('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
                setLoading(false);
                return;
            }
            
            login(teacher); // set session with full teacher data
            navigate('/'); // redirect to dashboard
        } catch (err) {
            console.error('Login error:', err);
            setError('เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล กรุณาตรวจสอบว่ารันสคริปต์ SQL ล่าสุดหรือยัง');
            setLoading(false);
        }
    }

    return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
            <div className="w-full max-w-sm">
                <div className="text-center mb-8">
                    <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                        <Lock size={32} className="text-primary" />
                    </div>
                    <h1 className="text-2xl font-bold">เข้าสู่ระบบสำหรับผู้สอน</h1>
                    <p className="text-muted-foreground text-sm mt-1">กรุณาเข้าใช้งานด้วยบัญชีของคุณ</p>
                </div>

                <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium mb-1">ชื่อผู้ใช้ (Username)</label>
                            <input 
                                type="text" required 
                                value={username} onChange={e => setUsername(e.target.value)}
                                className="w-full border border-input rounded-xl px-3 py-2.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" 
                                placeholder="เช่น kanit"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">รหัสผ่าน</label>
                            <input 
                                type="password" required 
                                value={password} onChange={e => setPassword(e.target.value)}
                                className="w-full border border-input rounded-xl px-3 py-2.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" 
                                placeholder="••••••••"
                            />
                        </div>
                        {error && <p className="text-destructive text-sm text-center">{error}</p>}
                        <button type="submit" disabled={loading}
                            className="w-full bg-primary text-primary-foreground rounded-xl py-2.5 text-sm font-medium hover:opacity-90 transition disabled:opacity-50 mt-2">
                            {loading ? 'กำลังตรวจสอบ...' : 'เข้าสู่ระบบ'}
                        </button>
                    </form>
                </div>

                <p className="text-center text-xs text-muted-foreground mt-6">
                    <a href="/student/login" className="hover:text-foreground transition">← ไปยังหน้านักเรียน</a>
                </p>
            </div>
        </div>
    );
}
