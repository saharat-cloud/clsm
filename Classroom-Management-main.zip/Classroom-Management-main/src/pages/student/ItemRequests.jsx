import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { alerts } from '@/utils/alerts';
import { HeartPulse, CheckCircle2, XCircle, Send, Users, ShieldPlus, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function ItemRequests() {
    const [requests, setRequests] = useState([]);
    const [myItems, setMyItems] = useState([]);
    const [classmates, setClassmates] = useState([]);
    const [studentsMap, setStudentsMap] = useState({});
    const [activeClassroomObj, setActiveClassroomObj] = useState(null);
    const [loading, setLoading] = useState(true);
    
    const [studentTextId, setStudentTextId] = useState('');
    const [requestModal, setRequestModal] = useState({ show: false, targetId: '' });

    useEffect(() => {
        loadData();
        const channel = supabase.channel('item-requests')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'item_requests' }, () => loadData())
            .on('postgres_changes', { event: '*', schema: 'public', table: 'student_items' }, () => loadData())
            .subscribe();
        return () => { supabase.removeChannel(channel); };
    }, []);

    async function loadData() {
        try {
            const session = localStorage.getItem('student_session');
            if (!session) return;
            const std = JSON.parse(session);
            
            const [freshStd] = await base44.entities.Student.filter({ 
                student_id: std.student_id,
                teacher_id: 'kanit_admin'
            });
            const s = freshStd || std;
            const textId = s.student_id;
            const dbId = s.id;
            setStudentTextId(textId);

            // Fetch admin-managed classrooms
            const allCls = await base44.entities.Classroom.filter({ teacher_id: 'kanit_admin' });
            const myClassrooms = allCls.filter(c => (c.student_ids || []).includes(dbId));
            const myClassroomIds = myClassrooms.map(c => c.id);

            if (myClassroomIds.length > 0) {
                const [allReqs, allItems, allStds] = await Promise.all([
                    base44.entities.ItemRequest.filter({ classroom_id: { in: myClassroomIds } }),
                    base44.entities.StudentItem.filter({ student_id: textId }),
                    base44.entities.Student.filter({ teacher_id: 'kanit_admin' })
                ]);

                // Determine my active classroom
                const activeClassroom = myClassrooms[0] || null;
                setActiveClassroomObj(activeClassroom);
                if (activeClassroom) localStorage.setItem('active_classroom_id', activeClassroom.id);

                // Create map of student IDs to names for easy lookup
                const sMap = {};
                allStds.forEach(st => sMap[st.student_id] = `${st.first_name} ${st.last_name}`);
                setStudentsMap(sMap);

                // Filter requests related to me
                setRequests(allReqs.filter(r => r.requester_id === textId || r.target_student_id === textId || r.target_student_id === 'all').sort((a,b)=>new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));
                setMyItems(allItems.filter(i => i.quantity > 0));

                // Find classmates across all my shared rooms
                const classmateDbIds = new Set();
                myClassrooms.forEach(c => (c.student_ids || []).forEach(id => {
                    if (id !== dbId) classmateDbIds.add(id);
                }));

                setClassmates(allStds.filter(st => classmateDbIds.has(st.id)));
            } else {
                setRequests([]);
                setMyItems([]);
                setClassmates([]);
                setStudentsMap({});
            }
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    async function handleApprove(req) {
        if (!await alerts.confirm('ส่งยาให้เพื่อน', `ยืนยันการให้ยาต้านไวรัสแก่ ${studentsMap[req.requester_id] || req.requester_id}?`)) return;

        try {
            // Check inventory
            const antivirus = myItems.find(i => i.item_type === 'antivirus' && i.quantity > 0);
            if (!antivirus) return alerts.error('คุณไม่มียาที่จะให้เพื่อน');

            // 1. Deduct item
            await base44.entities.StudentItem.update(antivirus.id, { quantity: antivirus.quantity - 1 });
            
            // 2. Cure friend's infection
            const friendInfs = await base44.entities.Infection.filter({ student_id: req.requester_id, is_active: true });
            if (friendInfs.length > 0) {
                await base44.entities.Infection.update(friendInfs[0].id, { is_active: false, cured_at: new Date().toISOString() });
            }

            // 3. Mark request approved
            await base44.entities.ItemRequest.update(req.id, { status: 'approved' });

            // 4. Send Notification
            await base44.entities.Notification.create({
                student_id: req.requester_id,
                title: '🎉 ได้รับยาช่วยชีวิต!',
                message: `${studentsMap[studentTextId] || 'เพื่อนคนหนึ่ง'} ได้ส่งยาให้คุณและรักษาไวรัสของคุณแล้ว!`,
                type: 'request_approved',
                is_read: false
            });

            alerts.success('ส่งยาให้เพื่อนสำเร็จ เพื่อนรอดตายแล้ว!');
            loadData();
        } catch(e) {
            alerts.error('พบข้อผิดพลาด', e.message);
        }
    }

    async function handleReject(req) {
        if (!await alerts.confirmDanger('ปฏิเสธการขอ', 'ปฏิเสธไม่ต้องส่งยาให้เพื่อนใช่หรือไม่?')) return;
        try {
            if (req.target_student_id === 'all') {
                // Individual rejection for group requests
                const rejectedBy = Array.isArray(req.rejected_by) ? req.rejected_by : [];
                if (!rejectedBy.includes(studentTextId)) {
                    await base44.entities.ItemRequest.update(req.id, { 
                        rejected_by: [...rejectedBy, studentTextId] 
                    });
                }
            } else {
                // Global rejection for targeted requests
                await base44.entities.ItemRequest.update(req.id, { status: 'rejected' });
            }
            
            await base44.entities.Notification.create({
                student_id: req.requester_id,
                title: '💔 คำขอยาถูกปฏิเสธ',
                message: `${studentsMap[studentTextId] || 'เพื่อน'} ขอโทษทีไม่มียาให้จริงๆ`,
                type: 'request_rejected',
                is_read: false
            });

            alerts.success('ปฏิเสธคำขอเรียบร้อยแล้ว');
            loadData();
        } catch(e) {
            alerts.error('พบข้อผิดพลาด', e.message);
        }
    }

    async function handleCreateRequest(e) {
        e.preventDefault();
        try {
            await base44.entities.ItemRequest.create({
                requester_id: studentTextId,
                target_student_id: requestModal.targetId || 'all',
                classroom_id: activeClassroomObj?.id || localStorage.getItem('active_classroom_id'),
                teacher_id: activeClassroomObj?.teacher_id || 'kanit_admin',
                item_type: 'antivirus',
                status: 'pending'
            });

            if (requestModal.targetId && requestModal.targetId !== 'all') {
                await base44.entities.Notification.create({
                    student_id: requestModal.targetId,
                    title: '🆘 เพื่อนขอยาต้านไวรัส!',
                    message: `${studentsMap[studentTextId] || studentTextId} กำลังจะแย่ ต้องการยาต้านไวรัสด่วน!`,
                    type: 'item_request',
                    is_read: false
                });
            }

            alerts.success('ส่งคำขอยาเรียบร้อยแล้ว รอคนใจบุญมาช่วยนะ');
            setRequestModal({ show: false, targetId: '' });
            loadData();
        } catch(e) {
            alerts.error('พบข้อผิดพลาด', e.message);
        }
    }

    const hasAntivirus = myItems.some(i => i.item_type === 'antivirus' && i.quantity > 0);
    const sentRequests = requests.filter(r => r.requester_id === studentTextId);
    const receivedRequests = requests.filter(r => {
        if (r.requester_id === studentTextId) return false;
        if (!['pending', 'approved'].includes(r.status)) return false;
        // Hide if I already rejected this 'all' request
        if (r.target_student_id === 'all' && Array.isArray(r.rejected_by) && r.rejected_by.includes(studentTextId)) return false;
        return true;
    });

    return (
        <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-tr from-pink-500/10 to-red-500/5 p-6 rounded-3xl border border-red-500/20">
                <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-red-100 text-red-500 rounded-2xl flex items-center justify-center shadow-inner">
                        <HeartPulse size={30} />
                    </div>
                    <div>
                        <h1 className="text-2xl font-black text-red-600 dark:text-red-400">คำขอยา(ต้านไวรัส)</h1>
                        <p className="text-sm text-muted-foreground mt-0.5 font-medium">แบ่งปันหรือขอความช่วยเหลือจากเพื่อนร่วมห้อง</p>
                    </div>
                </div>
                
                <button onClick={() => setRequestModal({ show: true, targetId: '' })}
                    className="flex items-center justify-center gap-2 bg-red-500 text-white px-5 py-3 rounded-2xl font-bold hover:bg-red-600 transition shadow-[0_4px_15px_rgba(239,68,68,0.3)]">
                    <Send size={18} /> ขอยาจากเพื่อน
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Received Requests */}
                <div className="bg-card border border-border rounded-3xl overflow-hidden shadow-sm">
                    <div className="p-5 border-b border-border bg-muted/30 flex items-center gap-2">
                        <Users size={20} className="text-blue-500" />
                        <h2 className="font-bold">เพื่อนที่กำลังต้องการความช่วยเหลือ</h2>
                        <span className="ml-auto bg-blue-100 text-blue-600 px-2.5 py-0.5 rounded-full text-xs font-bold">
                            {receivedRequests.filter(r=>r.status==='pending').length}
                        </span>
                    </div>

                    <div className="p-2 space-y-2 max-h-[500px] overflow-y-auto">
                        {receivedRequests.length === 0 && !loading && (
                            <p className="text-center text-sm text-muted-foreground py-10">ไม่มีคำขอความช่วยเหลือในขณะนี้</p>
                        )}
                        {receivedRequests.map(req => (
                            <div key={req.id} className="p-4 bg-background border border-border rounded-2xl transition hover:border-blue-500/30">
                                <div className="flex items-start justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm">
                                            {studentsMap[req.requester_id]?.charAt(0) || 'เพื่อน'}
                                        </div>
                                        <div>
                                            <p className="font-bold text-sm">{studentsMap[req.requester_id] || req.requester_id}</p>
                                            <p className="text-xs text-muted-foreground">ขอ <span className="font-bold text-red-500">ยาต้านไวรัส</span> x1</p>
                                        </div>
                                    </div>
                                    <div className="text-[10px] text-muted-foreground">
                                        {new Date(req.created_at).toLocaleString('th-TH', { hour: '2-digit', minute: '2-digit' })} น.
                                    </div>
                                </div>
                                
                                {req.status === 'pending' ? (
                                    <div className="flex gap-2 mt-4 ml-13">
                                        {!hasAntivirus ? (
                                            <p className="text-xs text-amber-600 bg-amber-50 px-3 py-1.5 rounded-lg w-full text-center border border-amber-100">คุณไม่มียาต้านไวรัสในกระเป๋า</p>
                                        ) : (
                                            <>
                                                <button onClick={() => handleApprove(req)} title="ให้ยาเพื่อน"
                                                    className="flex-1 bg-green-500 text-white rounded-xl py-2 flex items-center justify-center font-bold hover:bg-green-600 transition">
                                                    <CheckCircle2 size={18} /> ให้ยา
                                                </button>
                                                <button onClick={() => handleReject(req)} title="ปฏิเสธ"
                                                    className="w-12 bg-background border-2 border-border text-muted-foreground rounded-xl flex items-center justify-center hover:bg-muted transition">
                                                    <XCircle size={18} />
                                                </button>
                                            </>
                                        )}
                                    </div>
                                ) : (
                                    <div className="mt-3 text-xs font-bold text-green-500 bg-green-50 px-3 py-2 rounded-xl flex items-center gap-2 w-max">
                                        <CheckCircle2 size={16} /> ส่งยาให้แล้ว
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>

                {/* Sent Requests */}
                <div className="bg-card border border-border rounded-3xl overflow-hidden shadow-sm">
                    <div className="p-5 border-b border-border bg-muted/30 flex items-center gap-2">
                        <Send size={18} className="text-purple-500" />
                        <h2 className="font-bold">คำขอของฉัน</h2>
                    </div>

                    <div className="p-2 space-y-2 max-h-[500px] overflow-y-auto">
                        {sentRequests.length === 0 && !loading && (
                            <p className="text-center text-sm text-muted-foreground py-10">คุณยังไม่ได้ขอยาจากใคร</p>
                        )}
                        {sentRequests.map(req => (
                            <div key={req.id} className="p-4 bg-background border border-border rounded-2xl flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center">
                                        <ShieldPlus size={20} />
                                    </div>
                                    <div>
                                        <p className="font-bold text-sm">
                                            {req.target_student_id === 'all' 
                                                ? 'ขอความช่วยเหลือจากทุกคน' 
                                                : `ขอยาจาก ${studentsMap[req.target_student_id] || req.target_student_id}`}
                                        </p>
                                        <p className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-1">
                                            สถานะ: {
                                                req.status === 'pending' ? <span className="text-amber-500 font-bold">รอคอย...</span> :
                                                req.status === 'approved' ? <span className="text-green-500 font-bold">มีคนให้ยาแล้ว!</span> :
                                                <span className="text-red-500 font-bold">ถูกปฏิเสธ</span>
                                            }
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {requestModal.show && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
                    <div className="bg-card w-full max-w-sm rounded-[2rem] shadow-2xl p-6 border border-border">
                        <div className="w-16 h-16 bg-red-100 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Send size={30} className="ml-1" />
                        </div>
                        <h2 className="text-xl font-black text-center mb-1">ขอยาต้านไวรัส</h2>
                        <p className="text-sm text-muted-foreground text-center mb-6">ส่งคำขอไปหาเพื่อนในห้อง เพื่อขอยา 1 ชิ้น</p>

                        <form onSubmit={handleCreateRequest} className="space-y-4">
                            <div>
                                <label className="block text-sm font-bold mb-2">ส่งคำขอถึงใคร? <span className="text-red-500">*</span></label>
                                <select value={requestModal.targetId} onChange={e => setRequestModal({...requestModal, targetId: e.target.value})}
                                    className="w-full bg-background border-2 border-input px-4 py-3 rounded-2xl text-sm focus:outline-none focus:border-red-500 focus:ring-4 focus:ring-red-500/20 appearance-none font-medium">
                                    <option value="all">📢 ประกาศขอความช่วยเหลือจากทุกคนในห้อง</option>
                                    {classmates.map(c => (
                                        <option key={c.student_id} value={c.student_id}>🎯 พุ่งเป้าไปที่: {c.first_name} {c.last_name}</option>
                                    ))}
                                </select>
                            </div>

                            <button type="submit" className="w-full bg-red-500 text-white font-black py-4 rounded-xl mt-4 shadow-[0_4px_15px_rgba(239,68,68,0.3)] hover:opacity-90 transition flex items-center justify-center gap-2">
                                ส่งคำขอด่วน! <ArrowRight size={20} />
                            </button>
                            <button type="button" onClick={() => setRequestModal({ show: false, targetId: '' })} 
                                className="w-full mt-2 font-bold text-muted-foreground hover:text-foreground py-2 transition text-sm">
                                ยกเลิก
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
