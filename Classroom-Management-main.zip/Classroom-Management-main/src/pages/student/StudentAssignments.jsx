import { useState, useEffect } from 'react';
import { supabase } from '@/api/supabaseClient';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Upload, Clock, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { alerts } from '@/utils/alerts';

export default function StudentAssignments() {
    const navigate = useNavigate();
    const { toast } = useToast();
    const [student, setStudent] = useState(null);
    const [assignments, setAssignments] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [submissions, setSubmissions] = useState([]);
    const [submitting, setSubmitting] = useState(null);
    const [files, setFiles] = useState([]);
    const [note, setNote] = useState('');
    const [uploading, setUploading] = useState(false);
    const [tab, setTab] = useState('pending');

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) { navigate('/student/login'); return; }
        const std = JSON.parse(session);
        setStudent(std);
        loadData(std);

        // Realtime: listen for updates to this student's submissions
        // (edit_request approval/rejection, grading, etc.)
        const channel = supabase
            .channel('student-submissions-updates')
            .on('postgres_changes',
                { event: 'UPDATE', schema: 'public', table: 'submissions' },
                (payload) => {
                    const updated = payload.new;
                    if (updated.student_id === std.student_id) {
                        // Refresh submissions list silently
                        setSubmissions(prev =>
                            prev.map(s => s.id === updated.id ? { ...s, ...updated } : s)
                        );
                    }
                }
            )
            .subscribe();

        return () => { supabase.removeChannel(channel); };
    }, []);

    async function loadData(std) {
        // Classrooms and student rosters are managed by the admin
        const allCls = await base44.entities.Classroom.filter({ teacher_id: 'kanit_admin' });
        const myCls = allCls.filter(c => (c.student_ids || []).includes(std.id));
        const myClsIds = myCls.map(c => c.id);
        
        setClassrooms(myCls);

        if (myClsIds.length > 0) {
            const [asgns, subs, userSubs] = await Promise.all([
                base44.entities.Assignment.filter({ classroom_id: { in: myClsIds } }),
                base44.entities.Subject.filter({ classroom_id: { in: myClsIds } }),
                base44.entities.Submission.filter({ student_id: std.student_id }),
            ]);
            setAssignments(asgns);
            setSubjects(subs);
            setSubmissions(userSubs);
        } else {
            setAssignments([]);
            setSubjects([]);
            setSubmissions([]);
        }
    }

    const subMap = Object.fromEntries(submissions.map(s => [s.assignment_id, s]));
    const clsMap = Object.fromEntries(classrooms.map(c => [c.id, c]));
    const subjMap = Object.fromEntries(subjects.map(s => [s.id, s]));
    const now = new Date();

    const pending = assignments.filter(a => !subMap[a.id] && (a.late_policy !== 'no_submit' || new Date(a.due_date) > now));
    const submitted = assignments.filter(a => subMap[a.id]);

    async function handleSubmit(e) {
        e.preventDefault();
        if (!submitting) return;
        setUploading(true);
        const fileUrls = [];
        try {
            for (const f of files) {
                const ext = f.name.split('.').pop() || '';
                const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${ext}`;
                const filePath = `${student.student_id}/${fileName}`;
                
                const { error: uploadError } = await supabase.storage
                    .from('assignments')
                    .upload(filePath, f);
                
                if (uploadError) throw uploadError;

                const { data } = supabase.storage
                    .from('assignments')
                    .getPublicUrl(filePath);
                
                fileUrls.push(data.publicUrl);
            }

            const isLate = new Date(submitting.due_date) < now;
            const existingSub = subMap[submitting.id];

            if (existingSub) {
                await base44.entities.Submission.update(existingSub.id, {
                    file_urls: fileUrls,
                    note,
                    submitted_at: new Date().toISOString(),
                    is_late: isLate,
                    status: 'submitted',
                    score: null, 
                    feedback: null,
                    edit_request_status: null // Reset after successful edit
                });
            } else {
                await base44.entities.Submission.create({
                    assignment_id: submitting.id,
                    student_id: student.student_id,
                    classroom_id: submitting.classroom_id,
                    submitted_at: new Date().toISOString(),
                    file_urls: fileUrls,
                    note,
                    is_late: isLate,
                    status: 'submitted',
                });
            }

            // 🏆 Grant EXP Reward
            if (submitting.exp_reward > 0) {
                const newExp = (student.total_exp || 0) + submitting.exp_reward;
                await base44.entities.Student.update(student.id, { total_exp: newExp });
                
                // Also update local student state for immediate UI feedback
                const updatedStudent = { ...student, total_exp: newExp };
                setStudent(updatedStudent);
                localStorage.setItem('student_session', JSON.stringify(updatedStudent));

                toast({
                    title: `ได้รับ +${submitting.exp_reward} EXP!`,
                    description: `สะสมครบเพื่อเลเวลอัพและแลกของรางวัล`,
                });
            }
            
            // ☣️ Auto-Cure Virus Logic
            const infs = await base44.entities.Infection.filter({ student_id: student.student_id, assignment_id: submitting.id, is_active: true });
            if (infs.length > 0) {
                const targetInf = infs[0];
                
                // Grant Reward
                if (targetInf.reward_amount > 0) {
                    if (targetInf.reward_type === 'points') {
                        await base44.entities.PointTransaction.create({
                            student_id: student.student_id,
                            points: targetInf.reward_amount,
                            reason: `เอาชนะไวรัส! (ส่งงาน ${submitting.title})`
                        });
                    } else {
                        await base44.entities.ScoreRecord.create({
                            student_id: student.student_id,
                            classroom_id: submitting.classroom_id,
                            subject_id: null,
                            score: targetInf.reward_amount,
                            max_score: 0,
                            score_type: 'รางวัลไวรัส',
                            note: `เอาชนะไวรัสจากงาน ${submitting.title}`
                        });
                    }
                }

                await base44.entities.Infection.update(targetInf.id, { is_active: false, cured_at: new Date().toISOString() });
                
                await base44.entities.Notification.create({
                    student_id: student.student_id,
                    title: '⚡ ไวรัสถูกทำลาย!',
                    message: `ยินดีด้วย! คุณส่งงานสำเร็จและทำลายไวรัสได้แล้ว${targetInf.reward_amount > 0 ? ` ได้รับ ${targetInf.reward_amount} ${targetInf.reward_type === 'points' ? 'แต้ม' : 'คะแนน'}` : ''}`,
                    type: 'virus_cured',
                    is_read: false
                });
            }

            setSubmitting(null); setFiles([]); setNote('');
            loadData(student);
        } catch (err) {
            console.error(err);
            toast({
                title: "เกิดข้อผิดพลาด",
                description: err.message || "ไม่สามารถอัปโหลดไฟล์ได้ กรุณาลองใหม่",
                variant: "destructive"
            });
        } finally {
            setUploading(false);
        }
    }

    function canSubmit(a) {
        if (subMap[a.id]) return subMap[a.id].edit_request_status === 'approved';
        if (a.late_policy === 'no_submit' && new Date(a.due_date) < now) return false;
        return true;
    }

    async function handleRequestEdit(sub) {
        if (!await alerts.confirm('ขอแก้ไขงาน', 'ยืนยันการขออนุญาตแก้ไขงาน?')) return;
        try {
            await base44.entities.Submission.update(sub.id, {
                edit_request_status: 'pending'
            });
            toast({ title: 'ส่งคำขอแก้ไขงานแล้ว', description: 'กรุณารอครูอนุมัติ' });
            loadData(student);
        } catch (error) {
            toast({ title: 'เกิดข้อผิดพลาด', description: error.message, variant: 'destructive' });
        }
    }

    const displayList = tab === 'pending' ? pending : submitted;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-3xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/student" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <h1 className="text-2xl font-bold">งานของฉัน</h1>
                </div>

                <div className="flex bg-muted rounded-xl p-1 mb-6">
                    {[{ key: 'pending', label: `📋 งานค้าง (${pending.length})` }, { key: 'submitted', label: `✅ ส่งแล้ว (${submitted.length})` }].map(t => (
                        <button key={t.key} onClick={() => setTab(t.key)}
                            className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${tab === t.key ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`}>
                            {t.label}
                        </button>
                    ))}
                </div>

                <div className="grid gap-3">
                    {displayList.map(a => {
                        const sub = subMap[a.id];
                        const isPast = new Date(a.due_date) < now;
                        const cls = clsMap[a.classroom_id];
                        const subj = subjMap[a.subject_id];
                        return (
                            <div key={a.id} className="bg-card border border-border rounded-2xl p-5">
                                <div className="flex items-start justify-between gap-3 mb-2">
                                    <div>
                                        <p className="font-semibold">{a.title}</p>
                                        <p className="text-xs text-muted-foreground">
                                            {cls?.name} {subj?.name ? `• ${subj.name}` : ''}
                                        </p>
                                    </div>
                                    {sub ? (
                                        sub.is_late ? (
                                            <span className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded-full whitespace-nowrap">ส่งเลท</span>
                                        ) : sub.status === 'graded' ? (
                                            <span className="text-xs bg-green-100 text-green-600 px-2 py-1 rounded-full whitespace-nowrap">ตรวจแล้ว</span>
                                        ) : (
                                            <span className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded-full whitespace-nowrap">ส่งแล้ว</span>
                                        )
                                    ) : isPast ? (
                                        <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded-full whitespace-nowrap">เลยกำหนด</span>
                                    ) : (
                                        <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full whitespace-nowrap">รอส่ง</span>
                                    )}
                                </div>
                                {a.description && <p className="text-sm text-muted-foreground mb-2">{a.description}</p>}
                                <p className="text-xs text-muted-foreground flex items-center gap-1">
                                    <Clock size={12} /> กำหนดส่ง: {new Date(a.due_date).toLocaleString('th-TH')}
                                </p>
                                {sub?.status === 'graded' && (
                                    <div className="mt-3 p-3 bg-green-50 rounded-xl">
                                        <p className="text-sm font-bold text-green-700">คะแนน: {sub.score}/{a.max_score}</p>
                                        {sub.feedback && <p className="text-xs text-green-600 mt-1">{sub.feedback}</p>}
                                    </div>
                                )}
                                {canSubmit(a) && (
                                    <button onClick={() => { setSubmitting(a); setFiles([]); setNote(sub?.note || ''); }}
                                        className="mt-3 flex items-center gap-2 text-sm bg-primary text-primary-foreground px-4 py-2 rounded-xl hover:opacity-90 transition w-full justify-center sm:w-auto">
                                        <Upload size={14} /> {sub ? 'ส่งงานใหม่ (Resubmit)' : 'ส่งงาน'}
                                    </button>
                                )}
                                {sub && sub.edit_request_status === 'pending' && (
                                    <button disabled className="mt-3 flex items-center gap-2 text-sm bg-amber-100 text-amber-700 px-4 py-2 rounded-xl w-full justify-center sm:w-auto cursor-not-allowed">
                                        <Clock size={14} /> รอครูอนุมัติการแก้ไข
                                    </button>
                                )}
                                {sub && (!sub.edit_request_status || sub.edit_request_status === 'rejected') && (
                                    <button onClick={() => handleRequestEdit(sub)}
                                        className="mt-3 flex items-center gap-2 text-sm border border-primary text-primary px-4 py-2 rounded-xl hover:bg-primary/10 transition w-full justify-center sm:w-auto">
                                        ขอแก้ไขงาน
                                    </button>
                                )}
                            </div>
                        );
                    })}
                    {displayList.length === 0 && (
                        <div className="text-center py-16 text-muted-foreground">
                            {tab === 'pending' ? 'ไม่มีงานค้าง 🎉' : 'ยังไม่มีงานที่ส่ง'}
                        </div>
                    )}
                </div>
            </div>

            {submitting && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                    <div className="bg-card rounded-2xl shadow-xl w-full max-w-md p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-lg font-bold">ส่งงาน: {submitting.title}</h2>
                            <button onClick={() => setSubmitting(null)}><X size={20} className="text-muted-foreground" /></button>
                        </div>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-1">แนบไฟล์</label>
                                <label className="block border-2 border-dashed border-border rounded-xl p-4 text-center cursor-pointer hover:border-primary/50 transition">
                                    <Upload size={24} className="mx-auto text-muted-foreground mb-1" />
                                    <p className="text-sm text-muted-foreground">{files.length > 0 ? `${files.length} ไฟล์` : 'คลิกเพื่อเลือกไฟล์'}</p>
                                    <input type="file" multiple className="hidden" onChange={e => setFiles(Array.from(e.target.files))} />
                                </label>
                                {files.length > 0 && (
                                    <ul className="mt-2 space-y-1">
                                        {files.map((f, i) => <li key={i} className="text-xs text-muted-foreground">• {f.name}</li>)}
                                    </ul>
                                )}
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-1">หมายเหตุ (ถ้ามี)</label>
                                <textarea value={note} onChange={e => setNote(e.target.value)} rows={2}
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
                            </div>
                            <div className="flex gap-3">
                                <button type="button" onClick={() => setSubmitting(null)} className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted transition">ยกเลิก</button>
                                <button type="submit" disabled={uploading}
                                    className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition disabled:opacity-50">
                                    {uploading ? 'กำลังอัพโหลด...' : 'ส่งงาน'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}