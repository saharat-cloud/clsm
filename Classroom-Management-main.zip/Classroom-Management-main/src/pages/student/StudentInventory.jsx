import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { alerts } from '@/utils/alerts';
import { Package, ShieldPlus, UserPlus, HeartPulse, Send, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function StudentInventory() {
    const [items, setItems] = useState([]);
    const [infections, setInfections] = useState([]);
    const [classmates, setClassmates] = useState([]);
    const [infectedClassmates, setInfectedClassmates] = useState([]);
    const [loading, setLoading] = useState(true);
    const [studentId, setStudentId] = useState('');
    const [studentTextId, setStudentTextId] = useState('');

    const [useModal, setUseModal] = useState({ show: false, item: null, target: 'self' }); // target: 'self' | 'friend'
    const [selectedFriend, setSelectedFriend] = useState('');

    useEffect(() => {
        loadData();
        const channel = supabase.channel('student-inventory')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'student_items' }, () => loadData())
            .on('postgres_changes', { event: '*', schema: 'public', table: 'infections' }, () => loadData())
            .subscribe();
        return () => { supabase.removeChannel(channel); };
    }, []);

    async function loadData() {
        try {
            const session = localStorage.getItem('student_session');
            if (!session) return;
            const std = JSON.parse(session);
            
            const [freshStd] = await base44.entities.Student.filter({ 
                student_id: std.student_id,
                teacher_id: 'kanit_admin'
            });
            const s = freshStd || std;
            const textId = s.student_id;
            const dbId = s.id;
            setStudentId(dbId);
            setStudentTextId(textId);

            const [myItems, myInfs, rooms] = await Promise.all([
                base44.entities.StudentItem.filter({ student_id: textId }),
                base44.entities.Infection.filter({ student_id: textId, is_active: true }),
                base44.entities.Classroom.filter({ teacher_id: 'kanit_admin' })
            ]);

            setItems(myItems.filter(i => i.quantity > 0));
            setInfections(myInfs);

            // Find classmates to help across all shared rooms
            const myClassrooms = rooms.filter(c => (c.student_ids || []).includes(dbId));
            const myClassroomIds = myClassrooms.map(c => c.id);
            const classmateDbIds = new Set();
            myClassrooms.forEach(c => (c.student_ids || []).forEach(id => {
                if (id !== dbId) classmateDbIds.add(id);
            }));

            if (classmateDbIds.size > 0) {
                const [allStds, allInfs] = await Promise.all([
                    base44.entities.Student.filter({ id: { in: [...classmateDbIds] } }),
                    base44.entities.Infection.filter({ is_active: true, classroom_id: { in: myClassroomIds } })
                ]);
                const mates = allStds.filter(st => classmateDbIds.has(st.id));
                setClassmates(mates);
                
                // Which classmates are infected?
                const infectedMates = mates.filter(m => allInfs.some(inf => inf.student_id === m.student_id));
                setInfectedClassmates(infectedMates);
            }
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    async function handleUseItem(e) {
        e.preventDefault();
        const { item, target } = useModal;
        
        try {
            if (target === 'self') {
                if (infections.length === 0) return alerts.error('คุณไม่ได้ติดไวรัส ไม่จำเป็นต้องใช้ยา');
                
                const targetInf = infections[0]; // just cure the oldest active one
                
                // Grant Reward
                if (targetInf.reward_amount > 0) {
                    if (targetInf.reward_type === 'points') {
                        await base44.entities.PointTransaction.create({
                            student_id: studentTextId,
                            points: targetInf.reward_amount,
                            reason: `รอดพ้นจากไวรัส!`
                        });
                    } else {
                        await base44.entities.ScoreRecord.create({
                            student_id: studentTextId,
                            classroom_id: targetInf.classroom_id,
                            subject_id: null,
                            score: targetInf.reward_amount,
                            max_score: 0,
                            score_type: 'รางวัลไวรัส',
                            note: 'รอดพ้นจากไวรัส'
                        });
                    }
                }

                await base44.entities.Infection.update(targetInf.id, { is_active: false, cured_at: new Date().toISOString() });
                await base44.entities.StudentItem.update(item.id, { quantity: item.quantity - 1 });
                await base44.entities.Notification.create({
                    student_id: studentTextId,
                    title: '💊 ใช้ยาสำเร็จ!',
                    message: `คุณได้รักษาไวรัส${targetInf.reward_amount > 0 ? ' และได้รับรางวัลแล้ว' : ''}`,
                    type: 'item_used',
                    is_read: false
                });
                alerts.success(`รักษาตัวเองเรียบร้อยแล้ว${targetInf.reward_amount > 0 ? ` พร้อมรับ ${targetInf.reward_amount} ${targetInf.reward_type === 'points' ? 'แต้ม' : 'คะแนน'}` : ''}`);
                
            } else if (target === 'friend') {
                if (!selectedFriend) return alerts.error('กรุณาเลือกเพื่อนที่จะรักษา');
                
                // Verify friend is infected
                const friendInfs = await base44.entities.Infection.filter({ student_id: selectedFriend, is_active: true });
                if (friendInfs.length === 0) return alerts.error('เพื่อนคนนี้ไม่ได้ติดไวรัส หรือถูกรักษาไปแล้ว');

                const targetInf = friendInfs[0];
                
                // Grant Reward to Friend
                if (targetInf.reward_amount > 0) {
                    if (targetInf.reward_type === 'points') {
                        await base44.entities.PointTransaction.create({
                            student_id: selectedFriend,
                            points: targetInf.reward_amount,
                            reason: `รอดพ้นจากไวรัส (เพื่อนช่วย!)`
                        });
                    } else {
                        await base44.entities.ScoreRecord.create({
                            student_id: selectedFriend,
                            classroom_id: targetInf.classroom_id,
                            subject_id: null,
                            score: targetInf.reward_amount,
                            max_score: 0,
                            score_type: 'รางวัลไวรัส',
                            note: 'เพื่อนช่วยรักษานักเรียน'
                        });
                    }
                }

                await base44.entities.Infection.update(targetInf.id, { is_active: false, cured_at: new Date().toISOString() });
                await base44.entities.StudentItem.update(item.id, { quantity: item.quantity - 1 });
                
                // Notify Friend
                await base44.entities.Notification.create({
                    student_id: selectedFriend,
                    title: '💖 เพื่อนรักษ์เพื่อน',
                    message: `เพื่อนของคุณได้ใช้ยาต้านไวรัสเพื่อรักษาคุณให้หายติดเชื้อแล้ว!${targetInf.reward_amount > 0 ? ' คุณได้รับรางวัลด้วยนะ' : ''}`,
                    type: 'item_received',
                    is_read: false
                });

                alerts.success('รักษาเพื่อนเรียบร้อยแล้ว! เพื่อนคุณต้องขอบคุณแน่ๆ');
            }
            
            setUseModal({ show: false, item: null, target: 'self' });
            setSelectedFriend('');
            loadData();
        } catch(err) {
            alerts.error('พบข้อผิดพลาด', err.message);
        }
    }

    function getItemDetails(type) {
        if (type === 'antivirus') return { name: 'ยาต้านไวรัส', icon: ShieldPlus, color: 'text-green-500', bg: 'bg-green-100', borderColor: 'border-green-200' };
        return { name: 'ไอเทมทั่วไป', icon: Package, color: 'text-blue-500', bg: 'bg-blue-100', borderColor: 'border-blue-200' };
    }

    return (
        <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-primary/10 text-primary rounded-2xl flex items-center justify-center">
                        <Package size={24} />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold">กระเป๋าไอเทมของฉัน</h1>
                        <p className="text-sm text-muted-foreground mt-0.5">ยาต้านไวรัส และไอเทมพิเศษที่ได้รับ</p>
                    </div>
                </div>
                
                <Link to="/student/item-requests" className="flex items-center justify-center gap-2 bg-background border border-border px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-muted transition shadow-sm">
                    <HeartPulse size={18} className="text-red-500" />
                    คำขอยาจากเพื่อน
                </Link>
            </div>

            {infections.length > 0 && (
                <div className="bg-destructive/10 border border-destructive/20 rounded-2xl p-5 flex items-start gap-4 animate-in fade-in slide-in-from-top-2">
                    <AlertTriangle size={24} className="text-destructive flex-shrink-0 mt-0.5" />
                    <div>
                        <h3 className="font-bold text-destructive">คำเตือน: คุณติดไวรัสอยู่!</h3>
                        <p className="text-sm text-destructive/80 mt-1">หากมี 'ยาต้านไวรัส' ให้กดใช้กับตัวเอง หรือถ้าไม่มี ลองขอความช่วยเหลือจากเพื่อน</p>
                        {!items.some(i => i.item_type === 'antivirus' && i.quantity > 0) && (
                            <Link to="/student/item-requests" className="inline-flex items-center gap-2 bg-destructive text-destructive-foreground px-4 py-1.5 rounded-lg text-sm font-bold mt-3 hover:opacity-90 transition">
                                <Send size={16} /> ขอยาจากเพื่อนด่วน!
                            </Link>
                        )}
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {items.length === 0 && !loading && (
                    <div className="col-span-full py-20 text-center border-2 border-dashed border-border rounded-3xl bg-muted/10">
                        <Package size={48} className="mx-auto text-muted-foreground/30 mb-4" />
                        <h3 className="text-lg font-bold text-muted-foreground">กระเป๋าไอเทมว่างเปล่า</h3>
                        <p className="text-sm text-muted-foreground mt-1">แลกแต้มสะสมเพื่อรับไอเทมได้ที่ร้านค้า</p>
                    </div>
                )}

                {items.map(item => {
                    const details = getItemDetails(item.item_type);
                    const Icon = details.icon;
                    return (
                        <div key={item.id} className={`border-2 ${details.borderColor} bg-card rounded-3xl p-6 shadow-sm relative overflow-hidden group hover:shadow-md transition`}>
                            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-current opacity-5 rounded-bl-[100px] pointer-events-none" style={{ color: details.color }} />
                            
                            <div className="flex justify-between items-start mb-4 relative z-10">
                                <div className={`w-14 h-14 rounded-2xl ${details.bg} ${details.color} flex items-center justify-center`}>
                                    <Icon size={32} />
                                </div>
                                <div className="text-right">
                                    <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">จำนวน</span>
                                    <p className="text-3xl font-black leading-none mt-1">x{item.quantity}</p>
                                </div>
                            </div>
                            
                            <h3 className="font-black text-xl mb-1">{details.name}</h3>
                            <p className="text-sm text-muted-foreground mb-6">ไอเทมกดใช้เพื่อรักษาอาการติดไวรัส 1 ครั้ง ต่อ 1 เม็ด</p>
                            
                            <div className="grid grid-cols-2 gap-2 relative z-10">
                                <button 
                                    onClick={() => setUseModal({ show: true, item, target: 'self' })}
                                    disabled={infections.length === 0}
                                    className="flex items-center justify-center gap-1.5 bg-primary text-primary-foreground py-2 rounded-xl text-sm font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary/90 transition shadow-sm"
                                >
                                    <HeartPulse size={16} /> ใช้ตัวเอง
                                </button>
                                <button 
                                    onClick={() => setUseModal({ show: true, item, target: 'friend' })}
                                    disabled={infectedClassmates.length === 0}
                                    className="flex items-center justify-center gap-1.5 bg-background border-2 border-primary text-primary py-2 rounded-xl text-sm font-bold disabled:opacity-50 disabled:cursor-not-allowed disabled:border-border disabled:text-muted-foreground hover:bg-primary/5 transition"
                                >
                                    <UserPlus size={16} /> ให้เพื่อน
                                </button>
                            </div>
                            
                            {infectedClassmates.length === 0 && (
                                <p className="text-[10px] text-center text-muted-foreground mt-2 absolute bottom-2 left-0 right-0">ยังไม่มีเพื่อนในห้องที่ติดไวรัส</p>
                            )}
                        </div>
                    );
                })}
            </div>

            {useModal.show && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in">
                    <div className="bg-card w-full max-w-sm rounded-[2rem] shadow-2xl p-6 border border-border">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-xl font-black">ใช้งาน {getItemDetails(useModal.item.item_type).name}</h2>
                            <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center text-muted-foreground font-black">
                                x{useModal.item.quantity}
                            </div>
                        </div>

                        <form onSubmit={handleUseItem}>
                            {useModal.target === 'self' ? (
                                <div className="text-center py-6">
                                    <div className="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                                        <HeartPulse size={40} />
                                    </div>
                                    <h3 className="font-bold text-lg mb-2">รักษาอาการติดเชื้อ</h3>
                                    <p className="text-sm text-muted-foreground">ไอเทมจะถูกหัก 1 ชิ้น คุณแน่ใจหรือไม่ที่จะใช้ยานี้กับตัวเอง?</p>
                                </div>
                            ) : (
                                <div className="py-2 space-y-4">
                                    <div className="bg-blue-50 border border-blue-100 text-blue-800 text-sm p-3 rounded-xl flex gap-3">
                                        <ShieldPlus className="flex-shrink-0 mt-0.5 text-blue-500" size={18} />
                                        <p>เลือกเพื่อนที่กำลังติดไวรัส เพื่อช่วยเหลือพวกเขา ไอเทมจะถูกหัก 1 ชิ้น</p>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-bold mb-2 text-foreground">เลือกเพื่อนที่จะรักษา <span className="text-red-500">*</span></label>
                                        <select required value={selectedFriend} onChange={e => setSelectedFriend(e.target.value)}
                                            className="w-full bg-background border-2 border-input px-4 py-3 rounded-2xl text-sm focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/20 appearance-none font-medium">
                                            <option value="">-- เลือกเพื่อนที่น่าสงสาร --</option>
                                            {infectedClassmates.map(c => (
                                                <option key={c.student_id} value={c.student_id}>{c.first_name} {c.last_name} ({c.student_id})</option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                            )}

                            <div className="flex gap-3 mt-8">
                                <button type="button" onClick={() => setUseModal({ show: false, item: null, target: 'self' })} 
                                    className="flex-1 bg-background border-2 border-border py-3 rounded-xl font-bold hover:bg-muted transition text-muted-foreground">ยกเลิก</button>
                                <button type="submit" 
                                    className="flex-[2] bg-primary text-primary-foreground py-3 rounded-xl font-black shadow-[0_4px_15px_rgba(34,197,94,0.3)] hover:opacity-90 transition">
                                    ยืนยันการใช้ไอเทม
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
