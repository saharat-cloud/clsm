import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { alerts } from '@/utils/alerts';
import { FileText, File, Image as ImageIcon, BookOpen } from 'lucide-react';

export default function StudentMaterials() {
    const [materials, setMaterials] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadData();
    }, []);

    async function loadData() {
        try {
            const session = localStorage.getItem('student_session');
            if (!session) return;
            const std = JSON.parse(session);

            // Core student and classroom data is now managed by the admin
            const [freshStd] = await base44.entities.Student.filter({ 
                student_id: std.student_id,
                teacher_id: 'kanit_admin'
            });
            const s = freshStd || std;

            // Fetch all admin-managed classrooms
            const clsList = await base44.entities.Classroom.filter({ teacher_id: 'kanit_admin' });

            // Find classrooms the student is in
            const myClassrooms = clsList.filter(c => (c.student_ids || []).includes(s.id));
            const myClassroomIds = myClassrooms.map(c => c.id);

            if (myClassroomIds.length > 0) {
                // Fetch all materials and subjects
                const [matList, subList] = await Promise.all([
                    base44.entities.Material.list(),
                    base44.entities.Subject.list()
                ]);

                const myMats = matList.filter(m => 
                    (m.classroom_ids || []).some(cid => myClassroomIds.includes(cid))
                );

                // Attach subject info to materials
                const matsWithSubjects = myMats.map(m => ({
                    ...m,
                    subject: subList.find(s => s.id === m.subject_id)
                }));

                setMaterials(matsWithSubjects.sort((a,b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));
            } else {
                setMaterials([]);
            }
        } catch (err) {
            console.error(err);
            if (err.message?.includes('does not exist')) {
                alerts.error('ไม่พบตารางข้อมูล', 'กรุณาแจ้งครูผู้สอนให้ดำเนินการ Setup ระบบใหม่');
            } else {
                alerts.error('เกิดข้อผิดพลาดในการโหลดเนื้อหา');
            }
        } finally {
            setLoading(false);
        }
    }

    function getFileIcon(url) {
        if (url.match(/\.(jpeg|jpg|gif|png|webp)$/i)) return <ImageIcon size={20} className="text-blue-500" />;
        if (url.match(/\.(pdf)$/i)) return <FileText size={20} className="text-red-500" />;
        return <File size={20} className="text-gray-500" />;
    }

    return (
        <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
            <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary/10 text-primary rounded-2xl flex items-center justify-center">
                    <BookOpen size={24} />
                </div>
                <div>
                    <h1 className="text-2xl font-bold">บทเรียนของฉัน</h1>
                    <p className="text-sm text-muted-foreground mt-0.5">เนื้อหา แบบฝึกหัด และประกาศจากครู</p>
                </div>
            </div>

            <div className="space-y-4 mt-6">
                {materials.length === 0 && !loading && (
                    <div className="text-center py-20 bg-muted/20 border border-dashed border-border rounded-3xl">
                        <FileText size={48} className="mx-auto text-muted-foreground/30 mb-4" />
                        <h3 className="text-lg font-bold text-muted-foreground">ยังไม่มีเนื้อหาบทเรียน</h3>
                        <p className="text-sm text-muted-foreground mt-1">พักผ่อนได้เลย ยังไม่มีการสั่งงานหรือแจกเนื้อหาใหม่</p>
                    </div>
                )}
                
                {materials.map(m => (
                    <div key={m.id} className="bg-card border border-border rounded-2xl p-5 shadow-sm hover:shadow-md transition">
                        <div className="flex items-start gap-4">
                            <div className="hidden sm:flex w-10 h-10 rounded-full bg-blue-100 text-blue-600 items-center justify-center flex-shrink-0 mt-1">
                                <FileText size={20} />
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
                                    <div className="flex items-center gap-2">
                                        <h3 className="text-lg font-bold text-foreground truncate">{m.title}</h3>
                                        {m.subject && (
                                            <span className="text-[10px] bg-amber-100 text-amber-700 px-2.5 py-0.5 rounded-full font-bold whitespace-nowrap">
                                                {m.subject.code}
                                            </span>
                                        )}
                                    </div>
                                    <p className="text-xs font-medium text-muted-foreground bg-muted w-fit px-2.5 py-1 rounded-full whitespace-nowrap">
                                        {new Date(m.created_at).toLocaleString('th-TH')}
                                    </p>
                                </div>
                                
                                {m.content && (
                                    <div className="text-sm bg-muted/30 p-4 rounded-xl mb-4 whitespace-pre-wrap leading-relaxed text-foreground/90 border border-muted">
                                        {m.content}
                                    </div>
                                )}

                                {m.attachment_urls && m.attachment_urls.length > 0 && (
                                    <div className="flex flex-wrap gap-2 mt-4">
                                        {m.attachment_urls.map((url, i) => {
                                            const filename = decodeURIComponent(url.split('/').pop().split('?')[0]);
                                            return (
                                                <a key={i} href={url} target="_blank" rel="noreferrer" 
                                                    className="flex items-center gap-2 bg-background border border-border hover:border-primary hover:bg-primary/5 hover:text-primary px-3 py-2.5 rounded-xl text-sm font-medium transition group max-w-full"
                                                >
                                                    {getFileIcon(url)}
                                                    <span className="truncate max-w-[200px] text-muted-foreground group-hover:text-primary transition">{filename}</span>
                                                </a>
                                            );
                                        })}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
