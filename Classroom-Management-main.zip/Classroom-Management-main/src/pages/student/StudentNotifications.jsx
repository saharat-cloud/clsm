import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Bell, CheckCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export default function StudentNotifications() {
    const navigate = useNavigate();
    const [notifications, setNotifications] = useState([]);

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) { navigate('/student/login'); return; }
        const std = JSON.parse(session);
        async function load(studentId) {
            // Notifications are student-specific, regardless of which teacher sent them
            const notifs = await base44.entities.Notification.filter({ student_id: studentId });
            setNotifications(notifs.sort((a, b) => new Date(b.created_date || b.created_at).getTime() - new Date(a.created_date || a.created_at || 0).getTime()));
        }
        load(std.student_id);
    }, []);

    async function markRead(n) {
        if (n.is_read) return;
        await base44.entities.Notification.update(n.id, { is_read: true });
        setNotifications(prev => prev.map(x => x.id === n.id ? { ...x, is_read: true } : x));
    }

    const unread = notifications.filter(n => !n.is_read).length;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-2xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/student" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <h1 className="text-2xl font-bold">การแจ้งเตือน</h1>
                    {unread > 0 && <span className="bg-destructive text-destructive-foreground text-xs px-2 py-0.5 rounded-full">{unread}</span>}
                </div>

                <div className="grid gap-3">
                    {notifications.map(n => (
                        <div key={n.id}
                            onClick={() => markRead(n)}
                            className={`p-4 rounded-2xl border cursor-pointer transition ${n.is_read ? 'bg-card border-border opacity-70' : 'bg-accent/30 border-primary/40'}`}>
                            <div className="flex items-start gap-3">
                                <Bell size={18} className={n.is_read ? 'text-muted-foreground' : 'text-primary'} />
                                <div className="flex-1">
                                    <p className={`font-semibold ${n.is_read ? '' : 'text-foreground'}`}>{n.title}</p>
                                    <p className="text-sm text-muted-foreground mt-0.5">{n.message}</p>
                                    <p className="text-xs text-muted-foreground mt-2">{new Date(n.created_date).toLocaleString('th-TH')}</p>
                                </div>
                                {n.is_read && <CheckCircle size={14} className="text-muted-foreground mt-0.5" />}
                            </div>
                        </div>
                    ))}
                    {notifications.length === 0 && (
                        <div className="text-center py-16 text-muted-foreground">
                            <Bell size={40} className="mx-auto mb-3 opacity-30" />
                            <p>ยังไม่มีการแจ้งเตือน</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}