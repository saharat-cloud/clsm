import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { ArrowLeft, Plus, Minus, Trophy } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { alerts } from '@/utils/alerts';
import { calculateLevel, calculateProgress } from '@/lib/levelUtils';

export default function StudentPoints() {
    const navigate = useNavigate();
    const [student, setStudent] = useState(null);
    const [transactions, setTransactions] = useState([]);
    const [rewards, setRewards] = useState([]);
    const [claims, setClaims] = useState([]);
    const [activeTab, setActiveTab] = useState('rewards'); // Default to Shop
    const [showRewardAnim, setShowRewardAnim] = useState(null); // { name, image_url }

    const load = async () => {
        const session = localStorage.getItem('student_session');
        if (!session) { navigate('/student/login'); return; }
        const std = JSON.parse(session);
        
        // 1. Fetch semesters first to know which one is active
        const allSemesters = await base44.entities.Semester.filter({ teacher_id: 'kanit_admin' });
        const activeSem = allSemesters.find(s => s.is_active) || allSemesters[0];

        const filter = {
            ...(activeSem ? { 
                semester_academic_year: activeSem.academic_year, 
                semester_number: activeSem.semester 
            } : {}),
            student_id: std.student_id
        };

        const adminFilter = {
            ...(activeSem ? { 
                semester_academic_year: activeSem.academic_year, 
                semester_number: activeSem.semester 
            } : {}),
            teacher_id: 'kanit_admin'
        };

        // 2. Fetch everything else using the semester context
        const [fresh, txns, cls, rwds, clms] = await Promise.all([
            base44.entities.Student.filter({ student_id: std.student_id, teacher_id: 'kanit_admin' }),
            base44.entities.PointTransaction.filter(filter), 
            base44.entities.Classroom.filter(adminFilter),
            base44.entities.Reward.filter({ teacher_id: 'kanit_admin', ... (activeSem ? { semester_academic_year: activeSem.academic_year, semester_number: activeSem.semester } : {}) }),
            base44.entities.RewardClaim.filter(filter),
        ]);
        
        const s = fresh[0] || std;
        setStudent(s);
        setTransactions(txns.sort((a, b) => new Date(b.created_date || b.created_at || 0).getTime() - new Date(a.created_date || a.created_at || 0).getTime()));
        
        const myClsIds = cls.filter(c => (c.student_ids || []).includes(s.id)).map(c => c.id);
        const now = new Date();
        const availableRewards = rwds.filter(r => {
            // Include rewards that are either school-wide (no classroom_id) 
            // or targeted to one of the student's admin-managed classrooms
            if (r.classroom_id && !myClsIds.includes(r.classroom_id)) return false;
            
            if (r.status === 'limited') return false;
            if (r.sale_end_date && new Date(r.sale_end_date) < now) return false;
            return true;
        });
        setRewards(availableRewards);
        setClaims(clms.sort((a, b) => new Date(b.created_date || b.created_at || 0).getTime() - new Date(a.created_date || a.created_at || 0).getTime()));
    };

    useEffect(() => {
        load();
        
        // Listen for approved claims in real-time
        const session = localStorage.getItem('student_session');
        if (session) {
            const std = JSON.parse(session);
            const channel = supabase
                .channel('reward-approvals')
                .on(
                    'postgres_changes',
                    {
                        event: 'UPDATE',
                        schema: 'public',
                        table: 'reward_claims',
                        filter: `student_id=eq.${std.student_id}`
                    },
                    async (payload) => {
                        const newStatus = payload.new.status;
                        const oldStatus = payload.old.status;

                        if (newStatus !== oldStatus) {
                            if (newStatus === 'approved') {
                                // Find reward details for the animation
                                const { data: rwd } = await supabase
                                    .from('rewards')
                                    .select('*')
                                    .eq('id', payload.new.reward_id)
                                    .single();
                                
                                setShowRewardAnim(rwd || { name: 'ของรางวัล' });
                                load(); // Refresh points and claims
                                
                                setTimeout(() => {
                                    setShowRewardAnim(null);
                                }, 5000);
                            } else if (newStatus === 'rejected') {
                                // User gets points refunded, just refresh
                                load();
                            }
                        }
                    }
                )
                .subscribe();

            // Listen for reward updates (stock sync)
            const rewardChannel = supabase
                .channel('reward-stock-sync')
                .on(
                    'postgres_changes',
                    { event: 'UPDATE', schema: 'public', table: 'rewards' },
                    () => { load(); }
                )
                .subscribe();

            return () => {
                supabase.removeChannel(channel);
                supabase.removeChannel(rewardChannel);
            };
        }
    }, []);

    async function handleRedeem(reward) {
        const isFree = reward.exp_required === 0 && reward.points_required === 0;
        const isExpRedeem = !isFree && reward.exp_required > 0 && reward.points_required === 0;
        const isPointsRedeem = !isFree && reward.points_required > 0;
        
        if (isPointsRedeem && (student.total_points || 0) < reward.points_required) {
            alerts.error('แต้มสะสมไม่เพียงพอ');
            return;
        }
        if (isExpRedeem && (student.total_exp || 0) < reward.exp_required) {
            alerts.error('EXP ไม่เพียงพอ');
            return;
        }
        
        if (reward.stock <= 0 && reward.reward_type !== 'customization') {
            alerts.error('ของรางวัลหมดแล้ว');
            return;
        }

        const confirmText = isFree 
            ? `ยืนยันการรับ ${reward.name} ฟรี?`
            : isPointsRedeem 
                ? `ยืนยันการแลก ${reward.name} ด้วย ${reward.points_required} แต้ม?`
                : `ยืนยันการแลก ${reward.name} ด้วย ${reward.exp_required} EXP?`;

        if (!await alerts.confirm('รับรางวัล', confirmText)) return;

        let updatedFields = {};
        if (isPointsRedeem) {
            updatedFields.total_points = (student.total_points || 0) - reward.points_required;
            await base44.entities.PointTransaction.create({
                student_id: student.student_id,
                points: -reward.points_required,
                reason: `แลกรางวัล: ${reward.name}`,
            });
        }
        
        if (isExpRedeem) {
            updatedFields.total_exp = (student.total_exp || 0) - reward.exp_required;
        }

        // Special handling for customizations
        if (reward.reward_type === 'customization') {
            const owned = student.owned_customizations || [];
            const newItem = {
                type: reward.customization_type,
                value: reward.customization_value,
                name: reward.name,
                id: reward.id
            };
            // Only add if not already owned
            if (!owned.some(i => i.id === reward.id)) {
                updatedFields.owned_customizations = [...owned, newItem];
            }
        }

        if (Object.keys(updatedFields).length > 0) {
            const fresh = await base44.entities.Student.update(student.id, updatedFields);
            setStudent(fresh);
            localStorage.setItem('student_session', JSON.stringify(fresh));
        }

        // Always decrement stock if it exists
        if (reward.stock !== undefined) {
             await base44.entities.Reward.update(reward.id, { stock: Math.max(0, reward.stock - 1) });
        }

        // Create a claim for tracking (even for customizations)
        await base44.entities.RewardClaim.create({
            student_id: student.student_id,
            reward_id: reward.id,
            status: reward.reward_type === 'customization' ? 'approved' : 'pending' // Customizations auto-approve for now
        });

        if (reward.reward_type !== 'customization') {
            alerts.success('ส่งคำขอแลกรางวัลเรียบร้อยแล้ว', 'รอครูอนุมัติ');
        } else {
            alerts.success('แลกสำเร็จ!', 'คุณสามารถเปลี่ยนผลได้ที่หน้าโปรไฟล์');
        }

        load();
    }

    if (!student) return null;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-2xl mx-auto px-4 py-8">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                    <div className="flex items-center gap-3">
                        <Link to="/student" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                        <h1 className="text-2xl font-bold">ร้านค้า (แลกรางวัล)</h1>
                    </div>
                    
                    <div className="flex bg-muted/50 p-1 rounded-xl w-full md:w-auto overflow-x-auto hide-scrollbar">
                        <button onClick={() => setActiveTab('rewards')} className={`whitespace-nowrap flex-1 md:flex-none px-4 py-1.5 rounded-lg text-sm font-medium transition ${activeTab === 'rewards' ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>ร้านค้า</button>
                        <button onClick={() => setActiveTab('points')} className={`whitespace-nowrap flex-1 md:flex-none px-4 py-1.5 rounded-lg text-sm font-medium transition ${activeTab === 'points' ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>ประวัติแต้ม</button>
                        <button onClick={() => setActiveTab('claims')} className={`whitespace-nowrap flex-1 md:flex-none px-4 py-1.5 rounded-lg text-sm font-medium transition ${activeTab === 'claims' ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>ประวัติแลก</button>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-gradient-to-br from-amber-400 to-amber-500 text-white rounded-2xl p-6 text-center shadow-lg shadow-amber-500/20">
                        <p className="text-4xl font-black drop-shadow-sm">{student.total_points || 0}</p>
                        <p className="text-[10px] mt-1 opacity-90 font-bold uppercase tracking-wider">แต้มสะสม</p>
                    </div>
                    <div className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-2xl p-6 text-center shadow-lg shadow-blue-500/20">
                        <div className="flex items-center justify-center gap-2">
                            <span className="text-xs font-bold bg-white/20 px-2 py-0.5 rounded-full">LV. {calculateLevel(student.total_exp)}</span>
                            <p className="text-4xl font-black drop-shadow-sm">{student.total_exp || 0}</p>
                        </div>
                        <p className="text-[10px] mt-1 opacity-90 font-bold uppercase tracking-wider">EXP สะสม</p>
                        <div className="mt-2 w-full bg-black/20 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-white h-full transition-all duration-1000" style={{ width: `${calculateProgress(student.total_exp)}%` }} />
                        </div>
                    </div>
                </div>

                {activeTab === 'points' && (
                    <div className="animate-in fade-in slide-in-from-bottom-2">
                        <h2 className="font-bold mb-3 text-lg">ประวัติการได้/ลดแต้ม</h2>
                        <div className="bg-card border border-border rounded-2xl divide-y divide-border overflow-hidden">
                            {transactions.map(t => (
                                <div key={t.id} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/10 transition">
                                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${t.points > 0 ? 'bg-emerald-100/50' : 'bg-red-100/50'}`}>
                                        {t.points > 0 ? <Plus size={18} className="text-emerald-600" /> : <Minus size={18} className="text-red-500" />}
                                    </div>
                                    <div className="flex-1">
                                        <p className="font-medium text-sm">{t.reason || 'ไม่ระบุเหตุผล'}</p>
                                        <p className="text-xs text-muted-foreground mt-0.5">{new Date(t.created_date || t.created_at).toLocaleString('th-TH')}</p>
                                    </div>
                                    <span className={`text-lg font-bold ${t.points > 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                                        {t.points > 0 ? '+' : ''}{t.points}
                                    </span>
                                </div>
                            ))}
                            {transactions.length === 0 && <p className="text-center py-8 text-muted-foreground text-sm">ยังไม่มีประวัติแต้ม</p>}
                        </div>
                    </div>
                )}

                {activeTab === 'rewards' && (
                    <div className="animate-in fade-in slide-in-from-bottom-2">
                        <h2 className="font-bold mb-3 text-lg">รายการของรางวัลทั้งหมด</h2>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                            {rewards.map(r => {
                                const canAfford = (student.total_points || 0) >= r.points_required;
                                const isOutOfStock = r.stock <= 0;
                                return (
                                    <div key={r.id} className="bg-card border border-border rounded-2xl overflow-hidden group hover:border-primary/50 transition-all duration-300 hover:shadow-2xl hover:shadow-primary/10 hover:-translate-y-1">
                                        <div className="aspect-square bg-muted/30 flex items-center justify-center relative overflow-hidden">
                                            {r.image_url ? 
                                                <img src={r.image_url} alt={r.name} className="w-full h-full object-contain group-hover:scale-110 transition duration-700 p-4" /> 
                                                : 
                                                <div className="text-muted-foreground/30 font-bold text-4xl group-hover:scale-125 transition duration-700">?</div>
                                            }
                                            
                                            {/* Rarity Badge */}
                                            <div className="absolute bottom-2 left-2">
                                                <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full border shadow-sm ${
                                                    r.rarity === 'rare' ? 'bg-blue-500 text-white border-blue-400' :
                                                    r.rarity === 'epic' ? 'bg-purple-500 text-white border-purple-400' :
                                                    r.rarity === 'legendary' ? 'bg-amber-500 text-white border-amber-400 animate-pulse' :
                                                    'bg-gray-400 text-white border-gray-300'
                                                }`}>
                                                    {r.rarity || 'common'}
                                                </span>
                                            </div>

                                            <div className="absolute top-2 right-2 flex flex-col items-end gap-1">
                                                {r.points_required > 0 && (
                                                    <div className="bg-amber-500 text-white px-2.5 py-1 rounded-xl text-[10px] font-black shadow-lg">
                                                        {r.points_required} แต้ม
                                                    </div>
                                                )}
                                                {r.exp_required > 0 && (
                                                    <div className="bg-blue-600 text-white px-2.5 py-1 rounded-xl text-[10px] font-black shadow-lg">
                                                        {r.exp_required} EXP
                                                    </div>
                                                )}
                                            </div>
                                            {isOutOfStock && (
                                                <div className="absolute inset-0 bg-background/60 backdrop-blur-[2px] flex items-center justify-center z-10">
                                                    <span className="bg-destructive text-destructive-foreground px-3 py-1 rounded-lg text-sm font-bold shadow-lg transform -rotate-12 animate-in zoom-in">ของหมด</span>
                                                </div>
                                            )}
                                            {r.sale_end_date && (
                                                <div className="absolute top-2 left-2 z-10 bg-black/70 text-white text-[8px] px-2 py-1 rounded-full backdrop-blur-sm border border-white/20">
                                                    Sale ends: {new Date(r.sale_end_date).toLocaleDateString('th-TH')}
                                                </div>
                                            )}
                                        </div>
                                        <div className="p-4 relative bg-card">
                                            {/* Sparkle effect for legendary */}
                                            {r.rarity === 'legendary' && (
                                                <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-amber-400 to-transparent animate-pulse" />
                                            )}

                                            <p className="font-bold truncate text-sm mb-1 group-hover:text-primary transition-colors">{r.name}</p>
                                            
                                            <div className="flex items-center justify-between mb-4">
                                                <p className="text-[10px] text-muted-foreground">คงเหลือ: {r.stock} ชิ้น</p>
                                                {r.reward_type === 'points' && <span className="text-[8px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-full">+{r.score_amount} คะแนน</span>}
                                                {r.reward_type === 'customization' && <span className="text-[8px] font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded-full">ตกแต่ง</span>}
                                            </div>

                                            <button 
                                                onClick={() => handleRedeem(r)}
                                                disabled={(!canAfford && r.points_required > 0) || isOutOfStock}
                                                className={`w-full py-2.5 rounded-xl text-sm font-black transition-all duration-300 ${
                                                    isOutOfStock && r.reward_type !== 'customization' ? 'bg-muted text-muted-foreground cursor-not-allowed shadow-none' :
                                                    r.points_required === 0 && r.exp_required === 0 ? 'bg-emerald-500 text-white hover:bg-emerald-600 shadow-lg shadow-emerald-500/20 active:scale-95' :
                                                    ((r.points_required > 0 && (student.total_points || 0) < r.points_required) || (r.exp_required > 0 && (student.total_exp || 0) < r.exp_required)) ? 
                                                    'bg-red-50 text-red-500 border border-red-100 cursor-not-allowed' : 
                                                    'bg-primary text-primary-foreground hover:shadow-lg hover:shadow-primary/20 hover:scale-[1.02] active:scale-95'
                                                }`}
                                            >
                                                {isOutOfStock && r.reward_type !== 'customization' ? 'ของหมด' :
                                                 r.points_required === 0 && r.exp_required === 0 ? 'รับฟรี' :
                                                 ((r.points_required > 0 && (student.total_points || 0) < r.points_required) || (r.exp_required > 0 && (student.total_exp || 0) < r.exp_required)) ? 
                                                    (r.exp_required > 0 ? 'EXP ไม่พอ' : 'แต้มไม่พอ') : 'แลกรางวัล'}
                                            </button>
                                        </div>
                                    </div>
                                );
                            })}
                            {rewards.length === 0 && (
                                <div className="col-span-full py-12 text-center text-muted-foreground text-sm border-2 border-dashed border-border rounded-2xl bg-muted/10">
                                    ยังไม่มีของรางวัลให้แลกในขณะนี้
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {activeTab === 'claims' && (
                    <div className="animate-in fade-in slide-in-from-bottom-2">
                        <h2 className="font-bold mb-3 text-lg">ประวัติการแลกรางวัลของฉัน</h2>
                        <div className="bg-card border border-border rounded-2xl divide-y divide-border overflow-hidden">
                            {claims.map(c => {
                                const r = rewards.find(rw => rw.id === c.reward_id);
                                return (
                                    <div key={c.id} className="flex items-center gap-4 px-4 py-3 hover:bg-muted/10 transition">
                                        <div className="w-12 h-12 rounded-xl bg-muted/40 overflow-hidden flex-shrink-0 flex items-center justify-center border border-border/50">
                                            {r?.image_url ? <img src={r.image_url} alt="" className="w-full h-full object-cover"/> : <div className="text-muted-foreground/30 font-bold">?</div>}
                                        </div>
                                        <div className="flex-1">
                                            <p className="font-bold text-sm">{r?.name || 'รางวัลที่ถูกลบไปแล้ว'}</p>
                                            <p className="text-xs text-muted-foreground mt-0.5">{new Date(c.created_date || c.created_at).toLocaleString('th-TH')}</p>
                                        </div>
                                        <div className="text-right">
                                            <span className={`text-xs px-2.5 py-1 rounded-lg font-medium border ${
                                                c.status === 'pending' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                                                c.status === 'approved' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                                                'bg-red-50 text-red-600 border-red-100'
                                            }`}>
                                                {c.status === 'pending' ? 'รออนุมัติ' : c.status === 'approved' ? 'รับรางวัลแล้ว' : 'ถูกปฏิเสธ (คืนแต้ม)'}
                                            </span>
                                        </div>
                                    </div>
                                );
                            })}
                            {claims.length === 0 && <p className="text-center py-8 text-muted-foreground text-sm">ยังไม่เคยแลกรางวัล</p>}
                        </div>
                    </div>
                )}
            </div>

            {/* Glowing Reward Animation Overlay */}
            {showRewardAnim && (
                <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black/90 backdrop-blur-md animate-in fade-in duration-500">
                    <div className="relative">
                        {/* Glow and Pulse Effects */}
                        <div className="absolute inset-0 bg-amber-500/40 rounded-full blur-[100px] animate-pulse"></div>
                        <div className="absolute inset-0 bg-white/20 rounded-full blur-[40px] animate-ping"></div>
                        
                        {/* The Reward Image Spinning */}
                        <div className="relative w-64 h-64 bg-gradient-to-br from-amber-400 to-amber-600 rounded-[40px] p-1 shadow-2xl shadow-amber-500/50 animate-in zoom-in spin-in-180 duration-1000">
                            <div className="w-full h-full bg-background rounded-[38px] overflow-hidden flex items-center justify-center border-4 border-white/20">
                                {showRewardAnim.image_url ? (
                                    <img src={showRewardAnim.image_url} alt="" className="w-full h-full object-cover animate-bounce-slow" />
                                ) : (
                                    <Trophy size={100} className="text-amber-500 animate-bounce-slow" />
                                )}
                            </div>
                        </div>

                        {/* Light Beams (Pseudo-elements or extra divs) */}
                        {[...Array(8)].map((_, i) => (
                            <div key={i} className="absolute top-1/2 left-1/2 w-1 h-80 bg-gradient-to-t from-transparent via-white/50 to-transparent"
                                style={{ transform: `translate(-50%, -50%) rotate(${i * 45}deg)`, opacity: 0.3 }}></div>
                        ))}
                    </div>

                    <div className="mt-12 text-center animate-in slide-in-from-bottom-8 duration-700">
                        <h2 className="text-4xl font-black text-white mb-2 drop-shadow-lg uppercase tracking-wider">สำเร็จแล้ว!</h2>
                        <p className="text-amber-400 text-xl font-bold mb-8">คุณได้รับ {showRewardAnim.name}</p>
                        <button onClick={() => setShowRewardAnim(null)} className="px-8 py-3 bg-white text-black rounded-full font-black hover:bg-amber-400 transition transform hover:scale-110 active:scale-95 shadow-xl shadow-white/10">ตกลง</button>
                    </div>
                    
                    <style dangerouslySetInnerHTML={{ __html: `
                        @keyframes bounce-slow {
                            0%, 100% { transform: translateY(-5%); }
                            50% { transform: translateY(5%); }
                        }
                        .animate-bounce-slow {
                            animation: bounce-slow 3s ease-in-out infinite;
                        }
                    `}} />
                </div>
            )}
        </div>
    );
}