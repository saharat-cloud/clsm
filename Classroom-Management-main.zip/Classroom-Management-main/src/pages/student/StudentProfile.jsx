import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { ArrowLeft, Upload, Check, User } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { alerts } from '@/utils/alerts';
import StudentAvatar from '@/components/ui/StudentAvatar';
import { calculateLevel, calculateProgress } from '@/lib/levelUtils';

export default function StudentProfile() {
    const navigate = useNavigate();
    const { toast } = useToast();
    const [student, setStudent] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) { navigate('/student/login'); return; }
        const std = JSON.parse(session);
        load(std.student_id);

        const channel = supabase.channel(`profile-sync-${std.student_id}`)
            .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'students', filter: `student_id=eq.${std.student_id}` }, (payload) => {
                setStudent(payload.new);
                localStorage.setItem('student_session', JSON.stringify(payload.new));
            })
            .subscribe();
        return () => { supabase.removeChannel(channel); };
    }, []);

    async function load(studentId) {
        // Core student data is now attached to the admin account
        const [fresh] = await base44.entities.Student.filter({ 
            student_id: studentId, 
            teacher_id: 'kanit_admin' 
        });
        if (fresh) {
            setStudent(fresh);
            localStorage.setItem('student_session', JSON.stringify(fresh));
        }
    }

    async function handleAvatarUpload(e) {
        const file = e.target.files[0];
        if (!file) return;

        // 600KB Limit
        if (file.size > 600 * 1024) {
            alerts.error('ไฟล์มีขนาดใหญ่เกินไป', 'กรุณาอัปโหลดรูปภาพขนาดไม่เกิน 600KB');
            return;
        }

        setUploading(true);
        try {
            const ext = file.name.split('.').pop() || '';
            const fileName = `avatar_${student.student_id}_${Date.now()}.${ext}`;
            const filePath = `avatars/${fileName}`;

            const { error: uploadError } = await supabase.storage
                .from('assignments') // Reusing assignments bucket or use a new 'profiles' if exists
                .upload(filePath, file);

            if (uploadError) throw uploadError;

            const { data } = supabase.storage.from('assignments').getPublicUrl(filePath);
            const avatar_url = data.publicUrl;

            const updated = await base44.entities.Student.update(student.id, { avatar_url });
            setStudent(updated);
            localStorage.setItem('student_session', JSON.stringify(updated));
            toast({ title: 'อัปเดตรูปโปรไฟล์แล้ว' });
        } catch (err) {
            console.error(err);
            alerts.error('เกิดข้อผิดพลาดในการอัปโหลด');
        } finally {
            setUploading(false);
        }
    }

    async function selectCustomization(type, value) {
        setSaving(true);
        try {
            const field = type === 'title' ? 'title' : type === 'frame' ? 'profile_frame' : 'name_bg_color';
            const updated = await base44.entities.Student.update(student.id, { [field]: value });
            setStudent(updated);
            localStorage.setItem('student_session', JSON.stringify(updated));
            toast({ title: 'บันทึกการเปลี่ยนแปลงแล้ว' });
        } catch (err) {
            console.error(err);
            alerts.error('บันทึกไม่สำเร็จ');
        } finally {
            setSaving(false);
        }
    }

    if (!student) return null;

    const owned = student.owned_customizations || [];
    const titles = owned.filter(i => i.type === 'title');
    const frames = owned.filter(i => i.type === 'frame');
    const nameBgs = owned.filter(i => i.type === 'name_bg' || i.type === 'name_bg_color');

    return (
        <div className="min-h-screen bg-background pb-12">
            <div className="max-w-2xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-8">
                    <Link to="/student" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <h1 className="text-2xl font-bold">ปรับแต่งโปรไฟล์</h1>
                </div>

                <div className="grid gap-6">
                    {/* Preview Section */}
                    <div className="bg-card border border-border rounded-3xl p-8 flex flex-col items-center text-center shadow-sm">
                        <div className="relative mb-4">
                            <StudentAvatar student={student} size={100} showTitle={true} />
                            <label className="absolute bottom-6 right-2 bg-primary text-primary-foreground p-2 rounded-full shadow-lg cursor-pointer hover:scale-110 transition z-20">
                                <Upload size={16} />
                                <input type="file" className="hidden" accept="image/*" onChange={handleAvatarUpload} disabled={uploading} />
                            </label>
                        </div>
                        <h2 className={`text-xl font-bold student-name-${student.student_id}`}>{student.first_name} {student.last_name}</h2>
                        <p className="text-sm text-muted-foreground font-mono mt-1">{student.student_id}</p>
                        
                        <div className="mt-6 w-full max-w-xs">
                            <div className="flex justify-between text-[10px] font-bold uppercase text-muted-foreground mb-1">
                                <span>LV. {calculateLevel(student.total_exp)}</span>
                                <span>{student.total_exp} / {Math.floor(student.total_exp / 500 + 1) * 500} EXP</span>
                            </div>
                            <div className="w-full h-3 bg-muted rounded-full overflow-hidden border border-border">
                                <div className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full transition-all duration-1000" style={{ width: `${calculateProgress(student.total_exp)}%` }} />
                            </div>
                        </div>
                    </div>

                    {/* Titles */}
                    <section>
                        <h3 className="font-bold mb-3 px-1">ฉายาของคุณ ({titles.length})</h3>
                        <div className="flex flex-wrap gap-2">
                            <button onClick={() => selectCustomization('title', '')}
                                className={`px-4 py-2 rounded-xl text-sm border transition ${!student.title ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border hover:bg-muted'}`}>
                                ไม่มีฉายา
                            </button>
                             {titles.map((t, idx) => (
                                <button key={idx} onClick={() => selectCustomization('title', t.value)}
                                    className={`relative px-4 py-2 rounded-xl text-sm border transition ${
                                        student.title === t.value ? 'bg-amber-100 text-amber-700 border-amber-300 font-bold' : 'bg-card border-border hover:bg-muted'
                                    }`}>
                                    {t.name}
                                    {student.title === t.value && <Check size={12} className="absolute -top-1 -right-1 bg-amber-500 text-white rounded-full p-0.5" />}
                                </button>
                            ))}
                        </div>
                    </section>

                    {/* Frames */}
                    <section>
                        <h3 className="font-bold mb-3 px-1">กรอบรูปของคุณ ({frames.length})</h3>
                        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                            <button onClick={() => selectCustomization('frame', '')}
                                className={`aspect-square rounded-2xl border flex flex-col items-center justify-center gap-1 transition ${!student.profile_frame ? 'bg-primary/10 border-primary text-primary' : 'bg-card border-border hover:bg-muted'}`}>
                                <User size={24} className="opacity-20" />
                                <span className="text-[10px] font-bold">ดั้งเดิม</span>
                            </button>
                            {frames.map((f, idx) => (
                                <button key={idx} onClick={() => selectCustomization('frame', f.value)}
                                    className={`relative aspect-square rounded-2xl border overflow-hidden p-2 transition ${student.profile_frame === f.value ? 'border-primary ring-2 ring-primary/20 bg-primary/5' : 'border-border bg-card hover:bg-muted'}`}>
                                    <img src={f.value} alt={f.name} className="w-full h-full object-contain" />
                                    {student.profile_frame === f.value && (
                                        <div className="absolute inset-0 bg-primary/10 flex items-center justify-center">
                                            <Check size={20} className="text-primary bg-white rounded-full p-1 shadow-sm" />
                                        </div>
                                    )}
                                </button>
                            ))}
                        </div>
                    </section>

                    {/* Name Background Colors */}
                    <section>
                        <h3 className="font-bold mb-3 px-1">สีพื้นหลังชื่อ ({nameBgs.length})</h3>
                        <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                            <button onClick={() => selectCustomization('name_bg', '')}
                                className={`aspect-square rounded-2xl border-2 transition flex flex-col items-center justify-center gap-1 ${!student.name_bg_color ? 'border-primary bg-primary/5 text-primary' : 'border-border bg-card hover:bg-muted'}`}>
                                <div className="w-6 h-6 rounded-full border border-dashed border-muted-foreground/30" />
                                <span className="text-[10px] font-bold">เดิม</span>
                                {!student.name_bg_color && <Check size={12} className="absolute -top-1 -right-1 bg-primary text-white rounded-full p-0.5" />}
                            </button>
                            {nameBgs.map((c, idx) => (
                                <button key={idx} onClick={() => selectCustomization('name_bg', c.value)}
                                    className={`relative aspect-square rounded-2xl border-2 transition hover:scale-105 flex flex-col items-center justify-center gap-1 shadow-sm ${student.name_bg_color === c.value ? 'border-primary ring-2 ring-primary/20' : 'border-transparent'}`}
                                    style={{ background: c.value.includes('gradient') ? c.value : `${c.value}11` }}>
                                    <div className="w-8 h-8 rounded-full shadow-inner border border-white/20" style={{ background: c.value }} />
                                    <span className={`text-[9px] font-black truncate w-full px-1 ${c.value.includes('gradient') ? 'text-white drop-shadow-sm' : ''}`} style={{ color: c.value.includes('gradient') ? 'white' : c.value }}>
                                        {c.name || 'พรีเซ็ท'}
                                    </span>
                                    {student.name_bg_color === c.value && <Check size={12} className="absolute -top-1 -right-1 bg-primary text-white rounded-full p-0.5" />}
                                </button>
                            ))}
                        </div>
                    </section>
                </div>
            </div>
            {saving && (
                <div className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-black/80 text-white px-6 py-3 rounded-full text-sm font-bold animate-in slide-in-from-bottom-4">
                    กำลังบันทึก...
                </div>
            )}
        </div>
    );
}
