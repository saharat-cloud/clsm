import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import StudentAvatar from '@/components/ui/StudentAvatar';

export default function StudentRanking() {
    const navigate = useNavigate();
    const [student, setStudent] = useState(null);
    const [ranked, setRanked] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [filterSubj, setFilterSubj] = useState('');
    const [tab, setTab] = useState('points');

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) { navigate('/student/login'); return; }
        const std = JSON.parse(session);
        setStudent(std);
        async function loadData() {
            // 1. Fetch semesters first to know which one is active
            const allSemesters = await base44.entities.Semester.filter({ teacher_id: 'kanit_admin' });
            const activeSem = allSemesters.find(s => s.is_active) || allSemesters[0];

            const adminFilter = {
                ...(activeSem ? { 
                    semester_academic_year: activeSem.academic_year, 
                    semester_number: activeSem.semester 
                } : {}),
                teacher_id: 'kanit_admin'
            };

            const filter = {
                ...(activeSem ? { 
                    semester_academic_year: activeSem.academic_year, 
                    semester_number: activeSem.semester 
                } : {})
            };

            // 2. Classrooms and student rosters are managed by the admin
            const allCls = await base44.entities.Classroom.filter(adminFilter);
            const myCls = allCls.filter(c => (c.student_ids || []).includes(std.id));
            const myClsIds = myCls.map(c => c.id);
            
            // Get all unique student DB IDs in these classrooms
            const peerDbIds = [...new Set(myCls.flatMap(c => c.student_ids || []))];

            if (myClsIds.length > 0) {
                const [allStudents, sc, subs, asgns, allSubmissions] = await Promise.all([
                    base44.entities.Student.filter({ id: { in: peerDbIds } }),
                    base44.entities.ScoreRecord.filter({ ...filter, classroom_id: { in: myClsIds } }),
                    base44.entities.Subject.filter({ ...filter, classroom_id: { in: myClsIds } }),
                    base44.entities.Assignment.filter({ ...filter, classroom_id: { in: myClsIds } }),
                    base44.entities.Submission.filter({ ...filter, classroom_id: { in: myClsIds }, status: 'graded' }),
                ]);

                setClassrooms(allCls);
                setSubjects(subs);
                setAssignments(asgns);

                const peersWithStats = allStudents.map(p => ({
                    ...p,
                    total_score: getTotalScore(p.student_id, sc, asgns, allSubmissions, filterSubj)
                }));
                setRanked(peersWithStats);
            } else {
                setRanked([]);
            }
        }
        loadData();
    }, [filterSubj]); // Re-run effect when filterSubj changes to recalculate scores

    // Helper function to calculate total score for a student
    const getTotalScore = (studentId, allScores, allAssignments, allSubmissions, currentFilterSubj) => {
        const manualScore = allScores.filter(s => {
            if (s.student_id !== studentId) return false;
            if (currentFilterSubj && s.subject_id !== currentFilterSubj) return false;
            return true;
        }).reduce((sum, s) => sum + (s.score || 0), 0);

        const assignmentScore = allSubmissions.filter(s => {
            if (s.student_id !== studentId) return false;
            const asgn = allAssignments.find(a => a.id === s.assignment_id);
            if (!asgn || s.status !== 'graded') return false; // Only graded submissions count
            if (currentFilterSubj && asgn.subject_id !== currentFilterSubj) return false;
            return true;
        }).reduce((sum, s) => sum + (s.score || 0), 0);

        return manualScore + assignmentScore;
    };

    if (!student) return null;

    // Filter peers by subject if selected
    // Note: To be in the ranking for a subject, the peer must be in *at least one classroom* that teaches this subject
    const subjectClassroomIds = filterSubj
        ? [...new Set(assignments.filter(a => a.subject_id === filterSubj).map(a => a.classroom_id))]
        : [];

    const displayPeers = filterSubj
        ? ranked.filter(s => classrooms.some(c => subjectClassroomIds.includes(c.id) && c.student_ids?.includes(s.id)))
        : ranked;

    const scoreRanking = [...displayPeers].sort((a, b) => (b.total_score || 0) - (a.total_score || 0));
    const pointRanking = [...displayPeers].sort((a, b) => (b.total_points || 0) - (a.total_points || 0));
    
    const displayRanking = tab === 'score' ? scoreRanking : pointRanking;

    const medalColors = ['text-yellow-500', 'text-gray-400', 'text-amber-600'];

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-2xl mx-auto px-4 py-8">
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-6">
                    <div className="flex items-center gap-3">
                        <Link to="/student" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                        <h1 className="text-2xl font-bold">แรงค์กิ้ง</h1>
                    </div>
                    <div className="sm:ml-auto flex gap-2 w-full sm:w-auto">
                        {tab === 'score' && (
                            <select value={filterSubj} onChange={e => setFilterSubj(e.target.value)}
                                className="flex-1 sm:flex-none border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none">
                                <option value="">ทุกวิชา</option>
                                {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                            </select>
                        )}
                    </div>
                </div>

                <div className="flex bg-muted rounded-xl p-1 mb-6">
                    {[{ key: 'score', label: '📊 คะแนนเก็บ' }, { key: 'points', label: '⭐ แต้มสะสม' }].map(t => (
                        <button key={t.key} onClick={() => setTab(t.key)}
                            className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${tab === t.key ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`}>
                            {t.label}
                        </button>
                    ))}
                </div>

                <div className="grid gap-3">
                    {displayRanking.map((s, i) => {
                        const isMe = s.student_id === student.student_id;
                        const hasBg = s.name_bg_color;
                        const isGradient = hasBg?.includes('gradient');
                        
                        return (
                            <div key={s.id}
                                className={`flex items-center gap-4 p-4 rounded-2xl border transition-all ${isMe ? 'border-primary ring-2 ring-primary/5 shadow-sm' : 'border-border bg-card'}`}
                                style={hasBg ? {
                                    background: isGradient ? hasBg : `${hasBg}11`,
                                    color: isGradient ? 'white' : 'inherit',
                                    borderColor: isGradient ? 'transparent' : `${hasBg}33`
                                } : {}}
                            >
                                <div className={`w-8 text-center font-bold text-lg ${isGradient ? 'text-white' : (i < 3 ? medalColors[i] : 'text-muted-foreground')}`}>
                                    {i < 3 ? '🏅' : i + 1}
                                </div>
                                <StudentAvatar student={s} size={40} showTitle={true} />
                                <div className="flex-1">
                                    <p className="font-semibold">
                                        <span className={isGradient ? '' : `student-name-${s.student_id}`}>{s.first_name} {s.last_name}</span>
                                        {isMe && <span className={`ml-2 text-xs ${isGradient ? 'text-white/80' : 'text-primary'}`}>(คุณ)</span>}
                                    </p>
                                    <p className={`text-xs font-mono ${isGradient ? 'text-white/60' : 'text-muted-foreground'}`}>{s.student_id}</p>
                                </div>
                                <div className="text-right">
                                    <p className={`font-bold ${isGradient ? 'text-white' : (tab === 'score' ? 'text-blue-600' : 'text-amber-600')}`}>
                                        {tab === 'score' ? (s.total_score || 0) : (s.total_points || 0)}
                                    </p>
                                    <p className={`text-xs ${isGradient ? 'text-white/70' : 'text-muted-foreground'}`}>{tab === 'score' ? 'คะแนน' : 'แต้ม'}</p>
                                </div>
                            </div>
                        );
                    })}
                    {displayRanking.length === 0 && <p className="text-center py-16 text-muted-foreground">ยังไม่มีข้อมูล</p>}
                </div>
            </div>
        </div>
    );
}