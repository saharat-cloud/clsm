import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export default function StudentScores() {
    const navigate = useNavigate();
    const [student, setStudent] = useState(null);
    const [scores, setScores] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [submissions, setSubmissions] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);

    useEffect(() => {
        const session = localStorage.getItem('student_session');
        if (!session) { navigate('/student/login'); return; }
        const std = JSON.parse(session);
        setStudent(std);
        async function load() {
            // Classrooms are managed by admin
            const cls = await base44.entities.Classroom.filter({ teacher_id: 'kanit_admin' });
            const myCls = cls.filter(c => (c.student_ids || []).includes(std.id));
            const myClsIds = myCls.map(c => c.id);

            if (myClsIds.length > 0) {
                const [sc, subs, asgns, allSubmissions] = await Promise.all([
                    base44.entities.ScoreRecord.filter({ student_id: std.student_id, classroom_id: { in: myClsIds } }),
                    base44.entities.Subject.filter({ classroom_id: { in: myClsIds } }),
                    base44.entities.Assignment.filter({ classroom_id: { in: myClsIds } }),
                    base44.entities.Submission.filter({ student_id: std.student_id, status: 'graded' }),
                ]);
                setScores(sc);
                setAssignments(asgns);
                setSubmissions(allSubmissions);
                setClassrooms(myCls);
                setSubjects(subs);
            } else {
                setScores([]);
                setAssignments([]);
                setSubmissions([]);
                setClassrooms([]);
                setSubjects([]);
            }
        }
        load();
    }, []);

    const subMap = Object.fromEntries(subjects.map(s => [s.id, s]));

    const grouped = classrooms.map(cls => {
        const subject = subMap[cls.subject_id];
        const grading = subject?.grading_criteria || { assignment: 20, affective: 10, midterm: 30, final: 40, grades: { 4: 80, 3.5: 75, 3: 70, 2.5: 65, 2: 60, 1.5: 55, 1: 50, 0: 0 } };

        const clsScores = scores.filter(s => s.classroom_id === cls.id);
        const manualRecords = clsScores.map(r => ({ ...r, is_assignment: false }));
        
        const clsAssignments = assignments.filter(a => a.classroom_id === cls.id && a.is_graded !== false);
        const assignmentRecords = submissions
            .map(sub => {
                const asgn = clsAssignments.find(a => a.id === sub.assignment_id);
                return { sub, asgn };
            })
            .filter(({ asgn }) => asgn)
            .map(({ sub, asgn }) => ({
                id: sub.id,
                score_type: asgn.title,
                score: sub.score,
                max_score: asgn.max_score,
                note: sub.feedback || '',
                is_assignment: true
            }));

        const allRecords = [...manualRecords, ...assignmentRecords];

        let assignmentReceived = 0;
        let assignmentMax = 0;
        assignmentRecords.forEach(r => {
            assignmentReceived += r.score || 0;
            assignmentMax += r.max_score || 0;
        });
        const scaledAssignment = assignmentMax === 0 ? 0 : (assignmentReceived / assignmentMax) * (grading.assignment || 0);

        function getRecScore(type) {
            const rec = clsScores.find(s => s.score_type === type);
            return rec ? rec.score || 0 : 0;
        }

        const aff = getRecScore('จิตพิสัย');
        const mid = getRecScore('สอบกลางภาค');
        const fin = getRecScore('สอบปลายภาค');
        
        const total = scaledAssignment + aff + mid + fin;
        
        let grade = '-';
        if (grading.grades) {
            const sorted = Object.entries(grading.grades).sort((a,b) => b[1] - a[1]);
            for (const [g, min] of sorted) {
                if (total >= min) { grade = g; break; }
            }
            if (grade === '-') grade = '0';
        }

        return {
            classroom: cls,
            subject,
            records: allRecords,
            summary: {
                scaledAssignment: scaledAssignment.toFixed(1),
                assignmentWeight: grading.assignment,
                affective: aff,
                affWeight: grading.affective,
                midterm: mid,
                midWeight: grading.midterm,
                final: fin,
                finWeight: grading.final,
                total: total.toFixed(1),
                grade
            }
        };
    });

    if (!student) return null;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-3xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/student" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <h1 className="text-2xl font-bold">คะแนนเก็บของฉัน</h1>
                </div>

                {grouped.length === 0 && (
                    <div className="text-center py-16 text-muted-foreground">ยังไม่มีคะแนน</div>
                )}

                {grouped.map(g => (
                    <div key={g.classroom.id} className="bg-card border border-border rounded-2xl p-5 mb-4">
                        <div className="flex items-center justify-between mb-4">
                            <div>
                                <h2 className="font-bold text-lg">{g.classroom.name}</h2>
                                <p className="text-sm text-muted-foreground">{g.subject?.name || ''}</p>
                            </div>
                            <div className="text-right">
                                <p className="text-3xl font-black text-primary drop-shadow-sm">{g.summary.grade}</p>
                                <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider mt-1">เกรด</p>
                            </div>
                        </div>

                        <div className="bg-card border border-border/60 shadow-inner p-3 rounded-xl mb-4 grid grid-cols-5 gap-2 text-center divide-x divide-border">
                            <div><p className="text-[10px] text-muted-foreground mb-1">งาน</p><p className="font-bold text-sm text-blue-600">{g.summary.scaledAssignment}/{g.summary.assignmentWeight}</p></div>
                            <div><p className="text-[10px] text-muted-foreground mb-1">จิตพิสัย</p><p className="font-bold text-sm text-purple-600">{g.summary.affective}/{g.summary.affWeight}</p></div>
                            <div><p className="text-[10px] text-muted-foreground mb-1">กลางภาค</p><p className="font-bold text-sm text-emerald-600">{g.summary.midterm}/{g.summary.midWeight}</p></div>
                            <div><p className="text-[10px] text-muted-foreground mb-1">ปลายภาค</p><p className="font-bold text-sm text-orange-600">{g.summary.final}/{g.summary.finWeight}</p></div>
                            <div><p className="text-[10px] text-muted-foreground mb-1">รวมสุทธิ</p><p className="font-bold text-sm text-primary bg-primary/10 rounded px-1">{g.summary.total}/100</p></div>
                        </div>

                        {g.records.length === 0 ? (
                            <p className="text-sm text-muted-foreground text-center py-3">ยังไม่มีคะแนน</p>
                        ) : (
                            <div className="space-y-2">
                                <p className="text-xs font-semibold text-muted-foreground mb-2 mt-4">รายละเอียดส่วนคะแนนดิบ</p>
                                {g.records.map(r => (
                                    <div key={r.id} className="flex items-center gap-3 p-3 bg-muted/30 rounded-xl">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2">
                                                <p className="text-sm font-medium">{r.score_type}</p>
                                                {r.is_assignment && <span className="text-[10px] text-blue-500 bg-blue-50 px-1.5 rounded border border-blue-100">งาน</span>}
                                            </div>
                                            {r.note && <p className="text-xs text-muted-foreground">{r.note}</p>}
                                        </div>
                                        <div className="text-right">
                                            <p className="font-bold">{r.score}<span className="text-muted-foreground text-xs">/{r.max_score}</span></p>
                                            <div className="h-1.5 w-20 bg-muted rounded-full mt-1 overflow-hidden">
                                                <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(100, (r.score / r.max_score) * 100)}%` }} />
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
}