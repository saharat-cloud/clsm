import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Pencil, CheckCircle, Clock, AlertCircle, Download, Trash2 } from 'lucide-react';
import { playDelete } from '@/lib/sound';
import { alerts } from '@/utils/alerts';
import { useAuth } from '@/lib/AuthContext';

export default function AssignmentDetail() {
    const { user } = useAuth();
    const { id } = useParams();
    const navigate = useNavigate();
    const [assignment, setAssignment] = useState(null);
    const [classroom, setClassroom] = useState(null);
    const [submissions, setSubmissions] = useState([]);
    const [students, setStudents] = useState([]);
    const [gradingId, setGradingId] = useState(null);
    const [historySub, setHistorySub] = useState(null);
    const [gradeForm, setGradeForm] = useState({ score: '', feedback: '' });

    async function load() {
        if (!user) return;
        const [asgns, subs] = await Promise.all([
            base44.entities.Assignment.filter({ id, teacher_id: user.id }),
            base44.entities.Submission.filter({ assignment_id: id, teacher_id: user.id }),
        ]);
        const a = asgns[0];
        setAssignment(a);
        setSubmissions(subs);
        if (a?.classroom_id) {
            const [cls] = await base44.entities.Classroom.filter({ id: a.classroom_id, teacher_id: user.id });
            setClassroom(cls);
            const allStudents = await base44.entities.Student.filter({ teacher_id: user.id });
            const enrolled = allStudents.filter(s => (cls?.student_ids || []).includes(s.id));
            setStudents(enrolled);
        }
    }

    useEffect(() => { load(); }, [id]);

    const subMap = Object.fromEntries(submissions.map(s => [s.student_id, s]));

    async function handleGrade(e) {
        e.preventDefault();
        const sub = submissions.find(s => s.id === gradingId);

        // Snapshot old submission scores for rank computation
        const oldSubs = await base44.entities.Submission.filter({ assignment_id: id, teacher_id: user.id });
        const oldScoreMap = Object.fromEntries(oldSubs.map(s => [s.student_id, s.score || 0]));
        const oldRanked = [...students].sort((a, b) =>
            (oldScoreMap[b.student_id] || 0) - (oldScoreMap[a.student_id] || 0)
        );
        const oldRank = oldRanked.findIndex(s => s.student_id === sub?.student_id) + 1;

        await base44.entities.Submission.update(gradingId, {
            score: Number(gradeForm.score),
            feedback: gradeForm.feedback,
            status: 'graded',
            graded_at: new Date().toISOString(),
        });

        // Send real-time notification to student
        if (sub?.student_id) {
            const feedbackPart = gradeForm.feedback ? ` • ${gradeForm.feedback}` : '';
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: sub.student_id,
                title: '📝 ครูตรวจงานแล้ว',
                message: `งาน "${assignment.title}" ได้รับ ${gradeForm.score}/${assignment.max_score} คะแนน${feedbackPart}`,
                type: 'grade_received',
                is_read: false,
            });

            // Score rank change notification — only for top 5 in this assignment
            const newScoreMap = { ...oldScoreMap, [sub.student_id]: Number(gradeForm.score) };
            const newRanked = [...students].sort((a, b) =>
                (newScoreMap[b.student_id] || 0) - (newScoreMap[a.student_id] || 0)
            );
            const newRank = newRanked.findIndex(s => s.student_id === sub.student_id) + 1;
            if ((oldRank <= 5 || newRank <= 5) && oldRank !== newRank && oldRank > 0 && newRank > 0) {
                const direction = newRank < oldRank ? 'ขึ้น' : 'ตก';
                await base44.entities.Notification.create({
                    teacher_id: user.id,
                    student_id: sub.student_id,
                    title: `📊 แรงค์คะแนน${direction}!`,
                    message: `อันดับในงาน "${assignment.title}" เปลี่ยนจาก #${oldRank} → #${newRank}`,
                    type: 'rank_changed_score',
                    is_read: false,
                });
            }
        }
        setGradingId(null);
        load();
    }

    async function handleApproveEdit(sub) {
        await base44.entities.Submission.update(sub.id, { edit_request_status: 'approved' });
        await base44.entities.Notification.create({
            teacher_id: user.id,
            student_id: sub.student_id,
            title: '✅ ครูอนุมัติให้แก้ไขงาน',
            message: `งาน "${assignment.title}" ได้รับการอนุมัติให้แก้ไขแล้ว กรุณาส่งงานใหม่`,
            type: 'edit_approved',
            is_read: false,
        });
        load();
    }

    async function handleRejectEdit(sub) {
        await base44.entities.Submission.update(sub.id, { edit_request_status: 'rejected' });
        await base44.entities.Notification.create({
            teacher_id: user.id,
            student_id: sub.student_id,
            title: '❌ ครูปฏิเสธการแก้ไขงาน',
            message: `คำขอแก้ไขงาน "${assignment.title}" ถูกปฏิเสธ`,
            type: 'edit_rejected',
            is_read: false,
        });
        load();
    }

    async function handleDelete() {
        if (!await alerts.confirmDanger('ลบงานชิ้นนี้', 'คุณต้องการลบงานนี้ใช่หรือไม่?\nผลงานและคะแนนของนักเรียนจะถูกลบไปด้วย')) return;
        playDelete();
        await base44.entities.Assignment.delete(id);
        navigate('/teacher/assignments');
    }

    if (!assignment) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;

    const now = new Date();
    const submitted = submissions.length;
    const graded = submissions.filter(s => s.status === 'graded').length;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-5xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher/assignments" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <div className="flex-1">
                        <h1 className="text-2xl font-bold">{assignment.title}</h1>
                        <p className="text-muted-foreground text-sm">{classroom?.name} • กำหนดส่ง: {new Date(assignment.due_date).toLocaleString('th-TH')}</p>
                    </div>
                    <div className="flex gap-2">
                        <Link to={`/teacher/assignments/${id}/edit`}
                            className="flex items-center gap-2 border border-border px-3 py-2 rounded-xl text-sm hover:bg-muted transition">
                            <Pencil size={15} /> แก้ไข
                        </Link>
                        <button onClick={handleDelete}
                            className="flex items-center gap-2 border border-destructive/30 text-destructive px-3 py-2 rounded-xl text-sm hover:bg-destructive/10 transition">
                            <Trash2 size={15} /> ลบ
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-6">
                    {[
                        { label: 'นักเรียนทั้งหมด', value: students.length, color: 'text-foreground' },
                        { label: 'ส่งงานแล้ว', value: submitted, color: 'text-blue-600' },
                        { label: 'ตรวจแล้ว', value: graded, color: 'text-green-600' },
                    ].map(s => (
                        <div key={s.label} className="bg-card border border-border rounded-2xl p-4 text-center">
                            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
                        </div>
                    ))}
                </div>

                <div className="bg-card border border-border rounded-2xl overflow-hidden">
                    <table className="w-full text-sm">
                        <thead className="bg-muted/50">
                            <tr>
                                <th className="text-left px-4 py-3 text-muted-foreground font-medium">นักเรียน</th>
                                <th className="text-left px-4 py-3 text-muted-foreground font-medium">สถานะ</th>
                                <th className="text-left px-4 py-3 text-muted-foreground font-medium">ไฟล์</th>
                                <th className="text-left px-4 py-3 text-muted-foreground font-medium">คะแนน</th>
                                <th className="px-4 py-3"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                            {students.map(s => {
                                const sub = subMap[s.student_id];
                                return (
                                    <tr key={s.id} className="hover:bg-muted/20">
                                        <td className="px-4 py-3">
                                            <p className="font-medium">{s.first_name} {s.last_name}</p>
                                            <p className="text-xs text-muted-foreground font-mono">{s.student_id}</p>
                                        </td>
                                        <td className="px-4 py-3">
                                            {!sub ? (
                                                <span className="flex items-center gap-1 text-muted-foreground text-xs"><AlertCircle size={14} /> ยังไม่ส่ง</span>
                                            ) : sub.is_late ? (
                                                <span className="flex items-center gap-1 text-orange-500 text-xs"><Clock size={14} /> ส่งเลท</span>
                                            ) : sub.status === 'graded' ? (
                                                <span className="flex items-center gap-1 text-green-600 text-xs"><CheckCircle size={14} /> ตรวจแล้ว</span>
                                            ) : (
                                                <span className="flex items-center gap-1 text-blue-600 text-xs"><CheckCircle size={14} /> ส่งแล้ว</span>
                                            )}
                                        </td>
                                        <td className="px-4 py-3">
                                            {sub?.file_urls?.length > 0 ? (
                                                <div className="flex gap-1">
                                                    {sub.file_urls.map((url, i) => (
                                                        <a key={i} href={url} target="_blank" rel="noreferrer"
                                                            className="flex items-center gap-1 text-xs text-primary hover:underline">
                                                            <Download size={12} /> ไฟล์ {i + 1}
                                                        </a>
                                                    ))}
                                                </div>
                                            ) : <span className="text-xs text-muted-foreground">-</span>}
                                        </td>
                                        <td className="px-4 py-3">
                                            {sub?.status === 'graded' ? (
                                                <span className="font-bold text-green-600">{sub.score}/{assignment.max_score}</span>
                                            ) : <span className="text-muted-foreground">-</span>}
                                        </td>
                                        <td className="px-4 py-3 flex items-center gap-2 flex-wrap">
                                            {sub && sub.status !== 'graded' && (
                                                <button onClick={() => { setGradingId(sub.id); setGradeForm({ score: '', feedback: '' }); }}
                                                    className="text-xs bg-primary text-primary-foreground px-3 py-1 rounded-lg hover:opacity-90">
                                                    ตรวจงาน
                                                </button>
                                            )}
                                            {sub?.status === 'graded' && (
                                                <button onClick={() => { setGradingId(sub.id); setGradeForm({ score: sub.score, feedback: sub.feedback || '' }); }}
                                                    className="text-xs border border-border px-3 py-1 rounded-lg hover:bg-muted">
                                                    แก้ไข
                                                </button>
                                            )}
                                            {sub?.edit_request_status === 'pending' && (
                                                <div className="flex items-center gap-1">
                                                    <span className="text-[10px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full font-semibold whitespace-nowrap">ขอแก้ไข</span>
                                                    <button onClick={() => handleApproveEdit(sub)}
                                                        className="text-xs bg-green-500 text-white px-2 py-1 rounded-lg hover:opacity-90">
                                                        ✓ ยอมรับ
                                                    </button>
                                                    <button onClick={() => handleRejectEdit(sub)}
                                                        className="text-xs bg-red-500 text-white px-2 py-1 rounded-lg hover:opacity-90">
                                                        ✕ ปฏิเสธ
                                                    </button>
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>

            {gradingId && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                    <div className="bg-card rounded-2xl shadow-xl w-full max-w-md p-6">
                        <h2 className="text-lg font-bold mb-4">ให้คะแนน</h2>
                        <form onSubmit={handleGrade} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-1">คะแนน (เต็ม {assignment.max_score})</label>
                                <input type="number" required min={0} max={assignment.max_score}
                                    value={gradeForm.score} onChange={e => setGradeForm({ ...gradeForm, score: e.target.value })}
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-1">ความคิดเห็น</label>
                                <textarea value={gradeForm.feedback} onChange={e => setGradeForm({ ...gradeForm, feedback: e.target.value })}
                                    rows={3} className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
                            </div>
                            <div className="flex gap-3">
                                <button type="button" onClick={() => setGradingId(null)} className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted transition">ยกเลิก</button>
                                <button type="submit" className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition">บันทึกคะแนน</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

        </div>
    );
}