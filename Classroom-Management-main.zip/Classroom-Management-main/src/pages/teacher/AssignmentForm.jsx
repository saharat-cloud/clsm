import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft } from 'lucide-react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';
import { useSemester } from '@/lib/SemesterContext';

export default function AssignmentForm() {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const { id } = useParams();
    const navigate = useNavigate();
    const isEdit = id && id !== 'new';
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [form, setForm] = useState({
        title: '', description: '', classroom_ids: [], subject_id: '',
        due_date: '', max_score: 100, late_policy: 'allow_late', is_graded: true,
        exp_reward: 50
    });

    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const cls = params.get('classroom');
        const subId = params.get('subject');
        async function load() {
            if (!user) return;
            const [clsList, subList] = await Promise.all([
                base44.entities.Classroom.filter({ teacher_id: user.id }),
                base44.entities.Subject.filter({ teacher_id: user.id }),
            ]);
            setClassrooms(clsList);
            setSubjects(subList);
            if (cls) setForm(f => ({ ...f, classroom_ids: [cls] }));
            if (subId) setForm(f => ({ ...f, subject_id: subId }));
            if (isEdit) {
                const [a] = await base44.entities.Assignment.filter({ id });
                if (a) {
                    setForm({
                        title: a.title, description: a.description || '',
                        classroom_ids: [a.classroom_id], subject_id: a.subject_id,
                        due_date: a.due_date?.slice(0, 16) || '',
                        max_score: a.max_score, late_policy: a.late_policy || 'allow_late',
                        is_graded: a.is_graded !== false,
                        exp_reward: a.exp_reward || 50
                    });
                }
            }
        }
        load();
    }, [id, user]);

    const { toast } = useToast();

    // Auto-fill subject from classroom if only one subject is available
    useEffect(() => {
        if (form.classroom_ids.length > 0 && !isEdit) {
            const selectedCls = classrooms.filter(c => form.classroom_ids.includes(c.id));
            const allSubjectIds = new Set();
            selectedCls.forEach(c => (c.subject_ids || []).forEach(sid => allSubjectIds.add(sid)));
            
            if (allSubjectIds.size === 1) {
                setForm(f => ({ ...f, subject_id: Array.from(allSubjectIds)[0] }));
            }
        }
    }, [form.classroom_ids, classrooms, isEdit]);

    // Derived state for available subjects based on selected classrooms
    const availableSubjects = form.classroom_ids.length > 0 
        ? subjects.filter(s => {
            const selectedCls = classrooms.filter(c => form.classroom_ids.includes(c.id));
            // Return true if the subject is assigned to ALL of the selected classrooms
            return selectedCls.every(c => (c.subject_ids || []).includes(s.id));
        })
        : subjects;

    async function handleSubmit(e) {
        e.preventDefault();
        if (form.classroom_ids.length === 0) {
            toast({
                title: "ข้อมูลไม่ครบถ้วน",
                description: "กรุณาเลือกห้องเรียนอย่างน้อย 1 ห้อง",
                variant: "destructive"
            });
            return;
        }

        const baseData = {
            title: form.title,
            description: form.description,
            subject_id: form.subject_id,
            due_date: form.due_date,
            max_score: Number(form.max_score),
            late_policy: form.late_policy,
            is_graded: form.is_graded,
            exp_reward: Number(form.exp_reward),
            semester_academic_year: activeSemester?.academic_year || null,
            semester_number: activeSemester?.semester || null
        };

        if (isEdit) {
            await base44.entities.Assignment.update(id, { ...baseData, classroom_id: form.classroom_ids[0], teacher_id: user.id });
        } else {
            await Promise.all(form.classroom_ids.map(cid =>
                base44.entities.Assignment.create({ ...baseData, classroom_id: cid, teacher_id: user.id })
            ));
        }
        navigate('/teacher/assignments');
    }

    function toggleClassroom(cid) {
        const isAdding = !form.classroom_ids.includes(cid);
        
        if (isAdding && form.subject_id) {
            const classroomToAdd = classrooms.find(c => c.id === cid);
            if (classroomToAdd && !(classroomToAdd.subject_ids || []).includes(form.subject_id)) {
                toast({
                    title: "ไม่สามารถเลือกห้องนี้ได้",
                    description: `ห้อง ${classroomToAdd.name} ไม่ได้เรียนวิชาที่เลือกไว้`,
                    variant: "destructive"
                });
                return;
            }
        }

        setForm(f => {
            const ids = new Set(f.classroom_ids);
            if (ids.has(cid)) ids.delete(cid);
            else ids.add(cid);
            
            // Re-validate current subject against all selected classrooms
            const newIds = Array.from(ids);
            let nextSubjectId = f.subject_id;
            
            if (nextSubjectId && newIds.length > 0) {
                const selectedCls = classrooms.filter(c => newIds.includes(c.id));
                const allHaveSubject = selectedCls.every(c => (c.subject_ids || []).includes(nextSubjectId));
                if (!allHaveSubject) {
                    nextSubjectId = ''; // Clear subject if no longer valid for all
                }
            }

            return { ...f, classroom_ids: newIds, subject_id: nextSubjectId };
        });
    }

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-2xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-8">
                    <Link to="/teacher/assignments" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <h1 className="text-2xl font-bold">{isEdit ? 'แก้ไขงาน' : 'สั่งงานใหม่'}</h1>
                </div>

                <form onSubmit={handleSubmit} className="bg-card border border-border rounded-2xl p-6 space-y-5">
                    <div>
                        <label className="block text-sm font-medium mb-1">ชื่องาน *</label>
                        <input required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })}
                            className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">คำอธิบาย</label>
                        <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                            rows={3} className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
                    </div>
                    
                    <div>
                        <label className="block text-sm font-medium mb-2">ห้องเรียน *</label>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                            {classrooms.map(c => (
                                <label key={c.id} className={`flex items-center justify-center gap-2 p-3 text-sm rounded-xl border cursor-pointer transition select-none ${form.classroom_ids.includes(c.id) ? 'border-primary bg-primary/10 text-primary font-medium' : 'border-border bg-background hover:bg-muted font-normal text-muted-foreground'}`}>
                                    <input type="checkbox" className="hidden" 
                                        checked={form.classroom_ids.includes(c.id)} 
                                        onChange={() => toggleClassroom(c.id)}
                                        disabled={isEdit && c.id !== form.classroom_ids[0]} />
                                    {c.name}
                                </label>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium mb-1">รายวิชา *</label>
                        <select required value={form.subject_id} onChange={e => setForm({ ...form, subject_id: e.target.value })}
                            className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                            <option value="">-- เลือกวิชา --</option>
                            {availableSubjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium mb-1">วันกำหนดส่ง *</label>
                            <input type="datetime-local" required value={form.due_date} onChange={e => setForm({ ...form, due_date: e.target.value })}
                                className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">คะแนนเต็ม *</label>
                            <input type="number" required min={1} value={form.max_score} onChange={e => setForm({ ...form, max_score: Number(e.target.value) })}
                                className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">🎁 EXP ที่จะได้รับ *</label>
                            <input type="number" required min={0} value={form.exp_reward} onChange={e => setForm({ ...form, exp_reward: Number(e.target.value) })}
                                className="w-full border border-amber-200 bg-amber-50/20 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-2">นโยบายเมื่อเลยกำหนด *</label>
                        <div className="grid grid-cols-2 gap-3">
                            {[
                                { value: 'allow_late', label: '⚠️ รับแต่ขึ้นว่า "ส่งเลท"' },
                                { value: 'no_submit', label: '❌ ไม่รับงานหลังกำหนด' },
                            ].map(opt => (
                                <label key={opt.value} className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition ${form.late_policy === opt.value ? 'border-primary bg-accent' : 'border-border hover:bg-muted/50'}`}>
                                    <input type="radio" name="late_policy" value={opt.value} checked={form.late_policy === opt.value} onChange={e => setForm({ ...form, late_policy: e.target.value })} className="hidden" />
                                    <span className="text-sm">{opt.label}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                    <label className="flex items-center gap-3 cursor-pointer mt-4">
                        <input type="checkbox" checked={form.is_graded} onChange={e => setForm({ ...form, is_graded: e.target.checked })}
                            className="w-4 h-4 rounded text-primary focus:ring-primary border-gray-300" />
                        <span className="text-sm">นับคะแนนเก็บ</span>
                    </label>
                    <div className="flex gap-3 pt-4">
                        <Link to="/teacher/assignments" className="flex-1 border border-border rounded-xl py-2 text-sm text-center hover:bg-muted transition font-medium">ยกเลิก</Link>
                        <button type="submit" className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition">บันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    );
}