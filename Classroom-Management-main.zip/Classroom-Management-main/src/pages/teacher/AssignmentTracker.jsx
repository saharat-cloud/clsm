import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Bell, Download, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import * as XLSX from 'xlsx';
import { useAuth } from '@/lib/AuthContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';
import { useSemester } from '@/lib/SemesterContext';

export default function AssignmentTracker() {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [classrooms, setClassrooms] = useState([]);
    const [students, setStudents] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [submissions, setSubmissions] = useState([]);
    const [filterCls, setFilterCls] = useState('');
    const [loading, setLoading] = useState(true);
    
    // Notification state
    const [sending, setSending] = useState(null); // { student, assignment }
    const [msgTitle, setMsgTitle] = useState('');
    const [msgBody, setMsgBody] = useState('');
    const [sent, setSent] = useState(false);

    async function load() {
        if (!user) return;
        setLoading(true);
        try {
            const filter = {
                ...(activeSemester ? { 
                    semester_academic_year: activeSemester.academic_year, 
                    semester_number: activeSemester.semester 
                } : {}),
                teacher_id: user.id
            };

            const adminFilter = {
                ...(activeSemester ? { 
                    semester_academic_year: activeSemester.academic_year, 
                    semester_number: activeSemester.semester 
                } : {}),
                teacher_id: 'kanit_admin'
            };

            const [cls, stds, asgns, subs] = await Promise.all([
                base44.entities.Classroom.filter(adminFilter),
                base44.entities.Student.filter(adminFilter),
                base44.entities.Assignment.filter(filter),
                base44.entities.Submission.filter(filter),
            ]);
            setClassrooms(cls); setStudents(stds); setAssignments(asgns); setSubmissions(subs);
            if (!filterCls && cls.length > 0) setFilterCls(cls[0].id);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => { load(); }, [activeSemester]);

    const cls = classrooms.find(c => c.id === filterCls);
    const enrolledStudents = students.filter(s => (cls?.student_ids || []).includes(s.id));
    const clsAssignments = assignments.filter(a => a.classroom_id === filterCls);
    const now = new Date();

    function getSubStatus(studentId, assignment) {
        const sub = submissions.find(s => s.assignment_id === assignment.id && s.student_id === studentId);
        if (sub) return 'submitted';
        if (new Date(assignment.due_date) < now) return 'overdue';
        return 'pending';
    }

    function generateExcel() {
        if (!cls) return;
        const data = enrolledStudents.map(s => {
            const row = {
                'รหัสนักเรียน': s.student_id,
                'ชื่อ': s.first_name,
                'นามสกุล': s.last_name,
            };
            clsAssignments.forEach(a => {
                const status = getSubStatus(s.student_id, a);
                row[a.title] = status === 'submitted' ? 'ส่งแล้ว' : status === 'overdue' ? 'เลยกำหนด' : 'ยังไม่ส่ง';
            });
            return row;
        });
        const worksheet = XLSX.utils.json_to_sheet(data);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "สถานะการส่งงาน");
        XLSX.writeFile(workbook, `สถานะการส่งงาน_${cls.name}.xlsx`);
    }

    function openNotify(student, assignment, status) {
        setSending({ student, assignment });
        setMsgTitle(`ติดตามงาน: ${assignment.title}`);
        if (status === 'overdue') {
            setMsgBody(`แจ้งเตือนงานค้าง: คุณยังไม่ได้ส่งงาน "${assignment.title}" ซึ่งเลยกำหนดส่งมาแล้ว กรุณารีบดำเนินการส่งงานด่วน`);
        } else {
            setMsgBody(`แจ้งเตือนงานค้าง: อย่าลืมส่งงาน "${assignment.title}" ภายในวันที่ ${new Date(assignment.due_date).toLocaleString('th-TH')}`);
        }
    }

    async function handleSendNotification(e) {
        e.preventDefault();
        await base44.entities.Notification.create({
            teacher_id: user.id,
            student_id: sending.student.student_id,
            title: msgTitle,
            message: msgBody,
            type: 'assignment_reminder',
            is_read: false,
        });
        setSent(true);
        setTimeout(() => { setSent(false); setSending(null); setMsgTitle(''); setMsgBody(''); }, 1500);
    }

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-7xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <h1 className="text-2xl font-bold">ตารางติดตามงาน (ไม่แสดงคะแนน)</h1>
                    <div className="ml-auto flex gap-2">
                        <select value={filterCls} onChange={e => setFilterCls(e.target.value)}
                            className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none">
                            {classrooms.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                        <button onClick={generateExcel}
                            className="flex items-center gap-2 bg-[#107c41] text-white px-4 py-2 rounded-xl text-sm hover:opacity-90 transition shadow-sm font-medium">
                            <Download size={16} /> Export Excel
                        </button>
                    </div>
                </div>

                <div className="bg-card border border-border rounded-2xl overflow-auto shadow-sm">
                    <table className="w-full text-sm">
                        <thead className="bg-muted/50">
                            <tr>
                                <th className="text-left px-4 py-3 text-muted-foreground font-medium sticky left-0 bg-muted/50 z-10 border-r border-border min-w-[200px]">นักเรียน</th>
                                {clsAssignments.map(a => (
                                    <th key={a.id} className="px-4 py-3 text-center text-muted-foreground font-medium min-w-[120px] max-w-[180px] truncate" title={a.title}>
                                        <div className="font-semibold text-foreground truncate">{a.title}</div>
                                        <div className="text-[10px] font-normal opacity-70">
                                            ดิว: {new Date(a.due_date).toLocaleDateString('th-TH', { day: '2-digit', month: 'short' })}
                                        </div>
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                            {enrolledStudents.map(s => (
                                <tr key={s.id} className="hover:bg-muted/10 group">
                                    <td className="px-4 py-3 sticky left-0 bg-card group-hover:bg-muted/10 border-r border-border">
                                        <p className="font-medium text-foreground">{s.first_name} {s.last_name}</p>
                                        <p className="text-xs text-muted-foreground font-mono">{s.student_id}</p>
                                    </td>
                                    {clsAssignments.map(a => {
                                        const status = getSubStatus(s.student_id, a);
                                        return (
                                            <td key={a.id} className="px-2 py-2 text-center align-middle relative">
                                                {status === 'submitted' ? (
                                                    <div className="flex flex-col items-center justify-center text-green-600">
                                                        <CheckCircle size={20} className="mb-1" />
                                                        <span className="text-[10px] bg-green-50 px-2 py-0.5 rounded-full">ส่งแล้ว</span>
                                                    </div>
                                                ) : status === 'overdue' ? (
                                                    <button onClick={() => openNotify(s, a, status)}
                                                        className="flex flex-col items-center justify-center text-red-500 hover:scale-110 hover:text-red-600 transition-transform cursor-pointer w-full h-full py-1">
                                                        <AlertCircle size={20} className="mb-1" />
                                                        <span className="text-[10px] bg-red-50 px-2 py-0.5 rounded-full flex items-center gap-1"><Bell size={8} /> เลยกำหนด</span>
                                                    </button>
                                                ) : (
                                                    <button onClick={() => openNotify(s, a, status)}
                                                        className="flex flex-col items-center justify-center text-orange-400 hover:scale-110 hover:text-orange-500 transition-transform cursor-pointer w-full h-full py-1">
                                                        <Clock size={20} className="mb-1" />
                                                        <span className="text-[10px] bg-orange-50 px-2 py-0.5 rounded-full flex items-center gap-1"><Bell size={8} /> ยังไม่ส่ง</span>
                                                    </button>
                                                )}
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                            {enrolledStudents.length === 0 && (
                                <tr><td colSpan={clsAssignments.length + 1} className="text-center py-16 text-muted-foreground">ไม่มีนักเรียนในห้องนี้</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Notification modal */}
            {sending && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                    <div className="bg-card rounded-2xl shadow-xl w-full max-w-md p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-lg font-bold">ส่งข้อความแจ้งเตือน (ทวงงาน)</h2>
                            <button onClick={() => setSending(null)} className="text-muted-foreground hover:text-foreground">✕</button>
                        </div>
                        <p className="text-sm text-primary font-medium mb-1">งาน: {sending.assignment.title}</p>
                        <p className="text-sm text-muted-foreground mb-4">ถึง: {sending.student.first_name} {sending.student.last_name} ({sending.student.student_id})</p>
                        
                        {sent ? (
                            <div className="text-center py-6">
                                <CheckCircle size={40} className="text-green-500 mx-auto mb-2" />
                                <p className="font-semibold text-green-600">ส่งข้อความสำเร็จ!</p>
                            </div>
                        ) : (
                            <form onSubmit={handleSendNotification} className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium mb-1">หัวข้อ</label>
                                    <input required value={msgTitle} onChange={e => setMsgTitle(e.target.value)}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">ข้อความ</label>
                                    <textarea required value={msgBody} onChange={e => setMsgBody(e.target.value)} rows={4}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
                                </div>
                                <div className="flex gap-3 mt-6">
                                    <button type="button" onClick={() => setSending(null)}
                                        className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted transition font-medium">ยกเลิก</button>
                                    <button type="submit"
                                        className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition flex items-center justify-center gap-2">
                                        <Bell size={14} /> แจ้งนักเรียน
                                    </button>
                                </div>
                            </form>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}
