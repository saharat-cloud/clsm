import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, ArrowLeft, Clock, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { useSemester } from '@/lib/SemesterContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';

export default function Assignments() {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [assignments, setAssignments] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [filterCls, setFilterCls] = useState('');
    const [filterSub, setFilterSub] = useState('');
    const [filterTeacher, setFilterTeacher] = useState('');
    const [allTeachers, setAllTeachers] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        if (params.get('classroom')) setFilterCls(params.get('classroom'));
        if (params.get('subject')) setFilterSub(params.get('subject'));
    }, []);

    async function load() {
        if (!user) return;
        setLoading(true);
        try {
            const isAdmin = user.role === 'admin';
            const [asgns, cls, subs, teacherList] = await Promise.all([
                isAdmin 
                    ? (filterTeacher ? base44.entities.Assignment.filter({ teacher_id: filterTeacher }) : base44.entities.Assignment.list())
                    : base44.entities.Assignment.filter({ teacher_id: user.id }),
                base44.entities.Classroom.list(),
                base44.entities.Subject.list(),
                isAdmin ? base44.entities.Teacher.list() : Promise.resolve([])
            ]);

            setSubjects(subs);
            setAllTeachers(teacherList || []);

            let filteredCls = cls;
            if (user && user.id && !isAdmin) {
                filteredCls = cls.filter(c => (c.teacher_id === user.id || c.teacher_ids?.includes(user.id)));
            }

            if (activeSemester) {
                // Defensive: string comparison and allow null for legacy rooms
                filteredCls = filteredCls.filter(c => 
                    !c.semester_academic_year || 
                    (String(c.semester_academic_year) === String(activeSemester.academic_year) && 
                     String(c.semester_number) === String(activeSemester.semester))
                );
            }
            
            setClassrooms(filteredCls.sort((a,b)=>a.name.localeCompare(b.name)));

            let filteredAsgns = asgns;
            if (activeSemester) {
                filteredAsgns = asgns.filter(a => 
                    !a.semester_academic_year ||
                    (String(a.semester_academic_year) === String(activeSemester.academic_year) && 
                     String(a.semester_number) === String(activeSemester.semester))
                );
            }
            setAssignments(filteredAsgns.sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()));

        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => { load(); }, [user, activeSemester, filterTeacher]);

    const clsMap = Object.fromEntries(classrooms.map(c => [c.id, c]));
    const subMap = Object.fromEntries(subjects.map(s => [s.id, s]));

    // Only show assignments whose classroom still exists (avoids showing orphaned assignments after semester reset)
    const validAssignments = assignments.filter(a => clsMap[a.classroom_id]);
    const filtered = validAssignments
        .filter(a => !filterCls || a.classroom_id === filterCls)
        .filter(a => !filterSub || a.subject_id === filterSub);
    const now = new Date();

    if (loading) return <PageLoading />;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-4xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <div>
                        <h1 className="text-2xl font-bold">งานที่มอบหมาย</h1>
                        <p className="text-muted-foreground text-sm">{filtered.length} งาน</p>
                    </div>
                    <div className="ml-auto flex gap-2">
                        {user?.role === 'admin' && (
                            <select value={filterTeacher} onChange={e => setFilterTeacher(e.target.value)}
                                className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none min-w-[140px]">
                                <option value="">คุณครูทุกคน</option>
                                {allTeachers.map(t => <option key={t.id} value={t.id}>{t.first_name} {t.last_name}</option>)}
                            </select>
                        )}
                        <select value={filterSub} onChange={e => setFilterSub(e.target.value)}
                            className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none min-w-[120px]">
                            <option value="">ทุกวิชา</option>
                            {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                        <select value={filterCls} onChange={e => setFilterCls(e.target.value)}
                            className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none min-w-[120px]">
                            <option value="">ทุกห้อง</option>
                            {classrooms.map(c => {
                                const subName = subMap[c.subject_id]?.name || ' - ';
                                return <option key={c.id} value={c.id}>{c.name} ({subName})</option>;
                            })}
                        </select>
                        <Link to="/teacher/assignments/new"
                            className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl text-sm font-medium hover:opacity-90 transition">
                            <Plus size={16} /> สั่งงานใหม่
                        </Link>
                    </div>
                </div>

                <div className="grid gap-3">
                    {filtered.map(a => {
                        const cls = clsMap[a.classroom_id];
                        const sub = subMap[a.subject_id];
                        const isPast = new Date(a.due_date) < now;
                        return (
                            <Link key={a.id} to={`/teacher/assignments/${a.id}`}
                                className="bg-card border border-border rounded-2xl p-5 flex items-center gap-4 hover:shadow-md hover:border-primary/30 transition-all">
                                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isPast ? 'bg-orange-50' : 'bg-blue-50'}`}>
                                    {isPast ? <CheckCircle size={20} className="text-orange-500" /> : <Clock size={20} className="text-blue-600" />}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="font-semibold truncate">{a.title}</p>
                                    <p className="text-sm text-muted-foreground">
                                        {cls?.name} {sub ? `• ${sub.name}` : ''}
                                    </p>
                                    <p className="text-xs text-muted-foreground mt-0.5">
                                        กำหนดส่ง: {new Date(a.due_date).toLocaleString('th-TH')}
                                        {' • '}
                                        {a.late_policy === 'no_submit' ? '❌ ไม่รับหลังกำหนด' : '⚠️ รับแต่นับว่าเลท'}
                                    </p>
                                </div>
                                <div className="text-right">
                                    <p className="text-lg font-bold text-primary">{a.max_score}</p>
                                    <p className="text-xs text-muted-foreground">คะแนน</p>
                                </div>
                            </Link>
                        );
                    })}
                    {filtered.length === 0 && (
                        <div className="text-center py-16 text-muted-foreground">ยังไม่มีงาน</div>
                    )}
                </div>
            </div>
        </div>
    );
}