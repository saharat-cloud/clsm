import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Plus, UserMinus, ClipboardList, BookOpen, Check, Users, ArrowRightLeft } from 'lucide-react';
import { playClick, playDelete } from '@/lib/sound';
import { useSemester } from '@/lib/SemesterContext';
import { alerts } from '@/utils/alerts';
import { useAuth } from '@/lib/AuthContext';

export default function ClassroomDetail() {
    const { user } = useAuth();
    const { id } = useParams();
    const { activeSemester } = useSemester();
    const [classroom, setClassroom] = useState(null);
    const [allStudents, setAllStudents] = useState([]);
    const [allClassrooms, setAllClassrooms] = useState([]);
    const [allSubjects, setAllSubjects] = useState([]);
    const [enrolled, setEnrolled] = useState([]);
    const [addSearch, setAddSearch] = useState('');
    const [showAddPanel, setShowAddPanel] = useState(false);
    const [showSubjectPanel, setShowSubjectPanel] = useState(false);
    const [assignments, setAssignments] = useState([]);
    const [selectedToAdd, setSelectedToAdd] = useState([]);

    async function load() {
        const filter = {
            ...(activeSemester ? { semester_academic_year: activeSemester.academic_year, semester_number: activeSemester.semester } : {}),
            teacher_id: user.id
        };
        const [cls, students, asgns, subs, allCls] = await Promise.all([
            base44.entities.Classroom.filter({ id, teacher_id: user.id }),
            base44.entities.Student.filter(filter),
            base44.entities.Assignment.filter({ classroom_id: id, teacher_id: user.id }),
            base44.entities.Subject.filter(filter),
            base44.entities.Classroom.filter(filter)
        ]);
        const c = cls[0];
        setClassroom(c);
        setAssignments(asgns);
        setAllStudents(students);
        setAllClassrooms(allCls);
        setAllSubjects(subs);
        const ids = c?.student_ids || [];
        setEnrolled(students.filter(s => ids.includes(s.id)));
    }

    useEffect(() => { load(); }, [id]);

    async function removeStudent(studentId) {
        playDelete();
        const newIds = (classroom.student_ids || []).filter(i => i !== studentId);
        await base44.entities.Classroom.update(id, { student_ids: newIds });
        load();
    }

    async function addSelectedStudents() {
        playClick(700);
        const newIds = [...new Set([...(classroom.student_ids || []), ...selectedToAdd])];
        await base44.entities.Classroom.update(id, { student_ids: newIds });
        
        // Sync classroom_ids on student records and remove from old classrooms if applicable
        await Promise.all(selectedToAdd.map(async sid => {
            const s = allStudents.find(x => x.id === sid);
            if (s) {
                // Determine if student was already in another classroom (in the current active semester)
                // Filter out their previous classroom in this semester, replace with this one.
                const currentSemClassroomIds = allClassrooms.map(c => c.id);
                // Keep classrooms from other semesters, replace the one in this semester.
                const newStudentClassrooms = (s.classroom_ids || []).filter(cid => !currentSemClassroomIds.includes(cid));
                newStudentClassrooms.push(id);
                
                await base44.entities.Student.update(sid, { classroom_ids: newStudentClassrooms });

                // Also need to remove student from their old classroom in Classroom table
                const oldClassroomInThisSem = allClassrooms.find(c => (c.student_ids || []).includes(sid));
                if (oldClassroomInThisSem && oldClassroomInThisSem.id !== id) {
                    await base44.entities.Classroom.update(oldClassroomInThisSem.id, {
                        student_ids: oldClassroomInThisSem.student_ids.filter(studId => studId !== sid)
                    });
                }
            }
        }));
        setSelectedToAdd([]);
        setShowAddPanel(false);
        load();
    }

    async function addAllUnassignedStudents() {
        const unassigned = notEnrolled.filter(s => {
            const currentSemClassroomIds = allClassrooms.map(c => c.id);
            const intersections = (s.classroom_ids || []).filter(cid => currentSemClassroomIds.includes(cid));
            return intersections.length === 0;
        });
        
        if (unassigned.length === 0) {
            alerts.info('ไม่มีนักเรียน', 'ไม่พบนักเรียนที่ยังไม่มีห้องเรียนในเทอมนี้');
            return;
        }

        if (!await alerts.confirm('เพิ่มนักเรียน', `ยืนยันเพิ่มนักเรียนที่ยังไม่มีห้องทั้งหมด ${unassigned.length} คน เข้าห้องนี้ใช่หรือไม่?`)) return;
        
        playClick(700);
        setSelectedToAdd(unassigned.map(s => s.id));
        // Using setTimeout to let state update, then manually calling the logic
        setTimeout(() => {
             const newIds = [...new Set([...(classroom.student_ids || []), ...unassigned.map(u => u.id)])];
             base44.entities.Classroom.update(id, { student_ids: newIds }).then(() => {
                 Promise.all(unassigned.map(async s => {
                    const currentSemClassroomIds = allClassrooms.map(c => c.id);
                    const newStudentClassrooms = (s.classroom_ids || []).filter(cid => !currentSemClassroomIds.includes(cid));
                    newStudentClassrooms.push(id);
                    await base44.entities.Student.update(s.id, { classroom_ids: newStudentClassrooms });
                 })).then(() => {
                     setSelectedToAdd([]);
                     setShowAddPanel(false);
                     load();
                     alerts.success('เพิ่มสำเร็จ', `เพิ่มนักเรียน ${unassigned.length} คนเรียบร้อย`);
                 });
             });
        }, 100);
    }

    async function toggleSubject(subId) {
        playClick();
        const current = classroom.subject_ids || [];
        const updated = current.includes(subId) ? current.filter(x => x !== subId) : [...current, subId];
        await base44.entities.Classroom.update(id, { subject_ids: updated, subject_id: updated[0] || '' });
        load();
    }

    const notEnrolled = allStudents.filter(s =>
        !(classroom?.student_ids || []).includes(s.id) &&
        ((s.student_id || '').includes(addSearch) || (s.first_name || '').includes(addSearch) || (s.last_name || '').includes(addSearch))
    );

    const classroomSubjects = allSubjects.filter(s => (classroom?.subject_ids || []).includes(s.id));

    if (!classroom) return <div className="min-h-screen flex items-center justify-center bg-background"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-5xl mx-auto px-4 py-8 pb-24">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher/classrooms" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <div>
                        <h1 className="text-2xl font-bold">{classroom.name}</h1>
                        <p className="text-muted-foreground text-sm">
                            {classroom.academic_year ? `ปีการศึกษา ${classroom.academic_year}` : ''}
                            {classroom.semester ? ` เทอม ${classroom.semester}` : ''}
                            {classroomSubjects.length > 0 ? ` • ${classroomSubjects.length} วิชา` : ''}
                        </p>
                    </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                    {/* Students panel */}
                    <div className="md:col-span-2 space-y-4">
                        {/* Subject assignment */}
                        <div className="bg-card border border-border rounded-2xl p-5">
                            <div className="flex items-center justify-between mb-3">
                                <h2 className="font-semibold flex items-center gap-2"><BookOpen size={16} /> วิชาในห้องนี้ ({classroomSubjects.length})</h2>
                                <button onClick={() => { playClick(); setShowSubjectPanel(!showSubjectPanel); }}
                                    className="text-sm text-primary hover:underline flex items-center gap-1">
                                    <Plus size={14} /> จัดการวิชา
                                </button>
                            </div>
                            {showSubjectPanel && (
                                <div className="mb-3 p-3 bg-muted/50 rounded-xl">
                                    <p className="text-xs text-muted-foreground mb-2">คลิกเพื่อเพิ่ม/ลบวิชา</p>
                                    <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                                        {allSubjects.map(s => {
                                            const active = (classroom.subject_ids || []).includes(s.id);
                                            return (
                                                <button key={s.id} onClick={() => toggleSubject(s.id)}
                                                    className={`flex items-center gap-2 p-2 rounded-xl border text-sm transition-all ${active ? 'border-primary bg-accent text-accent-foreground' : 'border-border hover:bg-muted/50'}`}>
                                                    <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 ${active ? 'bg-primary border-primary' : 'border-muted-foreground/50'}`}>
                                                        {active && <Check size={11} className="text-white" strokeWidth={3} />}
                                                    </div>
                                                    <div className="min-w-0 text-left">
                                                        <p className="font-medium text-xs truncate">{s.name}</p>
                                                        <p className="text-xs text-muted-foreground">{s.code}</p>
                                                    </div>
                                                </button>
                                            );
                                        })}
                                        {allSubjects.length === 0 && (
                                            <p className="col-span-2 text-sm text-muted-foreground text-center py-2">
                                                ยังไม่มีวิชา — <Link to="/teacher/subjects" className="text-primary underline">เพิ่มวิชา</Link>
                                            </p>
                                        )}
                                    </div>
                                </div>
                            )}
                            <div className="flex flex-wrap gap-2">
                                {classroomSubjects.map(s => (
                                    <span key={s.id} className="flex items-center gap-1.5 px-3 py-1 bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300 rounded-full text-sm">
                                        <BookOpen size={12} /> {s.code} {s.name}
                                    </span>
                                ))}
                                {classroomSubjects.length === 0 && <p className="text-sm text-muted-foreground">ยังไม่มีวิชา — คลิก "จัดการวิชา"</p>}
                            </div>
                        </div>

                        {/* Students list */}
                        <div className="bg-card border border-border rounded-2xl p-5">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="font-semibold flex items-center gap-2"><Users size={16} /> นักเรียน ({enrolled.length} คน)</h2>
                                <button onClick={() => { playClick(); setShowAddPanel(!showAddPanel); setSelectedToAdd([]); }}
                                    className="flex items-center gap-2 text-sm text-primary hover:underline">
                                    <Plus size={16} /> เพิ่มนักเรียน
                                </button>
                            </div>

                            {showAddPanel && (
                                <div className="mb-4 p-3 bg-muted/50 rounded-xl">
                                    <div className="flex gap-2 mb-2">
                                        <input value={addSearch} onChange={e => setAddSearch(e.target.value)}
                                            placeholder="ค้นหาชื่อหรือรหัส..."
                                            className="w-full border border-input rounded-lg px-3 py-1.5 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring flex-1" />
                                        <button onClick={addAllUnassignedStudents} title="เพิ่มคนที่ยังไม่มีห้องทั้งหมด"
                                            className="px-3 py-1.5 bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-lg text-xs font-semibold whitespace-nowrap transition flex items-center gap-1">
                                            <Users size={14} /> ดึงคนที่ไม่มีห้อง
                                        </button>
                                    </div>
                                    <div className="max-h-48 overflow-y-auto space-y-1 mb-2">
                                        {notEnrolled.slice(0, 30).map(s => {
                                            const sel = selectedToAdd.includes(s.id);
                                            // Check if student is in another classroom this term
                                            const currentSemClassroomIds = allClassrooms.map(c => c.id);
                                            const otherClassroomIds = (s.classroom_ids || []).filter(cid => currentSemClassroomIds.includes(cid));
                                            const inAnotherClass = otherClassroomIds.length > 0;
                                            const otherClassName = inAnotherClass ? allClassrooms.find(c => c.id === otherClassroomIds[0])?.name : null;

                                            return (
                                                <div key={s.id}
                                                    onClick={() => { playClick(); setSelectedToAdd(prev => sel ? prev.filter(x => x !== s.id) : [...prev, s.id]); }}
                                                    className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition ${sel ? 'bg-accent' : 'hover:bg-card'}`}>
                                                    <div className="flex items-center gap-2">
                                                        <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 ${sel ? 'bg-primary border-primary' : 'border-muted-foreground/50'}`}>
                                                            {sel && <Check size={11} className="text-white" strokeWidth={3} />}
                                                        </div>
                                                        <span className="text-sm">{s.student_id} - {s.first_name} {s.last_name}</span>
                                                    </div>
                                                    {inAnotherClass && (
                                                        <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full flex items-center gap-1 shrink-0">
                                                            <ArrowRightLeft size={10} /> ย้ายจาก {otherClassName}
                                                        </span>
                                                    )}
                                                </div>
                                            );
                                        })}
                                        {notEnrolled.length === 0 && <p className="text-sm text-muted-foreground text-center py-2">ไม่พบนักเรียน</p>}
                                    </div>
                                    {selectedToAdd.length > 0 && (
                                        <button onClick={addSelectedStudents}
                                            className="w-full bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition">
                                            เพิ่ม/ย้าย {selectedToAdd.length} คนที่เลือกมาที่ห้องนี้
                                        </button>
                                    )}
                                </div>
                            )}

                            <div className="space-y-2">
                                {enrolled.map(s => (
                                    <div key={s.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-xl">
                                        <div>
                                            <span className="font-mono text-sm text-muted-foreground mr-2">{s.student_id}</span>
                                            <span className="text-sm font-medium">{s.first_name} {s.last_name}</span>
                                            {s.nickname && <span className="text-xs text-muted-foreground ml-2">({s.nickname})</span>}
                                        </div>
                                        <button onClick={() => removeStudent(s.id)} className="p-1.5 text-muted-foreground hover:text-destructive rounded-lg hover:bg-destructive/10 transition">
                                            <UserMinus size={15} />
                                        </button>
                                    </div>
                                ))}
                                {enrolled.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">ยังไม่มีนักเรียน</p>}
                            </div>
                        </div>
                    </div>

                    {/* Assignments panel */}
                    <div className="bg-card border border-border rounded-2xl p-5 h-fit">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="font-semibold flex items-center gap-2"><ClipboardList size={16} /> งาน ({assignments.length})</h2>
                            <Link to={`/teacher/assignments?classroom=${id}`} className="text-xs text-primary hover:underline">ดูทั้งหมด</Link>
                        </div>
                        <div className="space-y-2">
                            {assignments.slice(0, 5).map(a => (
                                <Link key={a.id} to={`/teacher/assignments/${a.id}`}
                                    className="block p-3 bg-muted/30 rounded-xl hover:bg-muted/50 transition">
                                    <p className="text-sm font-medium truncate">{a.title}</p>
                                    <p className="text-xs text-muted-foreground">{new Date(a.due_date).toLocaleDateString('th-TH')}</p>
                                </Link>
                            ))}
                            {assignments.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">ยังไม่มีงาน</p>}
                        </div>
                        <Link to={`/teacher/assignments/new?classroom=${id}`}
                            className="mt-3 flex items-center justify-center gap-2 w-full border border-dashed border-border rounded-xl py-2 text-sm text-muted-foreground hover:border-primary hover:text-primary transition">
                            <Plus size={16} /> สั่งงานใหม่
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}