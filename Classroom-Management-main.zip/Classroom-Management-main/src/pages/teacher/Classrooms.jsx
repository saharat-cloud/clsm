import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Pencil, Trash2, Users, ArrowLeft, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';
import ClassroomModal from '@/components/teacher/ClassroomModal';
import { playClick, playDelete } from '@/lib/sound';
import { alerts } from '@/utils/alerts';
import { useSemester } from '@/lib/SemesterContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';
import { useAuth } from '@/lib/AuthContext';

export default function Classrooms({ adminMode = false }) {
    const { user } = useAuth();
    const { activeSemester, semesterLabel } = useSemester();
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [teachers, setTeachers] = useState([]);
    const [modal, setModal] = useState(null);
    const [loading, setLoading] = useState(true);

    async function load() {
        if (!user) return;
        setLoading(true);
        const filter = {
            ...(adminMode ? {} : { teacher_id: user.id }),
            ...(activeSemester ? { 
                semester_academic_year: activeSemester.academic_year, 
                semester_number: activeSemester.semester 
            } : {})
        };
        const [cls, subs, stds, tList] = await Promise.all([
            base44.entities.Classroom.filter(filter),
            base44.entities.Subject.filter(adminMode ? {} : { teacher_id: user.id }),
            base44.entities.Student.filter(filter),
            adminMode ? base44.entities.Teacher.list() : Promise.resolve([])
        ]);

        setTeachers(tList);

        // Calculate actual student counts per classroom to avoid mismatches
        const counts = {};
        stds.forEach(s => {
            if (s.classroom_ids && Array.isArray(s.classroom_ids)) {
                s.classroom_ids.forEach(cid => {
                    counts[cid] = (counts[cid] || 0) + 1;
                });
            }
        });

        setClassrooms(cls.map(c => ({
            ...c,
            _actualCount: counts[c.id] || 0
        })));
        setSubjects(subs);
        setLoading(false);
    }

    useEffect(() => { load(); }, [activeSemester]);

    async function handleDelete(id) {
        if (!await alerts.confirmDanger('ลบห้องเรียน', 'ยืนยันการลบห้องเรียนนี้ใช่หรือไม่?')) return;
        playDelete();
        await base44.entities.Classroom.delete(id);
        load();
    }

    async function handleGlobalNextSemester() {
        if (!await alerts.confirm('ขึ้นเทอมใหม่', 'ยืนยันการขึ้นเทอมใหม่?\n\nห้องเรียน นักเรียน และรายวิชาของเทอมปัจจุบันจะถูกซ่อนเป็นประวัติ (Archive)\nเพื่อเตรียมระบบสำหรับเทอมใหม่')) return;
        
        try {
            const activeClassrooms = classrooms.filter(c => !c.is_archived);
            
            const [allStudents, allSubjects] = await Promise.all([
                base44.entities.Student.filter({ teacher_id: user.id }),
                base44.entities.Subject.filter({ teacher_id: user.id })
            ]);
            
            const activeStudents = allStudents.filter(s => !s.is_archived);
            const activeSubjects = allSubjects.filter(s => !s.is_archived);

            if (activeClassrooms.length === 0 && activeStudents.length === 0 && activeSubjects.length === 0) {
                alerts.info('ไม่มีข้อมูล', 'ไม่มีข้อมูลในเทอมปัจจุบันให้จัดเก็บ');
                return;
            }
            
            const promises = [];
            activeClassrooms.forEach(c => promises.push(base44.entities.Classroom.update(c.id, { is_archived: true })));
            activeStudents.forEach(s => promises.push(base44.entities.Student.update(s.id, { is_archived: true })));
            activeSubjects.forEach(s => promises.push(base44.entities.Subject.update(s.id, { is_archived: true })));
            
            await Promise.all(promises);
            
            load();
            alerts.success('จัดเก็บเรียบร้อย', 'จัดเก็บข้อมูลเทอมปัจจุบันเรียบร้อยแล้ว');
        } catch (err) {
            console.error(err);
            alerts.error('เกิดข้อผิดพลาด', 'โปรดตรวจสอบความถูกต้องของระบบ');
        }
    }

    const subjectMap = Object.fromEntries(subjects.map(s => [s.id, s]));
    const displayClassrooms = classrooms;

    if (loading) return <PageLoading />;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-4xl mx-auto px-4 py-8 pb-24">
                <div className="flex items-center gap-3 mb-8">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <div>
                        <h1 className="text-2xl font-bold">{adminMode ? 'จัดการชั้นเรียน (ระบบส่วนกลาง)' : 'ห้องเรียน'}</h1>
                        <p className="text-muted-foreground text-sm">{semesterLabel(activeSemester) || 'ทุกเทอม'} • {displayClassrooms.length} ห้อง</p>
                    </div>
                    {user?.role === 'admin' && (
                        <div className="ml-auto flex items-center gap-2">
                            <button onClick={() => { playClick(); setModal('create'); }}
                                    className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl text-sm font-semibold hover:opacity-90 transition">
                                    <Plus size={16} /> เพิ่มห้องเรียน
                                </button>
                        </div>
                    )}
                </div>

                {displayClassrooms.length === 0 && (
                    <div className="text-center py-16 bg-card rounded-2xl border border-dashed border-border">
                        <Users size={40} className="mx-auto text-muted-foreground/40 mb-3" />
                        <p className="text-muted-foreground font-medium">ยังไม่มีห้องเรียน</p>
                        <p className="text-sm text-muted-foreground mt-1">เริ่มต้นโดยกดปุ่ม "เพิ่มห้องเรียน" หรือเลือกปีการศึกษาใน Sidebar</p>
                    </div>
                )}

                <div className="grid gap-3">
                    {displayClassrooms.map((c) => {
                        const classSubjects = (c.subject_ids || (c.subject_id ? [c.subject_id] : [])).map(sid => subjectMap[sid]).filter(Boolean);
                        return (
                            <div key={c.id} className="bg-card border border-border rounded-2xl p-5 flex items-center gap-4 hover:shadow-md hover:border-primary/30 transition-all">
                                <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl flex items-center justify-center flex-shrink-0">
                                    <Users size={22} className="text-emerald-600" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="font-semibold text-lg">{c.name}</p>
                                    <p className="text-sm text-muted-foreground">
                                        {c.academic_year ? `ปีการศึกษา ${c.academic_year}` : ''}
                                        {c.semester ? ` เทอม ${c.semester}` : ''}
                                        {' • '}{c._actualCount || 0} นักเรียน
                                    </p>
                                    {adminMode && (
                                        <p className="text-[11px] font-bold text-primary/70 mt-0.5 uppercase tracking-wide">
                                            ครูผู้สอน: {teachers.find(t => t.id === c.teacher_id)?.first_name || 'ไม่ระบุ'}
                                        </p>
                                    )}
                                    {classSubjects.length > 0 && (
                                        <div className="flex flex-wrap gap-1 mt-1.5">
                                            {classSubjects.map(s => (
                                                <span key={s.id} className="flex items-center gap-1 text-xs px-2 py-0.5 bg-violet-100 text-violet-700 dark:bg-violet-900/20 dark:text-violet-300 rounded-full">
                                                    <BookOpen size={10} /> {s.code}
                                                </span>
                                            ))}
                                        </div>
                                    )}
                                </div>
                                <Link to={`/teacher/classrooms/${c.id}`}
                                    className="text-sm bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground px-3 py-1.5 rounded-xl transition font-medium">ดูข้อมูล</Link>
                                {user?.role === 'admin' && (
                                    <>
                                        <button onClick={() => { playClick(); setModal(c); }} className="p-2 text-muted-foreground hover:text-primary rounded-lg hover:bg-muted transition"><Pencil size={16} /></button>
                                        <button onClick={() => handleDelete(c.id)} className="p-2 text-muted-foreground hover:text-destructive rounded-lg hover:bg-destructive/10 transition"><Trash2 size={16} /></button>
                                    </>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>

            {modal && (
                <ClassroomModal
                    classroom={modal === 'create' ? null : modal}
                    onClose={() => setModal(null)}
                    onSaved={() => { setModal(null); load(); }}
                />
            )}
        </div>
    );
}