import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, UserPlus, Trash2, Pencil, Shield, User, Key, Check, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { alerts } from '@/utils/alerts';
import { useToast } from '@/components/ui/use-toast';
import { PageLoading } from '@/components/ui/LoadingSpinner';

export default function ManageAccounts() {
    const { user } = useAuth();
    const navigate = useNavigate();
    const { toast } = useToast();
    const [teachers, setTeachers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [modal, setModal] = useState(null); // 'create' or teacher object

    useEffect(() => {
        if (user && user.role !== 'admin') {
            navigate('/teacher');
            return;
        }
        load();
    }, [user]);

    async function load() {
        setLoading(true);
        try {
            const data = await base44.entities.Teacher.list();
            setTeachers(data.sort((a, b) => a.username.localeCompare(b.username)));
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    async function handleDelete(teacher) {
        if (teacher.id === user.id) {
            alerts.error('ไม่สามารถลบบัญชีตัวเองได้');
            return;
        }
        if (!await alerts.confirmDanger('ลบบัญชีครู', `ยืนยันการลบบัญชีของ ${teacher.first_name} (${teacher.username}) หรือไม่? ข้อมูลชั้นเรียนทั้งหมดของครูคนนี้จะยังคงอยู่ในฐานข้อมูลแต่อาจเข้าถึงได้ยากขึ้น`)) return;
        
        try {
            await base44.entities.Teacher.delete(teacher.id);
            toast({ title: 'ลบบัญชีสำเร็จ' });
            load();
        } catch (err) {
            alerts.error('ลบไม่สำเร็จ', err.message);
        }
    }

    if (loading) return <PageLoading />;

    return (
        <div className="min-h-screen bg-background pb-12">
            <div className="max-w-4xl mx-auto px-4 py-8">
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-3">
                        <Link to="/teacher" className="p-2 rounded-full hover:bg-muted transition text-muted-foreground hover:text-foreground">
                            <ArrowLeft size={20} />
                        </Link>
                        <div>
                            <h1 className="text-2xl font-bold tracking-tight">จัดการบัญชีครู</h1>
                            <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <Shield size={14} className="text-primary" /> สิทธิ์ผู้ดูแลระบบสูงสุด
                            </p>
                        </div>
                    </div>
                    <button onClick={() => setModal('create')}
                        className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl text-sm font-bold shadow-sm hover:opacity-90 transition">
                        <UserPlus size={18} /> เพิ่มครูใหม่
                    </button>
                </div>

                <div className="grid gap-4">
                    {teachers.map(t => (
                        <div key={t.id} className="bg-card border border-border rounded-2xl p-5 flex items-center gap-4 hover:shadow-md transition-all">
                            <div className="w-12 h-12 rounded-2xl bg-muted flex items-center justify-center overflow-hidden">
                                {t.avatar_url ? <img src={t.avatar_url} className="w-full h-full object-cover" /> : <User size={24} className="text-muted-foreground/40" />}
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-0.5">
                                    <h3 className="font-bold truncate">{t.first_name} {t.last_name || ''}</h3>
                                    {t.role === 'admin' && <span className="bg-primary/10 text-primary text-[10px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-widest">Admin</span>}
                                </div>
                                <p className="text-xs text-muted-foreground font-mono">@{t.username} • ID: {t.id}</p>
                                {(() => {
                                    if (!t.last_active_at) return null;
                                    const diff = Date.now() - new Date(t.last_active_at).getTime();
                                    const isOnline = diff < 15 * 60 * 1000;
                                    return (
                                        <div className="flex items-center gap-1.5 mt-1">
                                            <div className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.5)] animate-pulse' : 'bg-muted-foreground/30'}`} />
                                            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                                                {isOnline ? 'Online' : `Last seen: ${new Date(t.last_active_at).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}`}
                                            </span>
                                        </div>
                                    );
                                })()}
                            </div>
                            <div className="flex items-center gap-1">
                                <button onClick={() => setModal(t)} className="p-2 text-muted-foreground hover:text-primary transition">
                                    <Pencil size={18} />
                                </button>
                                <button onClick={() => handleDelete(t)} disabled={t.id === user.id}
                                    className="p-2 text-muted-foreground hover:text-destructive transition disabled:opacity-30">
                                    <Trash2 size={18} />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {modal && (
                <AccountModal 
                    teacher={modal === 'create' ? null : modal} 
                    onClose={() => setModal(null)} 
                    onSaved={() => { setModal(null); load(); }}
                />
            )}
        </div>
    );
}

function AccountModal({ teacher, onClose, onSaved }) {
    const { toast } = useToast();
    const [saving, setSaving] = useState(false);
    const [form, setForm] = useState({
        username: teacher?.username || '',
        password: teacher?.password || '',
        first_name: teacher?.first_name || '',
        last_name: teacher?.last_name || '',
        role: teacher?.role || 'teacher'
    });

    async function handleSubmit(e) {
        e.preventDefault();
        setSaving(true);
        try {
            if (teacher) {
                await base44.entities.Teacher.update(teacher.id, form);
                toast({ title: 'อัปเดตข้อมูลสำเร็จ' });
            } else {
                // For new teacher, we need a unique ID
                const id = `teacher_${Date.now()}`;
                await base44.entities.Teacher.create({ ...form, id });
                toast({ title: 'เพิ่มครูคนใหม่สำเร็จ' });
            }
            onSaved();
        } catch (err) {
            alerts.error('ดำเนินการไม่สำเร็จ', err.message);
        } finally {
            setSaving(false);
        }
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 overflow-y-auto">
            <div className="bg-card rounded-3xl shadow-2xl w-full max-w-md p-8 border border-white/20">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold">{teacher ? 'แก้ไขข้อมูลครู' : 'เพิ่มครูคนใหม่'}</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-muted transition text-muted-foreground">
                        <X size={20} />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1.5 ml-1">ชื่อจริง</label>
                            <input required value={form.first_name} onChange={e => setForm({...form, first_name: e.target.value})}
                                className="w-full bg-muted/50 border border-border rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1.5 ml-1">นามสกุล</label>
                            <input value={form.last_name} onChange={e => setForm({...form, last_name: e.target.value})}
                                className="w-full bg-muted/50 border border-border rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition" />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1.5 ml-1">Username (ใช้สำหรับ Login)</label>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"><User size={16} /></span>
                            <input required value={form.username} onChange={e => setForm({...form, username: e.target.value.toLowerCase().replace(/\s/g, '')})}
                                disabled={!!teacher}
                                className="w-full bg-muted/50 border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition disabled:opacity-50" />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1.5 ml-1">Password</label>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"><Key size={16} /></span>
                            <input required value={form.password} onChange={e => setForm({...form, password: e.target.value})}
                                className="w-full bg-muted/50 border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition" />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1.5 ml-1">บทบาท (Role)</label>
                        <div className="grid grid-cols-2 gap-2">
                            <button type="button" onClick={() => setForm({...form, role: 'teacher'})}
                                className={`py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest border-2 transition-all ${form.role === 'teacher' ? 'bg-primary/5 border-primary text-primary shadow-inner' : 'bg-background border-border text-muted-foreground hover:bg-muted'}`}>
                                Teacher
                                {form.role === 'teacher' && <Check size={12} className="inline-block ml-1" />}
                            </button>
                            <button type="button" onClick={() => setForm({...form, role: 'admin'})}
                                className={`py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest border-2 transition-all ${form.role === 'admin' ? 'bg-primary/5 border-primary text-primary shadow-inner' : 'bg-background border-border text-muted-foreground hover:bg-muted'}`}>
                                Admin
                                {form.role === 'admin' && <Check size={12} className="inline-block ml-1" />}
                            </button>
                        </div>
                    </div>

                    <div className="pt-4 flex gap-3">
                        <button type="button" onClick={onClose} className="flex-1 bg-muted/50 border border-border rounded-xl py-3 text-sm font-bold hover:bg-muted transition">ยกเลิก</button>
                        <button type="submit" disabled={saving} className="flex-1 bg-primary text-primary-foreground rounded-xl py-3 text-sm font-bold shadow-lg hover:shadow-primary/20 hover:opacity-90 transition disabled:opacity-50">
                            {saving ? 'กำลังบันทึก...' : teacher ? 'อัปเดตข้อมูล' : 'สร้างบัญชีครู'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
