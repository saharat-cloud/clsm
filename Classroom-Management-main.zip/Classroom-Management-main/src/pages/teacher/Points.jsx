import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Plus, Trophy, Trash2, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '@/api/supabaseClient';
import { alerts } from '@/utils/alerts';
import { useSemester } from '@/lib/SemesterContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';
import StudentAvatar from '@/components/ui/StudentAvatar';
import { GRADIENT_PRESETS, ANIMATION_PRESETS, getAnimationLabel } from '@/utils/customizationPresets';
import { useAuth } from '@/lib/AuthContext';

export default function Points() {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [loading, setLoading] = useState(true);
    const [students, setStudents] = useState([]);
    const [transactions, setTransactions] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [rewards, setRewards] = useState([]);
    const [claims, setClaims] = useState([]);
    const [filterCls, setFilterCls] = useState('');
    const [modalStudent, setModalStudent] = useState(null);
    const [manageItemsStudent, setManageItemsStudent] = useState(null);
    const [form, setForm] = useState({ points: '', reason: '', classroom_id: '' });
    
    // Reward states
    const [activeTab, setActiveTab] = useState('points');
    const [rewardForm, setRewardForm] = useState(null);
    const [rewardFile, setRewardFile] = useState(null);
    const [uploading, setUploading] = useState(false);
    const gradientPresets = GRADIENT_PRESETS;

    async function load() {
        if (!user) return;
        setLoading(true);
        const filter = {
            ...(activeSemester ? { 
                semester_academic_year: activeSemester.academic_year, 
                semester_number: activeSemester.semester 
            } : {}),
            teacher_id: user.id
        };

        const adminFilter = {
            ...(activeSemester ? { 
                semester_academic_year: activeSemester.academic_year, 
                semester_number: activeSemester.semester 
            } : {}),
            teacher_id: 'kanit_admin'
        };
        
        const [stds, cls, txns, rwds, clms] = await Promise.all([
            base44.entities.Student.filter(adminFilter),
            base44.entities.Classroom.filter(adminFilter),
            base44.entities.PointTransaction.filter(filter),
            base44.entities.Reward.filter(filter),
            base44.entities.RewardClaim.filter(filter),
        ]);
        
        // Manual filter for claims if no teacher_id in it yet
        const clsIds = cls.map(c => c.id);
        const stdIds = stds.filter(s => clsIds.some(cid => (cls.find(cl => cl.id === cid)?.student_ids || []).includes(s.id))).map(s => s.student_id);

        setStudents(stds); 
        setClassrooms(cls);
        
        setTransactions(txns.filter(t => stdIds.includes(t.student_id)));
        setClaims(clms.filter(c => stdIds.includes(c.student_id)));
        setRewards(rwds.filter(r => !r.classroom_id || clsIds.includes(r.classroom_id)));
        
        setLoading(false);
    }

    useEffect(() => { 
        load(); 
        const channel = supabase
            .channel(`teacher-points-claims-${user.id}`)
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'reward_claims', filter: `teacher_id=eq.${user.id}` }, (payload) => {
                const newClaim = payload.new;
                setClaims(prev => {
                    if (prev.find(c => c.id === newClaim.id)) return prev;
                    return [newClaim, ...prev];
                });
            })
            .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'rewards', filter: `teacher_id=eq.${user.id}` }, (payload) => {
                setRewards(prev => prev.map(r => r.id === payload.new.id ? payload.new : r));
            })
            .subscribe();
        return () => { supabase.removeChannel(channel); };
    }, [activeSemester]);

    const cls = classrooms.find(c => c.id === filterCls);
    const displayStudents = filterCls
        ? students.filter(s => (cls?.student_ids || []).includes(s.id))
        : students;

    function getPointRank(studentId, studentsList) {
        const sorted = [...studentsList].sort((a, b) => (b.total_points || 0) - (a.total_points || 0));
        return sorted.findIndex(s => s.student_id === studentId) + 1;
    }

    async function handleAdjust(e) {
        e.preventDefault();
        const pts = Number(form.points);
        const classroomStudents = filterCls
            ? students.filter(s => (cls?.student_ids || []).includes(s.id))
            : students;
        const oldRank = getPointRank(modalStudent.student_id, classroomStudents);

        await base44.entities.PointTransaction.create({
            student_id: modalStudent.student_id,
            points: pts,
            reason: form.reason,
            classroom_id: form.classroom_id || filterCls,
            teacher_id: user.id
        });
        const newTotal = (modalStudent.total_points || 0) + pts;
        const capped = Math.max(0, newTotal);
        await base44.entities.Student.update(modalStudent.id, { total_points: capped });

        const isPositive = pts > 0;
        await base44.entities.Notification.create({
            teacher_id: user.id,
            student_id: modalStudent.student_id,
            title: isPositive ? `🎉 ได้รับแต้ม +${pts}` : `⚠️ หักแต้ม ${pts}`,
            message: form.reason ? `เหตุผล: ${form.reason} • แต้มสะสมปัจจุบัน: ${capped}` : `แต้มสะสมปัจจุบัน: ${capped}`,
            type: isPositive ? 'points_added' : 'points_deducted',
            is_read: false,
        });

        const updatedStudents = classroomStudents.map(s =>
            s.student_id === modalStudent.student_id ? { ...s, total_points: capped } : s
        );
        const newRank = getPointRank(modalStudent.student_id, updatedStudents);
        if ((oldRank <= 5 || newRank <= 5) && oldRank !== newRank) {
            const direction = newRank < oldRank ? 'ขึ้น' : 'ตก';
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: modalStudent.student_id,
                title: `🏆 แรงค์แต้ม${direction}!`,
                message: `อันดับแต้มสะสมเปลี่ยนจาก #${oldRank} → #${newRank}`,
                type: 'rank_changed_points',
                is_read: false,
            });
        }
        setModalStudent(null);
        load();
    }

    const [deleteReward, setDeleteReward] = useState(null);

    async function handleSaveReward(e) {
        e.preventDefault();
        setUploading(true);
        try {
            let finalImageUrl = rewardForm.image_url;
            if (rewardFile) {
                const ext = rewardFile.name.split('.').pop() || '';
                const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${ext}`;
                const { error: uploadError } = await supabase.storage
                    .from('rewards')
                    .upload(fileName, rewardFile);
                if (uploadError) throw uploadError;
                const { data } = supabase.storage.from('rewards').getPublicUrl(fileName);
                finalImageUrl = data.publicUrl;
            }

            const oldReward = rewardForm.id ? rewards.find(r => r.id === rewardForm.id) : null;

            const data = {
                name: rewardForm.name,
                points_required: Number(rewardForm.points_required),
                stock: Number(rewardForm.stock),
                image_url: finalImageUrl,
                reward_type: rewardForm.reward_type || 'item',
                score_amount: Number(rewardForm.score_amount || 0),
                classroom_id: filterCls || null,
                exp_required: Number(rewardForm.exp_required || 0),
                customization_type: rewardForm.customization_type || '',
                customization_value: (rewardForm.reward_type === 'customization' && rewardForm.customization_type === 'frame' && (rewardFile || finalImageUrl)) ? finalImageUrl : (rewardForm.customization_value || ''),
                rarity: rewardForm.rarity || 'common',
                sale_end_date: rewardForm.sale_end_date || null,
                status: rewardForm.status || 'active',
                teacher_id: user.id,
                semester_academic_year: activeSemester?.academic_year || null,
                semester_number: activeSemester?.semester || null
            };

            // Auto-calculate name if empty
            if (!data.name) {
                if (data.reward_type === 'points') data.name = `คะแนนพิเศษ +${data.score_amount}`;
                else if (data.reward_type === 'antivirus') data.name = `💊 ยาต้านไวรัส`;
                else if (data.reward_type === 'customization' && rewardForm.customization_type === 'title') data.name = `ฉายา: ${data.customization_value}`;
                else if (data.reward_type === 'customization' && rewardForm.customization_type === 'name_bg') {
                    const preset = gradientPresets.find(p => p.value === data.customization_value);
                    data.name = `สีโปรไฟล์: ${preset ? preset.name : 'สีพิเศษ'}`;
                }
                else if (data.reward_type === 'customization' && rewardForm.customization_type === 'frame' && data.customization_value.startsWith('animated:')) {
                    const preset = data.customization_value.split(':')[1];
                    const label = getAnimationLabel(preset);
                    data.name = `กรอบแอนิเมชั่น: ${label}`;
                }
            }

            if (rewardForm.id) {
                await base44.entities.Reward.update(rewardForm.id, data);
                
                // Propagate changes to students who own this customization
                if (data.reward_type === 'customization') {
                    const allStudents = await base44.entities.Student.filter({ teacher_id: user.id });
                    const studentsToUpdate = allStudents.filter(s => 
                        (s.owned_customizations || []).some(oc => oc.id === rewardForm.id)
                    );

                    for (const s of studentsToUpdate) {
                        const newOwned = s.owned_customizations.map(oc => 
                            oc.id === rewardForm.id ? { ...oc, value: data.customization_value, name: data.name } : oc
                        );
                        const updateData = { owned_customizations: newOwned };

                        // Update active fields if they match the OLD value
                        if (oldReward) {
                            if (s.profile_frame === oldReward.customization_value) updateData.profile_frame = data.customization_value;
                            if (s.title === oldReward.customization_value) updateData.title = data.customization_value;
                            if (s.name_bg_color === oldReward.customization_value) updateData.name_bg_color = data.customization_value;
                        }

                        await base44.entities.Student.update(s.id, updateData);
                    }
                }
            } else {
                await base44.entities.Reward.create(data);
            }
            setRewardForm(null);
            setRewardFile(null);
            load();
        } catch (err) {
            console.error(err);
            alerts.error('เกิดข้อผิดพลาด', err.message);
        } finally {
            setUploading(false);
        }
    }

    async function handleDeleteReward(id) {
        setDeleteReward(rewards.find(r => r.id === id));
    }

    async function confirmDeleteReward(mode) {
        if (!deleteReward) return;
        
        if (mode === 'limited') {
            await base44.entities.Reward.update(deleteReward.id, { status: 'limited' });
            alerts.success('ตั้งเป็นสินค้าลิมิเต็ดแล้ว', 'สินค้านี้จะไม่ปรากฏในร้านค้า แต่เด็กที่แลกไปแล้วจะยังใช้งานได้ปกติ');
        } else if (mode === 'permanent') {
            if (!await alerts.confirmDanger('ลบถาวร', 'ยืนยันการลบถาวร? สินค้านี้จะหายไปจากทั้งร้านค้าและตัวเด็กทุกคนที่เคยแลกไป ยอดแต้มจะไม่ได้รับการคืนอัตโนมัติ')) return;
            
            // 1. Delete from all students
            const allStudents = await base44.entities.Student.filter({ teacher_id: user.id });
            for (const s of allStudents) {
                const owned = s.owned_customizations || [];
                const filtered = owned.filter(oc => oc.id !== deleteReward.id);
                if (filtered.length !== owned.length) {
                    const updateData = { owned_customizations: filtered };
                    if (s.profile_frame === deleteReward.customization_value) updateData.profile_frame = '';
                    if (s.title === deleteReward.customization_value) updateData.title = '';
                    if (s.name_bg_color === deleteReward.customization_value) updateData.name_bg_color = '';
                    await base44.entities.Student.update(s.id, updateData);
                }
            }
            // 2. Delete Reward
            await base44.entities.Reward.delete(deleteReward.id);
            alerts.success('ลบถาวรสำเร็จ');
        }
        setDeleteReward(null);
        load();
    }

    async function handleClaimAction(claim, action) {
        const title = action === 'approve' ? 'ยืนยันการอนุมัติ' : 'ปฏิเสธคำขอ';
        const text = action === 'approve' ? 'ยืนยันการอนุมัติการแลกรางวัลนี้?' : 'ปฏิเสธการแลกรางวัลและคืนแต้มให้นักเรียน?';
        if (!await alerts.confirm(title, text)) return;
        
        await base44.entities.RewardClaim.update(claim.id, { status: action === 'approve' ? 'approved' : 'rejected' });
        
        if (action === 'approve') {
            const reward = rewards.find(r => r.id === claim.reward_id);
            if (reward && reward.reward_type === 'antivirus') {
                try {
                    const stdItems = await base44.entities.StudentItem.filter({ student_id: claim.student_id, item_type: 'antivirus', teacher_id: user.id });
                    if (stdItems.length > 0) {
                        await base44.entities.StudentItem.update(stdItems[0].id, { quantity: (stdItems[0].quantity || 0) + 1 });
                    } else {
                        await base44.entities.StudentItem.create({ teacher_id: user.id, student_id: claim.student_id, item_type: 'antivirus', quantity: 1 });
                    }
                } catch(e) { console.error('Failed to grant antivirus item:', e); }
            } else if (reward && reward.reward_type === 'points' && reward.score_amount > 0) {
                let targetClassroomId = reward.classroom_id;
                let targetSubjectId = classrooms.find(c => c.id === reward.classroom_id)?.subject_id;
                if (!targetClassroomId) {
                    const studentRecord = students.find(s => s.student_id === claim.student_id);
                    const stClasses = classrooms.filter(c => studentRecord && (c.student_ids || []).includes(studentRecord.id));
                    if (stClasses.length > 0) {
                        targetClassroomId = stClasses[0].id;
                        targetSubjectId = stClasses[0].subject_id;
                    } else {
                        throw new Error('ไม่สามารถให้คะแนนได้: นักเรียนไม่ได้อยู่ในห้องเรียนใดเลย');
                    }
                }
                await base44.entities.ScoreRecord.create({
                    teacher_id: user.id,
                    student_id: claim.student_id,
                    classroom_id: targetClassroomId,
                    subject_id: targetSubjectId || null,
                    score_type: 'คะแนนพิเศษ',
                    score: Number(reward.score_amount) || 1,
                    max_score: Number(reward.score_amount) || 1,
                    note: `แลกรางวัล: ${reward.name}`
                });
            }
            const rewardForNotif = rewards.find(r => r.id === claim.reward_id);
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: claim.student_id,
                title: '🎁 อนุมัติการแลกรางวัลแล้ว!',
                message: `รางวัล "${rewardForNotif?.name || 'รางวัล'}" ได้รับการยืนยันแล้ว`,
                type: 'reward_approved',
                is_read: false,
            });
        }
        
        if (action === 'rejected') {
            const std = students.find(s => s.student_id === claim.student_id);
            const reward = rewards.find(r => r.id === claim.reward_id);
            if (std && reward) {
                await base44.entities.Notification.create({
                    teacher_id: user.id,
                    student_id: claim.student_id,
                    title: '❌ ปฏิเสธการแลกรางวัล',
                    message: `คำขอแลกรางวัล "${reward.name}" ถูกปฏิเสธ ระบบได้คืนแต้มให้คุณแล้ว`,
                    type: 'reward_rejected',
                    is_read: false,
                });
                const newTotal = (std.total_points || 0) + reward.points_required;
                await base44.entities.Student.update(std.id, { total_points: newTotal });
                await base44.entities.PointTransaction.create({
                    teacher_id: user.id, student_id: std.student_id, points: reward.points_required, reason: `คืนแต้ม(ปฏิเสธ): ${reward.name}`
                });
                await base44.entities.Reward.update(reward.id, { stock: reward.stock + 1 });
            }
        }
        setClaims(prev => prev.map(c => c.id === claim.id ? { ...c, status: action === 'approve' ? 'approved' : 'rejected' } : c));
        load();
    }

    async function handleResetClassPoints() {
        if (!filterCls) return;
        if (!await alerts.confirmDanger('รีเซ็ตแต้มเป็น 0', `ยืนยันการตั้งค่าแต้มสะสมของนักเรียนห้อง ${cls?.name} ทุกคนให้เป็น 0 ใช่หรือไม่?`)) return;
        setLoading(true);
        const stdsInClass = students.filter(s => (cls?.student_ids || []).includes(s.id));
        await Promise.all(stdsInClass.map(s => base44.entities.Student.update(s.id, { total_points: 0 })));
        alerts.success('รีเซ็ตสำเร็จ', `แต้มสะสมของห้อง ${cls?.name} ถูกเซ็ตเป็น 0 แล้ว`);
        load();
    }

    async function handleClearClassHistory() {
        if (!filterCls) return;
        if (!await alerts.confirmDanger('ล้างประวัติแต้ม', `ยืนยันการลบประวัติการให้แต้ม/หักแต้มทั้งหมดของห้อง ${cls?.name} ใช่หรือไม่?\n(แต้มปัจจุบันของเด็กจะไม่เปลี่ยนแปลง)`)) return;
        setLoading(true);
        const enrolledIds = students.filter(s => (cls?.student_ids || []).includes(s.id)).map(s => s.student_id);
        const txnsToDelete = transactions.filter(t => enrolledIds.includes(t.student_id));
        await Promise.all(txnsToDelete.map(t => base44.entities.PointTransaction.delete(t.id)));
        alerts.success('ล้างประวัติสำเร็จ', `ประวัติแต้มของห้อง ${cls?.name} ถูกลบแล้ว`);
        load();
    }

    const pendingClaimsCount = claims.filter(c => c.status === 'pending').length;
    if (loading) return <PageLoading />;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-4xl mx-auto px-4 py-8">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                    <div className="flex items-center gap-3">
                        <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                        <h1 className="text-2xl font-bold">แต้มสะสม & รางวัล</h1>
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-3">
                        <div className="flex bg-muted/50 p-1 rounded-xl">
                            <button onClick={() => setActiveTab('points')} className={`px-4 py-1.5 rounded-lg text-sm font-medium transition ${activeTab === 'points' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>แต้มผู้เรียน</button>
                            <button onClick={() => setActiveTab('rewards')} className={`px-4 py-1.5 rounded-lg text-sm font-medium transition ${activeTab === 'rewards' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>จัดการของรางวัล</button>
                            <button onClick={() => setActiveTab('claims')} className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition ${activeTab === 'claims' ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                                คำขอแลก {pendingClaimsCount > 0 && <span className="text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded-full">{pendingClaimsCount}</span>}
                            </button>
                        </div>
                        <select value={filterCls} onChange={e => setFilterCls(e.target.value)}
                            className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none">
                            <option value="">ทุกห้องเรียน (ส่วนกลาง)</option>
                            {classrooms.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                </div>

                {activeTab === 'points' && (
                    <>
                    {filterCls && (
                        <div className="flex justify-end gap-2 mb-4">
                            <button onClick={handleClearClassHistory}
                                className="flex items-center gap-2 border border-destructive/30 text-destructive px-3 py-1.5 rounded-xl text-sm hover:bg-destructive/10 transition font-medium">
                                <Trash2 size={16} /> ล้างประวัติแต้มห้องนี้
                            </button>
                            <button onClick={handleResetClassPoints}
                                className="flex items-center gap-2 bg-destructive/10 text-destructive px-3 py-1.5 rounded-xl text-sm hover:bg-destructive/20 transition font-medium">
                                <Trash2 size={16} /> รีเซ็ตแต้มเป็น 0
                            </button>
                        </div>
                    )}
                    <div className="grid gap-2">
                        {displayStudents.map((s, idx) => (
                            <div key={s.id} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${idx === 0 ? 'bg-amber-100 text-amber-600' : 'bg-muted text-muted-foreground'}`}>
                                    {idx + 1}
                                </div>
                                <div className="flex-1">
                                    <p className="font-medium">{s.first_name} {s.last_name}</p>
                                    <p className="text-xs font-mono text-muted-foreground">{s.student_id}</p>
                                </div>
                                <div className="text-right mr-3">
                                    <p className="text-xl font-bold text-amber-600">{s.total_points || 0}</p>
                                    <p className="text-xs text-muted-foreground">แต้ม</p>
                                </div>
                                <div className="flex items-center gap-1">
                                    <button onClick={() => { setModalStudent(s); setForm({ points: '', reason: '', classroom_id: '' }); }}
                                        className="flex items-center gap-1 bg-primary text-primary-foreground px-3 py-1.5 rounded-xl text-sm hover:opacity-90 transition">
                                        <Plus size={14} /> ปรับแต้ม
                                    </button>
                                    {user?.role === 'admin' && (
                                        <button onClick={() => setManageItemsStudent(s)}
                                            className="p-1.5 text-muted-foreground hover:text-primary rounded-xl hover:bg-muted transition" title="จัดการไอเทม/ของตกแต่ง">
                                            <User size={16} />
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                    </>
                )}

                {activeTab === 'rewards' && (
                    <div>
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-lg font-bold">ของรางวัล {filterCls ? `(เฉพาะห้อง ${cls?.name})` : '(ส่วนกลาง)'}</h2>
                            <div className="flex gap-2">
                                <button onClick={() => { setRewardForm({ name: '', points_required: 0, exp_required: 100, stock: 999, image_url: '', reward_type: 'item', customization_type: 'title', customization_value: '', score_amount: 1, rarity: 'common', status: 'active', sale_end_date: null }); setRewardFile(null); }}
                                    className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl text-sm font-medium hover:opacity-90">
                                    <Plus size={16} /> เพิ่มรางวัล
                                </button>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                            {rewards.filter(r => (filterCls ? r.classroom_id === filterCls : !r.classroom_id)).map(r => (
                                <div key={r.id} className={`bg-card border rounded-2xl overflow-hidden group relative ${r.status === 'limited' ? 'border-amber-200 opacity-75' : 'border-border'}`}>
                                    {r.status === 'limited' && <div className="absolute top-2 left-2 z-20 bg-amber-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full uppercase">Limited</div>}
                                    <div className="aspect-square bg-muted flex items-center justify-center relative">
                                        {r.image_url ? <img src={r.image_url} alt={r.name} className="w-full h-full object-cover" /> : <Trophy size={40} className="text-muted-foreground/30" />}
                                        <div className="absolute top-2 right-2 flex flex-col items-end gap-1">
                                            {r.points_required > 0 && <div className="bg-background/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold text-amber-600 shadow-sm border border-amber-100">{r.points_required} แต้ม</div>}
                                            {r.exp_required > 0 && <div className="bg-background/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold text-blue-600 shadow-sm border border-blue-100">{r.exp_required} EXP</div>}
                                        </div>
                                    </div>
                                    <div className="p-3">
                                        <div className="flex justify-between items-start mb-1">
                                            <p className="font-bold truncate text-sm flex-1" title={r.name}>{r.name}</p>
                                            <span className={`flex-shrink-0 text-[8px] font-black uppercase px-1.5 py-0.5 rounded border ml-1 ${
                                                r.rarity === 'rare' ? 'bg-blue-50 text-blue-600 border-blue-200' :
                                                r.rarity === 'epic' ? 'bg-purple-50 text-purple-600 border-purple-200' :
                                                r.rarity === 'legendary' ? 'bg-amber-100 text-amber-700 border-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.2)]' :
                                                'bg-gray-50 text-gray-500 border-gray-200'
                                            }`}>
                                                {r.rarity || 'common'}
                                            </span>
                                        </div>
                                        <p className="text-xs text-muted-foreground mb-3">คงเหลือ: {r.stock} ชิ้น</p>
                                        <div className="flex gap-2">
                                            <button onClick={() => setRewardForm(r)} className="flex-1 border border-border py-1.5 rounded-lg text-xs hover:bg-muted">แก้ไข</button>
                                            <button onClick={() => handleDeleteReward(r.id)} className="flex-1 border border-destructive/30 text-destructive py-1.5 rounded-lg text-xs hover:bg-destructive/10">ลบ</button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {activeTab === 'claims' && (
                    <div>
                        <h2 className="text-lg font-bold mb-4">คำขอแลกรางวัล</h2>
                        <div className="bg-card border border-border rounded-2xl divide-y divide-border">
                            {claims.map(c => {
                                const std = students.find(s => s.student_id === c.student_id);
                                const r = rewards.find(rw => rw.id === c.reward_id);
                                return (
                                    <div key={c.id} className="flex items-center gap-4 px-4 py-3">
                                        <div className="w-10 h-10 rounded-xl bg-muted overflow-hidden flex-shrink-0">
                                            {r?.image_url ? <img src={r.image_url} alt="" className="w-full h-full object-cover"/> : <Trophy size={20} className="m-auto mt-2 text-muted-foreground/40"/>}
                                        </div>
                                        <div className="flex-1">
                                            <p className="font-bold text-sm">{r?.name || 'ลบไปแล้ว'}</p>
                                            <p className="text-xs text-muted-foreground">{std ? `${std.first_name} ${std.last_name} (${std.student_id})` : c.student_id}</p>
                                        </div>
                                        {c.status === 'pending' ? (
                                            <div className="flex gap-2">
                                                <button onClick={() => handleClaimAction(c, 'rejected')} className="text-xs border border-border px-3 py-1.5 rounded-xl text-destructive hover:bg-destructive/10">ปฏิเสธ</button>
                                                <button onClick={() => handleClaimAction(c, 'approve')} className="text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-xl hover:opacity-90">อนุมัติ</button>
                                            </div>
                                        ) : (
                                            <span className={`text-xs px-2.5 py-1 rounded-lg font-medium ${c.status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                                {c.status === 'approved' ? 'อนุมัติแล้ว' : 'ปฏิเสธ'}
                                            </span>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}
            </div>

            {rewardForm && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 overflow-y-auto">
                    <div className="bg-card rounded-2xl shadow-xl w-full max-w-md p-6 my-auto">
                        <h2 className="text-lg font-bold mb-4">{rewardForm.id ? 'แก้ไขของรางวัล' : 'เพิ่มของรางวัล'}</h2>
                        <form onSubmit={handleSaveReward} className="space-y-4">
                            {(!['points', 'antivirus'].includes(rewardForm.reward_type) && !(rewardForm.reward_type === 'customization' && ['title', 'name_bg'].includes(rewardForm.customization_type))) && (
                                <div>
                                    <label className="block text-sm font-medium mb-1">ชื่อรางวัล *</label>
                                    <input required value={rewardForm.name} onChange={e => setRewardForm({ ...rewardForm, name: e.target.value })}
                                        placeholder="ชื่อที่จะแสดงในร้านค้า"
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                            )}
                            {(['points', 'antivirus'].includes(rewardForm.reward_type) || (rewardForm.reward_type === 'customization' && ['title', 'name_bg'].includes(rewardForm.customization_type))) && (
                                <div className="bg-blue-50/50 border border-blue-100 p-3 rounded-xl">
                                    <label className="block text-[10px] uppercase font-bold text-blue-600 mb-1">ชื่อรางวัล (ระบบตั้งให้อัตโนมัติ)</label>
                                    <input value={rewardForm.name} onChange={e => setRewardForm({ ...rewardForm, name: e.target.value })}
                                        placeholder="ปล่อยว่างเพื่อใช้ชื่ออัตโนมัติ"
                                        className="w-full bg-transparent border-0 p-0 text-sm font-bold focus:ring-0 placeholder:font-normal" />
                                </div>
                            )}
                            <div>
                                <label className="block text-sm font-medium mb-1">ประเภท *</label>
                                <select value={rewardForm.reward_type || 'item'} onChange={e => setRewardForm({ ...rewardForm, reward_type: e.target.value })}
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                                    <option value="item">ของรางวัลทั่วไป (ของจริง)</option>
                                    <option value="points">คะแนนเก็บพิเศษ (คะแนนดิบ)</option>
                                    <option value="antivirus">💊 ยาต้านไวรัส (มินิเกม)</option>
                                    <option value="customization">🎨 ตกแต่งโปรไฟล์ (กรอบ/ฉายา/สี)</option>
                                </select>
                            </div>
                            
                            {rewardForm.reward_type === 'customization' && (
                                <div className="space-y-3">
                                    <div className="grid grid-cols-2 gap-3 p-3 bg-muted/30 rounded-xl border border-border/50">
                                        <div>
                                            <label className="block text-[10px] uppercase font-bold text-muted-foreground mb-1">ประเภทการตกแต่ง</label>
                                            <select value={rewardForm.customization_type} onChange={e => setRewardForm({ ...rewardForm, customization_type: e.target.value })}
                                                className="w-full border border-input rounded-lg px-2 py-1.5 bg-background text-xs focus:outline-none">
                                                <option value="title">ฉายา (Text)</option>
                                                <option value="frame">กรอบโปรไฟล์ (Image/Animated)</option>
                                                <option value="name_bg">สีพื้นหลังชื่อ (Hex Color)</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label className="block text-[10px] uppercase font-bold text-muted-foreground mb-1">ค่า (Value / Hex / Title)</label>
                                            <div className="flex flex-col gap-2">
                                                {rewardForm.customization_type === 'frame' && (
                                                    <select value={rewardForm.customization_value.startsWith('animated:') ? rewardForm.customization_value : ''} 
                                                        onChange={e => setRewardForm({ ...rewardForm, customization_value: e.target.value })}
                                                        className="w-full border border-input rounded-lg px-2 py-1.5 bg-background text-xs focus:outline-none">
                                                        <option value="">-- เลือกพรีเซ็ตแอนิเมชั่น (หรืออัปโหลดไฟล์ด้านล่าง) --</option>
                                                        {ANIMATION_PRESETS.map(a => (
                                                            <option key={a.id} value={`animated:${a.id}`}>
                                                                {a.icon} {a.name}
                                                            </option>
                                                        ))}
                                                    </select>
                                                )}
                                                <input value={rewardForm.customization_value} onChange={e => setRewardForm({ ...rewardForm, customization_value: e.target.value })}
                                                    placeholder={rewardForm.customization_type === 'name_bg' ? '#ff0000 หรือ gradient...' : 'ใส่ค่าที่นี่'}
                                                    className="flex-1 border border-input rounded-lg px-2 py-1.5 bg-background text-xs focus:outline-none" />
                                                {rewardForm.customization_type === 'name_bg' && (
                                                    <input type="color" value={rewardForm.customization_value.startsWith('#') ? rewardForm.customization_value : '#000000'} 
                                                        onChange={e => setRewardForm({ ...rewardForm, customization_value: e.target.value.toUpperCase() })}
                                                        className="w-8 h-8 rounded-lg overflow-hidden border-0 p-0 cursor-pointer" />
                                                )}
                                            </div>
                                            {rewardForm.customization_type === 'name_bg' && (
                                                <div className="mt-2">
                                                    <p className="text-[9px] uppercase font-bold text-muted-foreground mb-1">พรีเซ็ต Gradient</p>
                                                    <div className="grid grid-cols-6 gap-1">
                                                        {gradientPresets.map((g, i) => (
                                                            <button key={i} type="button" onClick={() => setRewardForm({ ...rewardForm, customization_value: g.value, name: `สีโปรไฟล์: ${g.name}` })}
                                                                className="w-full h-4 rounded-sm border border-black/10 transition hover:scale-110"
                                                                title={g.name}
                                                                style={{ background: g.value }} />
                                                        ))}
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                    
                                    <div className="p-4 bg-muted/40 rounded-2xl border border-border/50">
                                        <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-3 text-center">Live Preview</h3>
                                        <div className="flex flex-col items-center justify-center p-4 bg-background rounded-xl border border-border shadow-inner">
                                            <StudentAvatar 
                                                student={{
                                                    student_id: 'PREVIEW',
                                                    first_name: 'สมมติ',
                                                    last_name: 'นามแฝง',
                                                    title: rewardForm.customization_type === 'title' ? rewardForm.customization_value : '',
                                                    profile_frame: rewardForm.customization_type === 'frame' ? (rewardFile ? URL.createObjectURL(rewardFile) : rewardForm.customization_value) : '',
                                                    name_bg_color: rewardForm.customization_type === 'name_bg' ? rewardForm.customization_value : ''
                                                }} 
                                                size={80} 
                                                showTitle={true}
                                            />
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <div className="flex justify-between items-center mb-1">
                                        <label className="text-xs font-medium">แต้มที่ใช้</label>
                                        <button type="button" onClick={() => setRewardForm({ ...rewardForm, points_required: 0, exp_required: 0 })}
                                            className="text-[10px] bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded-full font-bold hover:bg-emerald-200 transition">
                                            ฟรี
                                        </button>
                                    </div>
                                    <input type="number" value={rewardForm.points_required} onChange={e => setRewardForm({ ...rewardForm, points_required: parseInt(e.target.value) || 0 })}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1 text-blue-600">EXP ที่ใช้</label>
                                    <input type="number" value={rewardForm.exp_required} onChange={e => setRewardForm({ ...rewardForm, exp_required: e.target.value })}
                                        className="w-full border border-blue-200 bg-blue-50/20 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1 text-orange-600">วันที่สิ้นสุดการขาย (Optional)</label>
                                <input type="datetime-local" value={rewardForm.sale_end_date || ''} onChange={e => setRewardForm({ ...rewardForm, sale_end_date: e.target.value })}
                                    className="w-full border border-orange-200 bg-orange-50/20 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500" />
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">ระดับความหายาก (Rarity)</label>
                                <div className="grid grid-cols-4 gap-2">
                                    {['common', 'rare', 'epic', 'legendary'].map(r => (
                                        <button key={r} type="button" onClick={() => setRewardForm({ ...rewardForm, rarity: r })}
                                            className={`py-2 rounded-lg text-[10px] font-bold uppercase border-2 transition ${rewardForm.rarity === r ? 'border-primary bg-primary/10 text-primary' : 'border-transparent bg-muted text-muted-foreground'}`}>
                                            {r}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {rewardForm.reward_type === 'points' ? (
                                <div>
                                    <label className="block text-sm font-medium mb-1">คะแนนที่จะได้รับ *</label>
                                    <input type="number" required value={rewardForm.score_amount} onChange={e => setRewardForm({ ...rewardForm, score_amount: e.target.value })}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                            ) : (
                                <div>
                                    <label className="block text-sm font-medium mb-1">จำนวนคงเหลือ *</label>
                                    <input type="number" required value={rewardForm.stock} onChange={e => setRewardForm({ ...rewardForm, stock: e.target.value })}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                            )}

                            <div>
                                <label className="block text-sm font-medium mb-1">รูปภาพ {rewardForm.customization_type === 'frame' ? '(ใช้สำหรับกรอบภาพด้วย)' : ''}</label>
                                <div className="space-y-2">
                                    <input type="file" accept="image/*" onChange={e => setRewardFile(e.target.files[0])}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none file:bg-primary/10 file:text-primary file:border-0 file:rounded-lg file:px-3 file:py-1 file:mr-4 hover:file:bg-primary/20" />
                                    <input value={rewardForm.image_url || ''} onChange={e => setRewardForm({ ...rewardForm, image_url: e.target.value })}
                                        placeholder="หรือวางลิงก์รูปภาพที่นี่ (https://...)" disabled={!!rewardFile}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50" />
                                </div>
                            </div>

                            <div className="flex gap-3 pt-2">
                                <button type="button" onClick={() => { setRewardForm(null); setRewardFile(null); }} className="flex-1 border border-border rounded-xl py-2 text-sm font-medium hover:bg-muted transition">ยกเลิก</button>
                                <button type="submit" disabled={uploading} className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition disabled:opacity-50">
                                    {uploading ? 'กำลังบันทึก...' : 'บันทึก'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {modalStudent && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                    <div className="bg-card rounded-2xl shadow-xl w-full max-w-md p-6">
                        <h2 className="text-lg font-bold mb-1">ปรับแต้ม</h2>
                        <p className="text-sm text-muted-foreground mb-4">{modalStudent.first_name} {modalStudent.last_name} • ปัจจุบัน {modalStudent.total_points || 0} แต้ม</p>
                        <form onSubmit={handleAdjust} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-1">แต้ม (ใช้ - สำหรับลบ)</label>
                                <input type="number" required value={form.points} onChange={e => setForm({ ...form, points: e.target.value })}
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-1">เหตุผล</label>
                                <input value={form.reason} onChange={e => setForm({ ...form, reason: e.target.value })}
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div className="flex gap-3">
                                <button type="button" onClick={() => setModalStudent(null)} className="flex-1 border border-border rounded-xl py-2 text-sm font-medium hover:bg-muted transition">ยกเลิก</button>
                                <button type="submit" className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition">บันทึก</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {deleteReward && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
                    <div className="bg-card rounded-3xl shadow-2xl w-full max-w-sm p-8 text-center border border-white/20">
                        <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Trash2 size={32} />
                        </div>
                        <h2 className="text-xl font-bold mb-2">ลบของรางวัล</h2>
                        <p className="text-sm text-muted-foreground mb-6">เลือกรูปแบบการลบสำหรับรางวัล<br/><span className="font-bold text-foreground">"{deleteReward.name}"</span></p>
                        
                        <div className="grid gap-3">
                            <button onClick={() => confirmDeleteReward('limited')}
                                className="w-full bg-amber-50 text-amber-700 border border-amber-200 py-3 rounded-2xl text-sm font-bold hover:bg-amber-100 transition flex flex-col items-center">
                                <span>ทำให้เป็น Limited</span>
                                <span className="text-[10px] font-normal opacity-70">ซ่อนจากร้านค้า แต่เด็กที่แลกไปแล้วยังใช้อยู่</span>
                            </button>
                            
                            <button onClick={() => confirmDeleteReward('permanent')}
                                className="w-full bg-red-600 text-white py-3 rounded-2xl text-sm font-bold hover:bg-red-700 transition flex flex-col items-center">
                                <span>ลบถาวร</span>
                                <span className="text-[10px] font-normal opacity-70">ลบออกจากทั้งร้านค้าและตัวเด็กทุกคน</span>
                            </button>
                            
                            <button onClick={() => setDeleteReward(null)}
                                className="w-full bg-muted py-3 rounded-2xl text-sm font-medium hover:bg-muted/80 transition">
                                ยกเลิก
                            </button>
                        </div>
                    </div>
                </div>
            )}
            {manageItemsStudent && <ManageItemsModal student={manageItemsStudent} onClose={() => { setManageItemsStudent(null); load(); }} />}
        </div>
    );
}

function ManageItemsModal({ student, onClose }) {
    const { user } = useAuth();
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);

    async function load() {
        setLoading(true);
        try {
            const res = await base44.entities.StudentItem.filter({ student_id: student.student_id, teacher_id: user.id });
            setItems(res || []);
        } catch (e) { console.error(e); }
        setLoading(false);
    }

    useEffect(() => { load(); }, [student]);

    async function deleteItem(id) {
        if (!await alerts.confirmDanger('ลบไอเทม', 'ยืนยันการลบไอเทมนี้ออกจากตัวนักเรียน?')) return;
        await base44.entities.StudentItem.delete(id);
        load();
    }

    async function removeCustomization(id, type) {
        if (!await alerts.confirmDanger('ลบของตกแต่ง', 'ยืนยันการลบของตกแต่งนี้ออกจากตัวนักเรียน?')) return;
        
        const owned = student.owned_customizations || [];
        const filtered = owned.filter(oc => oc.id !== id);
        const updateData = { owned_customizations: filtered };
        
        const item = owned.find(oc => oc.id === id);
        if (item) {
            if (student.profile_frame === item.value) updateData.profile_frame = '';
            if (student.title === item.value) updateData.title = '';
            if (student.name_bg_color === item.value) updateData.name_bg_color = '';
        }

        await base44.entities.Student.update(student.id, updateData);
        alerts.success('ลบสำเร็จ');
        onClose(); // Close to refresh Parent data
    }

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
            <div className="bg-card rounded-3xl shadow-xl w-full max-w-lg p-6 flex flex-col max-h-[85vh]">
                <div className="flex items-center justify-between mb-4">
                    <div>
                        <h2 className="text-lg font-bold">จัดการไอเทม & ของตกแต่ง</h2>
                        <p className="text-sm text-muted-foreground">{student.first_name} {student.last_name}</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-muted rounded-full">✕</button>
                </div>

                <div className="flex-1 overflow-y-auto space-y-6 pr-2">
                    <section>
                        <h3 className="text-xs font-black uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
                            <div className="w-1 h-3 bg-blue-500 rounded-full" /> ไอเทมในกระเป๋า
                        </h3>
                        <div className="grid gap-2">
                            {items.length === 0 && !loading && <p className="text-xs text-muted-foreground italic py-4 text-center">ไม่มีไอเทมในกระเป๋า</p>}
                            {items.map(it => (
                                <div key={it.id} className="bg-muted/30 border border-border rounded-xl p-3 flex items-center justify-between">
                                    <div>
                                        <p className="font-bold text-sm uppercase">{it.item_type}</p>
                                        <p className="text-xs text-muted-foreground">จำนวน: {it.quantity}</p>
                                    </div>
                                    <button onClick={() => deleteItem(it.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition">
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </section>

                    <section>
                        <h3 className="text-xs font-black uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
                            <div className="w-1 h-3 bg-purple-500 rounded-full" /> ของตกแต่งที่ครอบครอง
                        </h3>
                        <div className="grid gap-2">
                            {(student.owned_customizations || []).length === 0 && <p className="text-xs text-muted-foreground italic py-4 text-center">ไม่มีของตกแต่ง</p>}
                            {(student.owned_customizations || []).map(oc => (
                                <div key={oc.id} className="bg-muted/30 border border-border rounded-xl p-3 flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 bg-background rounded-lg flex items-center justify-center border border-border overflow-hidden">
                                            {oc.value?.startsWith('http') ? <img src={oc.value} alt="" className="w-full h-full object-cover" /> : <div className="text-xs">{(oc.name || 'C').charAt(0)}</div>}
                                        </div>
                                        <div>
                                            <p className="font-bold text-sm">{oc.name || 'Unnamed'}</p>
                                            <p className="text-[10px] text-muted-foreground opacity-60">ID: {oc.id}</p>
                                        </div>
                                    </div>
                                    <button onClick={() => removeCustomization(oc.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition">
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </section>
                </div>
            </div>
        </div>
    );
}

function getPointRank(studentsList, studentId) {
    const sorted = [...studentsList].sort((a, b) => (b.total_points || 0) - (a.total_points || 0));
    return sorted.findIndex(s => s.student_id === studentId) + 1;
}

