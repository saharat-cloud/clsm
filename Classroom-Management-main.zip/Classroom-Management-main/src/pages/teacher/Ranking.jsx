import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Trophy, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import StudentAvatar from '@/components/ui/StudentAvatar';
import { useSemester } from '@/lib/SemesterContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';
import { useAuth } from '@/lib/AuthContext';

export default function Ranking() {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [loading, setLoading] = useState(true);
    const [students, setStudents] = useState([]);
    const [scores, setScores] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [submissions, setSubmissions] = useState([]);
    const [filterCls, setFilterCls] = useState('');
    const [filterSubj, setFilterSubj] = useState('');
    const [tab, setTab] = useState('score');

    async function load() {
        if (!user) return;
        setLoading(true);
        const filter = {
            ...(activeSemester ? { 
                semester_academic_year: activeSemester.academic_year, 
                semester_number: activeSemester.semester 
            } : {}),
            teacher_id: user.id
        };

        const adminFilter = {
            ...(activeSemester ? { 
                semester_academic_year: activeSemester.academic_year, 
                semester_number: activeSemester.semester 
            } : {}),
            teacher_id: 'kanit_admin'
        };
            
        const [stds, sc, cls, subs, asgns, allSubmissions] = await Promise.all([
            base44.entities.Student.filter(adminFilter),
            base44.entities.ScoreRecord.filter(filter),
            base44.entities.Classroom.filter(adminFilter),
            base44.entities.Subject.filter(filter),
            base44.entities.Assignment.filter(filter),
            base44.entities.Submission.filter({ ...filter, status: 'graded' }),
        ]);

        const clsIds = cls.map(c => c.id);
        const stdIds = stds.map(s => s.student_id);

        setStudents(stds); 
        setClassrooms(cls); 
        setSubjects(subs);
        
        // Filter assignments and scores to this semester
        const semsAssignments = asgns.filter(a => clsIds.includes(a.classroom_id));
        setAssignments(semsAssignments);
        setScores(sc.filter(s => clsIds.includes(s.classroom_id) || stdIds.includes(s.student_id)));

        // Filter submissions to these assignments
        const semsAsgnIds = semsAssignments.map(a => a.id);
        setSubmissions(allSubmissions.filter(s => semsAsgnIds.includes(s.assignment_id)));
        
        setLoading(false);
    }

    useEffect(() => { load(); }, [activeSemester]);

    // Find classrooms that have assignments for the selected subject
    const subjectClassroomIds = filterSubj 
        ? [...new Set(assignments.filter(a => a.subject_id === filterSubj).map(a => a.classroom_id))]
        : classrooms.map(c => c.id);

    // Filter students by selected classroom, AND by classrooms that teach the selected subject
    // Filter students by selected classroom, AND ensure they belong to AT LEAST ONE classroom in the current semester
    const displayStudents = students.filter(s => {
        // Find which semesters' classrooms the student is in
        const currentSemesterClassrooms = classrooms.filter(c => (c.student_ids || []).includes(s.id));
        if (currentSemesterClassrooms.length === 0) return false;

        if (filterCls) {
            const cls = classrooms.find(c => c.id === filterCls);
            if (!cls?.student_ids?.includes(s.id)) return false;
        }
        if (filterSubj) {
            const isInSubjectCls = classrooms.some(c => subjectClassroomIds.includes(c.id) && c.student_ids?.includes(s.id));
            if (!isInSubjectCls) return false;
        }
        return true;
    });

    function getTotalScore(studentId) {
        // Find which classroom(s) the student is currently enrolled in
        const enrolledClassroomIds = classrooms.filter(c => (c.student_ids || []).includes(studentId)).map(c => c.id);

        const manualScores = scores.filter(s => {
            if (s.student_id !== studentId) return false;
            if (filterCls && s.classroom_id !== filterCls) return false;
            if (filterSubj && s.subject_id !== filterSubj) return false;
            if (s.classroom_id && !enrolledClassroomIds.includes(s.classroom_id)) return false;
            return true;
        });
        const manualScore = manualScores.reduce((sum, s) => sum + (s.score || 0), 0);

        const validSubmissions = submissions.filter(s => {
            if (s.student_id !== studentId) return false;
            const asgn = assignments.find(a => a.id === s.assignment_id);
            if (!asgn || asgn.is_graded === false) return false;
            if (filterCls && asgn.classroom_id !== filterCls) return false;
            if (filterSubj && asgn.subject_id !== filterSubj) return false;
            if (!enrolledClassroomIds.includes(asgn.classroom_id)) return false;
            return true;
        });
        const assignmentScore = validSubmissions.reduce((sum, s) => sum + (s.score || 0), 0);

        return {
            total: manualScore + assignmentScore,
            manualScore,
            assignmentScore,
            debugScoreRooms: manualScores.map(s => s.classroom_id).join(','),
            debugAssignRooms: validSubmissions.map(s => assignments.find(a=>a.id===s.assignment_id)?.classroom_id).join(',')
        };
    }

    const scoreRanking = [...displayStudents]
        .map(s => ({ ...s, ...getTotalScore(s.student_id) }))
        .sort((a, b) => b.total - a.total);

    // Points are global per student, filtering by subject might not work accurately for points unless points belong to a subject.
    // For now, if subject is filtered, we rank them by score only, OR we just show their global points but filter the list of students.
    const pointRanking = [...displayStudents].sort((a, b) => (b.total_points || 0) - (a.total_points || 0));

    const ranked = tab === 'score' ? scoreRanking : pointRanking;

    const medalColors = ['bg-amber-100 text-amber-600', 'bg-slate-100 text-slate-600', 'bg-orange-100 text-orange-600'];

    if (loading) return <PageLoading />;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-3xl mx-auto px-4 py-8">
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-6">
                    <div className="flex items-center gap-3">
                        <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                        <h1 className="text-2xl font-bold">แรงค์กิ้ง</h1>
                    </div>
                    <div className="sm:ml-auto flex gap-2">
                        <select value={filterSubj} onChange={e => setFilterSubj(e.target.value)}
                            className="flex-1 sm:flex-none border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none">
                            <option value="">ทุกวิชา</option>
                            {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                        <select value={filterCls} onChange={e => setFilterCls(e.target.value)}
                            className="flex-1 sm:flex-none border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none">
                            <option value="">ทุกห้อง</option>
                            {classrooms.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                </div>

                <div className="flex bg-muted rounded-xl p-1 mb-6">
                    {[{ key: 'score', label: '📊 คะแนนเก็บ' }, { key: 'points', label: '⭐ แต้มสะสม' }].map(t => (
                        <button key={t.key} onClick={() => setTab(t.key)}
                            className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${tab === t.key ? 'bg-card shadow text-foreground' : 'text-muted-foreground'}`}>
                            {t.label}
                        </button>
                    ))}
                </div>

                {ranked.slice(0, 3).length > 0 && (
                    <div className="flex items-end justify-center gap-4 mb-8">
                        {[ranked[1], ranked[0], ranked[2]].map((s, i) => {
                            if (!s) return <div key={i} className="w-24" />;
                            const rank = i === 1 ? 1 : i === 0 ? 2 : 3;
                            const heights = ['h-24', 'h-32', 'h-20'];
                            const h = heights[i];
                            return (
                                <div key={s.id} className="flex flex-col items-center gap-2">
                                    <StudentAvatar student={s} size={64} showTitle={true} />
                                    <p className="text-sm font-medium text-center truncate w-20 student-name-${s.student_id}">{s.first_name}</p>
                                    <p className="text-lg font-bold">{tab === 'score' ? s.total : (s.total_points || 0)}</p>
                                    <div className={`w-20 ${h} rounded-t-xl flex items-end justify-center pb-3 ${medalColors[rank - 1]}`}>
                                        {rank === 1 && <Trophy size={24} />}
                                        {rank === 2 && <Star size={20} />}
                                        {rank === 3 && <Star size={18} />}
                                    </div>
                                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${medalColors[rank - 1]}`}>{rank}</div>
                                </div>
                            );
                        })}
                    </div>
                )}

                <div className="bg-card border border-border rounded-2xl divide-y divide-border">
                    {ranked.map((s, idx) => (
                        <div key={s.id} className={`flex items-center gap-4 px-4 py-3 ${idx < 3 ? 'bg-gradient-to-r from-amber-50/50 to-transparent' : ''}`}>
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${idx < 3 ? medalColors[idx] : 'bg-muted text-muted-foreground'}`}>
                                {idx + 1}
                            </div>
                            <StudentAvatar student={s} size={40} showTitle={true} />
                            <div className="flex-1 text-left">
                                <p className={`font-medium student-name-${s.student_id}`}>{s.first_name} {s.last_name}</p>
                                <p className="text-xs font-mono text-muted-foreground">{s.student_id}</p>
                            </div>
                            <p className={`text-lg font-bold ${tab === 'score' ? 'text-blue-600' : 'text-amber-600'}`} title={tab === 'score' ? `สอบ: ${s.manualScore} | งาน: ${s.assignmentScore} (scRooms:${s.debugScoreRooms} | asRooms:${s.debugAssignRooms})` : ''}>
                                {tab === 'score' ? s.total : (s.total_points || 0)}
                                <span className="text-xs text-muted-foreground ml-1">{tab === 'score' ? 'คะแนน' : 'แต้ม'}</span>
                            </p>
                        </div>
                    ))}
                    {ranked.length === 0 && <p className="text-center py-12 text-muted-foreground text-sm">ไม่มีข้อมูล</p>}
                </div>
            </div>
        </div>
    );
}