import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Download, Plus, Pencil, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { alerts } from '@/utils/alerts';
import { useAuth } from '@/lib/AuthContext';
import { useSemester } from '@/lib/SemesterContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';

export default function Scores() {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [students, setStudents] = useState([]);
    const [scores, setScores] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [submissions, setSubmissions] = useState([]);
    const [filterCls, setFilterCls] = useState('');
    const [filterSub, setFilterSub] = useState('');
    const [filterTeacher, setFilterTeacher] = useState('');
    const [allTeachers, setAllTeachers] = useState([]);
    const [modalStudent, setModalStudent] = useState(null);
    const [scoreForm, setScoreForm] = useState({ score_type: '', score: '', max_score: '', note: '' });
    const [editId, setEditId] = useState(null);
    const [loading, setLoading] = useState(true);
    const [editingScore, setEditingScore] = useState(null); // { studentId, type, score, recordId }
    const [addColumnModal, setAddColumnModal] = useState(false);
    const [newColForm, setNewColForm] = useState({ name: '', weight: 10 });

    async function load() {
        if (!user) return;
        setLoading(true);
        try {
            const isAdmin = user.role === 'admin';
            const [clsList, subList, stdList, sc, asgns, allSubmissions, teacherList] = await Promise.all([
                base44.entities.Classroom.list(),
                base44.entities.Subject.list(),
                base44.entities.Student.list(),
                isAdmin 
                    ? (filterTeacher ? base44.entities.ScoreRecord.filter({ teacher_id: filterTeacher }) : base44.entities.ScoreRecord.list())
                    : base44.entities.ScoreRecord.filter({ teacher_id: user.id }),
                isAdmin 
                    ? (filterTeacher ? base44.entities.Assignment.filter({ teacher_id: filterTeacher }) : base44.entities.Assignment.list())
                    : base44.entities.Assignment.filter({ teacher_id: user.id }),
                isAdmin 
                    ? (filterTeacher ? base44.entities.Submission.filter({ teacher_id: filterTeacher, status: 'graded' }) : base44.entities.Submission.filter({ status: 'graded' }))
                    : base44.entities.Submission.filter({ teacher_id: user.id, status: 'graded' }),
                isAdmin ? base44.entities.Teacher.list() : Promise.resolve([])
            ]);

            setSubjects(subList);
            setScores(sc);
            setAssignments(asgns);
            setSubmissions(allSubmissions);
            setAllTeachers(teacherList || []);

            let filteredCls = clsList;
            if (!isAdmin) {
                filteredCls = clsList.filter(c => (c.teacher_id === user.id || c.teacher_ids?.includes(user.id)));
            }
            if (activeSemester) {
                // Defensive: string comparison and allow null for legacy rooms
                filteredCls = filteredCls.filter(c => 
                    !c.semester_academic_year || 
                    (String(c.semester_academic_year) === String(activeSemester.academic_year) && 
                     String(c.semester_number) === String(activeSemester.semester))
                );
            }
            setClassrooms(filteredCls.sort((a,b)=>a.name.localeCompare(b.name)));

            // Filter students: only those belonging to the teacher's classrooms
            const myClsIds = new Set(filteredCls.map(c => c.id));
            setStudents(stdList.filter(s => (s.classroom_ids || []).some(cid => myClsIds.has(cid))));

            if (!filterCls && filteredCls.length > 0) setFilterCls(filteredCls[0].id);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => { load(); }, [user, activeSemester, filterTeacher]);

    const cls = classrooms.find(c => c.id === filterCls);
    const sub = subjects.find(s => s.id === cls?.subject_id);
    const enrolledStudents = students.filter(s => (cls?.student_ids || []).includes(s.id));
    const clsScores = scores.filter(s => s.classroom_id === filterCls);
    const clsAssignments = assignments.filter(a => a.classroom_id === filterCls && a.is_graded !== false);

    const grading = sub?.grading_criteria || { assignment: 20, affective: 10, midterm: 30, final: 40, grades: { 4: 80, 3.5: 75, 3: 70, 2.5: 65, 2: 60, 1.5: 55, 1: 50, 0: 0 } };
    const baseExtraTypes = ['จิตพิสัย', 'สอบกลางภาค', 'สอบปลายภาค', 'คะแนนพิเศษ'];
    const extraTypes = [...baseExtraTypes, ...(cls?.extra_score_types || [])];

    function getTypeKey(type) {
        if (type === 'จิตพิสัย') return 'affective';
        if (type === 'สอบกลางภาค') return 'midterm';
        if (type === 'สอบปลายภาค') return 'final';
        if (type === 'คะแนนพิเศษ') return 'special';
        return 'custom';
    }

    function getRecScore(studentId, type) {
        return clsScores.find(s => s.student_id === studentId && s.score_type === type);
    }

    function getAssignmentSum(studentId) {
        let totalReceived = 0;
        let totalMax = 0;
        clsAssignments.forEach(a => {
            const asmSub = submissions.find(s => s.assignment_id === a.id && s.student_id === studentId);
            if (asmSub && asmSub.status === 'graded') {
                totalReceived += asmSub.score || 0;
            }
            totalMax += a.max_score || 0;
        });
        if (totalMax === 0) return 0;
        return (totalReceived / totalMax) * (grading.assignment || 0);
    }

    function getTotalScore(studentId) {
        const assignmentSum = getAssignmentSum(studentId);
        let extraSum = 0;
        extraTypes.forEach(type => {
            const sc = getRecScore(studentId, type);
            if (sc) {
                const key = getTypeKey(type);
                const weight = key === 'custom' ? (grading[type] || 10) : (grading[key] || 10);
                // If weight equals max_score, no normalization needed (current behavior)
                // But let's support normalization if max_score != weight
                if (sc.max_score > 0 && sc.max_score !== weight) {
                    extraSum += (sc.score / sc.max_score) * weight;
                } else {
                    extraSum += sc.score || 0;
                }
            }
        });
        return assignmentSum + extraSum;
    }

    function calculateGrade(total) {
        if (!grading.grades) return '-';
        const sorted = Object.entries(grading.grades).sort((a,b) => b[1] - a[1]);
        for (const [g, min] of sorted) {
            if (total >= min) return g;
        }
        return '0';
    }

    async function handleSaveScore(e) {
        e?.preventDefault();
        const targetStudent = modalStudent || students.find(s => s.student_id === editingScore?.studentId);
        if (!targetStudent) return;

        const data = {
            teacher_id: user.id,
            student_id: targetStudent.student_id,
            classroom_id: filterCls || null,
            subject_id: cls?.subject_id || null,
            score_type: scoreForm.score_type || editingScore?.type,
            score: Number(scoreForm.score || editingScore?.score),
            max_score: Number(scoreForm.max_score || (editingScore ? (grading[editingScore.type] || 10) : 10)),
            note: scoreForm.note || '',
        };

        const id = editId || editingScore?.recordId;
        if (id) {
            await base44.entities.ScoreRecord.update(id, data);
        } else {
            await base44.entities.ScoreRecord.create(data);
        }

        setModalStudent(null); setEditId(null); setEditingScore(null);
        load();
    }

    async function deleteScore(id) {
        if (!await alerts.confirmDanger('ลบคะแนน', 'ยืนยันการลบคะแนนนี้ใช่หรือไม่?')) return;
        await base44.entities.ScoreRecord.delete(id);
        load();
    }

    async function handleAddColumn(e) {
        e?.preventDefault();
        const { name, weight } = newColForm;
        if (!name) return;
        const current = cls?.extra_score_types || [];
        if (current.includes(name) || baseExtraTypes.includes(name)) {
            alerts.error('ไม่สามารถเพิ่มได้', 'ชื่อช่องคะแนนนี้มีอยู่แล้ว');
            return;
        }

        // Update classroom extra types
        await base44.entities.Classroom.update(filterCls, {
            extra_score_types: [...current, name]
        });

        // Update subject grading criteria with the weight
        if (sub) {
            await base44.entities.Subject.update(sub.id, {
                grading_criteria: {
                    ...grading,
                    [name]: Number(weight)
                }
            });
        }

        setAddColumnModal(false);
        setNewColForm({ name: '', weight: 10 });
        load();
    }

    async function handleRemoveColumn(name) {
        if (!await alerts.confirmDanger('ลบช่องคะแนน', `ลบช่อง "${name}"?\nคะแนนข้างในจะไม่หายแต่จะไม่นำมาคำนวณในหน้านี้`)) return;
        const current = cls?.extra_score_types || [];
        await base44.entities.Classroom.update(filterCls, {
            extra_score_types: current.filter(t => t !== name)
        });
        load();
    }

    async function handleClearClassScores() {
        if (!filterCls) return;
        if (!await alerts.confirmDanger('ล้างคะแนนทั้งหมดของห้องนี้', `ยืนยันการล้างคะแนน? ข้อมูลต่อไปนี้จะถูกลบถาวร:\n1. คะแนนพิเศษ สอบ ทักษะ จิตพิสัยทั้งหมดของห้องนี้\n2. ประวัติการส่งงานและคะแนนการส่งงานทั้งหมดของห้องนี้\n\nการกระทำนี้ไม่สามารถย้อนกลับได้!`)) return;
        
        // Delete score records
        await Promise.all(clsScores.map(sc => base44.entities.ScoreRecord.delete(sc.id)));
        
        // Sweep orphaned scores for students in this room (where classroom_id is null or invalid)
        const enrolledStudentIds = enrolledStudents.map(st => st.student_id);
        const orphanedScores = scores.filter(s => (!s.classroom_id || s.classroom_id === 'null') && enrolledStudentIds.includes(s.student_id));
        if (orphanedScores.length > 0) {
            await Promise.all(orphanedScores.map(sc => base44.entities.ScoreRecord.delete(sc.id)));
        }
        
        // Delete submissions for assignments in this classroom
        const asmIds = clsAssignments.map(a => a.id);
        const allSubs = await base44.entities.Submission.filter({ teacher_id: user.id });
        const subsToDelete = allSubs.filter(s => asmIds.includes(s.assignment_id));
        await Promise.all(subsToDelete.map(sub => base44.entities.Submission.delete(sub.id)));

        alerts.success('ล้างคะแนนสำเร็จ', 'ล้างคะแนนและประวัติการส่งงานของห้องนี้เรียบร้อยแล้ว');
        load();
    }

    function exportExcel() {
        let csv = '\uFEFF'; // BOM for Thai
        const headers = ['รหัสนักเรียน', 'ชื่อ', 'นามสกุล', ...clsAssignments.map(a => a.title), 'รวมคะแนนงาน', ...extraTypes, 'รวมสุทธิ', 'เกรด'];
        csv += headers.join(',') + '\n';
        enrolledStudents.forEach(std => {
            const assignmentScores = clsAssignments.map(a => {
                const sub = submissions.find(s => s.assignment_id === a.id && s.student_id === std.student_id);
                return sub && sub.status === 'graded' ? sub.score : '';
            });
            const total = getTotalScore(std.student_id);
            const row = [
                std.student_id, std.first_name, std.last_name,
                ...assignmentScores,
                getAssignmentSum(std.student_id).toFixed(1),
                ...extraTypes.map(t => getRecScore(std.student_id, t)?.score ?? ''),
                total.toFixed(1),
                calculateGrade(total)
            ];
            csv += row.join(',') + '\n';
        });
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = `คะแนน_${cls?.name || ''}.csv`;
        a.click();
    }

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-6xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <h1 className="text-2xl font-bold">คะแนนเก็บ</h1>
                    <div className="ml-auto flex gap-2">
                        {user?.role === 'admin' && (
                            <select value={filterTeacher} onChange={e => setFilterTeacher(e.target.value)}
                                className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none min-w-[140px]">
                                <option value="">คุณครูทุกคน</option>
                                {allTeachers.map(t => <option key={t.id} value={t.id}>{t.first_name} {t.last_name}</option>)}
                            </select>
                        )}
                        <select value={filterSub} onChange={e => { setFilterSub(e.target.value); setFilterCls(''); }}
                            className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none min-w-[140px]">
                            <option value="">ทุกวิชา</option>
                            {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                        <select value={filterCls} onChange={e => setFilterCls(e.target.value)}
                            className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none min-w-[160px]">
                            <option value="">เลือกห้องเรียน...</option>
                            {classrooms
                                .filter(c => !filterSub || c.subject_id === filterSub)
                                .map(c => {
                                    const s = subjects.find(sub => sub.id === c.subject_id);
                                    return <option key={c.id} value={c.id}>{c.name} {s ? `- ${s.name}` : ''}</option>;
                                })
                            }
                        </select>
                        <button onClick={() => setAddColumnModal(true)}
                            className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl text-sm font-medium hover:opacity-90">
                            <Plus size={16} /> เพิ่มช่องคะแนน
                        </button>
                        {filterCls && (
                            <button onClick={handleClearClassScores}
                                className="flex items-center gap-2 border border-destructive/30 text-destructive px-4 py-2 rounded-xl text-sm hover:bg-destructive/10 transition font-medium">
                                <Trash2 size={16} /> ล้างคะแนนห้องนี้
                            </button>
                        )}
                        <button onClick={exportExcel}
                            className="flex items-center gap-2 border border-border px-4 py-2 rounded-xl text-sm hover:bg-muted transition">
                            <Download size={16} /> Export CSV
                        </button>
                    </div>
                </div>

                {cls && <p className="text-sm text-muted-foreground mb-4">{sub?.name} • {enrolledStudents.length} คน</p>}

                <div className="bg-card border border-border rounded-2xl overflow-auto">
                    <table className="w-full text-sm">
                        <thead className="bg-muted/50">
                            <tr>
                                <th className="text-left px-4 py-3 text-muted-foreground font-medium sticky left-0 bg-muted/50 z-10">นักเรียน</th>
                                {clsAssignments.map(a => <th key={a.id} className="px-4 py-3 text-muted-foreground font-medium whitespace-nowrap min-w-[80px]" title={a.title}>{a.title} ({a.max_score})</th>)}
                                <th className="px-4 py-3 text-blue-700 bg-blue-50/50 font-bold whitespace-nowrap">รวมงาน ({grading.assignment})</th>
                                {extraTypes.map(type => {
                                    const isBase = baseExtraTypes.includes(type);
                                    let colorCls = "text-purple-700 bg-purple-50/50";
                                    if (type === 'สอบกลางภาค') colorCls = "text-emerald-700 bg-emerald-50/50";
                                    if (type === 'สอบปลายภาค') colorCls = "text-orange-700 bg-orange-50/50";
                                    if (type === 'คะแนนพิเศษ') colorCls = "text-rose-700 bg-rose-50/50";
                                    if (!isBase) colorCls = "text-slate-700 bg-slate-100/50";
                                    
                                    return (
                                        <th key={type} className={`px-4 py-3 font-bold whitespace-nowrap ${colorCls}`}>
                                            <div className="flex items-center justify-center gap-1 group">
                                                {type} ({grading[getTypeKey(type)] || scores.find(s => s.score_type === type)?.max_score || 10})
                                                {!isBase && (
                                                    <button onClick={() => handleRemoveColumn(type)} className="opacity-0 group-hover:opacity-100 text-destructive/50 hover:text-destructive transition-all">
                                                        <Trash2 size={12} />
                                                    </button>
                                                )}
                                            </div>
                                        </th>
                                    );
                                })}
                                <th className="px-4 py-3 text-primary bg-primary/5 font-bold whitespace-nowrap">รวมสุทธิ (100)</th>
                                <th className="px-4 py-3 text-primary font-bold text-lg whitespace-nowrap">เกรด</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                            {enrolledStudents.map(std => {
                                const total = getTotalScore(std.student_id);
                                return (
                                <tr key={std.id} className="hover:bg-muted/20">
                                    <td className="px-4 py-3 sticky left-0 bg-card z-10 w-48 shadow-[1px_0_0_0_rgb(0,0,0,0.05)]">
                                        <p className="font-medium truncate">{std.first_name} {std.last_name}</p>
                                        <p className="text-xs text-muted-foreground font-mono truncate">{std.student_id}</p>
                                    </td>
                                    {clsAssignments.map(a => {
                                        const sub = submissions.find(s => s.assignment_id === a.id && s.student_id === std.student_id);
                                        return (
                                            <td key={a.id} className="text-center px-4 py-3">
                                                {sub && sub.status === 'graded' ? (
                                                    <span className="font-medium text-slate-700">{sub.score}</span>
                                                ) : <span className="text-muted-foreground/30">-</span>}
                                            </td>
                                        );
                                    })}
                                    <td className="px-4 py-3 text-center font-bold text-blue-600 bg-blue-50/20">{getAssignmentSum(std.student_id).toFixed(1)}</td>
                                    {extraTypes.map(type => {
                                        const sc = getRecScore(std.student_id, type);
                                        const isBase = baseExtraTypes.includes(type);
                                        let bgCls = "bg-purple-50/20";
                                        if (type === 'สอบกลางภาค') bgCls = "bg-emerald-50/20";
                                        if (type === 'สอบปลายภาค') bgCls = "bg-orange-50/20";
                                        if (type === 'คะแนนพิเศษ') bgCls = "bg-rose-50/20";
                                        if (!isBase) bgCls = "bg-slate-50/20";

                                        return (
                                            <td key={type} className={`px-4 py-3 text-center ${bgCls}`}>
                                                {editingScore?.studentId === std.student_id && editingScore?.type === type ? (
                                                    <input 
                                                        autoFocus
                                                        type="number"
                                                        className="w-16 h-8 text-center border border-primary rounded-lg focus:outline-none focus:ring-2 focus:ring-primary shadow-sm"
                                                        value={editingScore.score}
                                                        onChange={e => setEditingScore({ ...editingScore, score: e.target.value })}
                                                        onBlur={() => handleSaveScore()}
                                                        onKeyDown={e => {
                                                            if (e.key === 'Enter') handleSaveScore();
                                                            if (e.key === 'Escape') setEditingScore(null);
                                                        }}
                                                    />
                                                ) : sc ? (
                                                    <div className="flex items-center gap-1 justify-center group/cell">
                                                        <span 
                                                            className="font-bold text-slate-700 cursor-pointer hover:text-primary transition-colors text-base"
                                                            onClick={() => setEditingScore({ studentId: std.student_id, type, score: sc.score, recordId: sc.id })}
                                                        >
                                                            {sc.score}
                                                        </span>
                                                        <div className="flex opacity-0 group-hover/cell:opacity-100 transition-opacity">
                                                           <button onClick={() => { setModalStudent(std); setEditId(sc.id); setScoreForm({ score_type: sc.score_type, score: sc.score, max_score: sc.max_score, note: sc.note || '' }); }}
                                                               className="p-1 text-muted-foreground hover:text-primary"><Pencil size={12} /></button>
                                                           <button onClick={() => deleteScore(sc.id)} className="p-1 text-muted-foreground hover:text-destructive"><Trash2 size={12} /></button>
                                                        </div>
                                                    </div>
                                                ) : (
                                                    <button onClick={() => setEditingScore({ studentId: std.student_id, type, score: '', recordId: null })} 
                                                        className="text-xs text-primary hover:underline hover:font-bold transition-all flex items-center justify-center w-full min-h-[24px]">
                                                        + เพิ่ม
                                                    </button>
                                                )}
                                            </td>
                                        );
                                    })}
                                    <td className="px-4 py-3 text-center font-black text-primary text-lg bg-primary/10">{total.toFixed(0)}</td>
                                    <td className="px-4 py-3 text-center font-black text-emerald-600 text-lg">{calculateGrade(total)}</td>
                                </tr>
                            )})}
                            {enrolledStudents.length === 0 && (
                                <tr><td colSpan={clsAssignments.length + 8} className="text-center py-12 text-muted-foreground">ไม่มีนักเรียนในห้องนี้</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {modalStudent && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                    <div className="bg-card rounded-2xl shadow-xl w-full max-w-md p-6">
                        <h2 className="text-lg font-bold mb-1">{editId ? 'แก้ไขคะแนน' : 'เพิ่มคะแนน'}</h2>
                        <p className="text-sm text-muted-foreground mb-4">{modalStudent.first_name} {modalStudent.last_name}</p>
                        <form onSubmit={handleSaveScore} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-1">ประเภทคะแนน *</label>
                                <input required list="score-types" value={scoreForm.score_type} onChange={e => setScoreForm({ ...scoreForm, score_type: e.target.value })}
                                    placeholder="เช่น จิตพิสัย, สอบกลางภาค"
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                <datalist id="score-types">{extraTypes.map(t => <option key={t} value={t} />)}</datalist>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-sm font-medium mb-1">คะแนน *</label>
                                    <input type="number" required min={0} value={scoreForm.score} onChange={e => setScoreForm({ ...scoreForm, score: e.target.value })}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">คะแนนเต็ม *</label>
                                    <input type="number" required min={1} value={scoreForm.max_score} onChange={e => setScoreForm({ ...scoreForm, max_score: e.target.value })}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-1">หมายเหตุ</label>
                                <input value={scoreForm.note} onChange={e => setScoreForm({ ...scoreForm, note: e.target.value })}
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div className="flex gap-3">
                                <button type="button" onClick={() => { setModalStudent(null); setEditId(null); }} className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted transition">ยกเลิก</button>
                                <button type="submit" className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition">บันทึก</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
            {addColumnModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                    <div className="bg-card rounded-2xl shadow-xl w-full max-w-sm p-6">
                        <h2 className="text-lg font-bold mb-4">เพิ่มช่องคะแนน</h2>
                        <form onSubmit={handleAddColumn} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-1">ชื่อช่องคะแนน *</label>
                                <input required value={newColForm.name} onChange={e => setNewColForm({ ...newColForm, name: e.target.value })}
                                    placeholder="เช่น คะแนนจิตอาสา"
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-1">สัดส่วนคะแนน (Weight) *</label>
                                <div className="flex items-center gap-3">
                                    <input type="number" required min={0} value={newColForm.weight} onChange={e => setNewColForm({ ...newColForm, weight: Number(e.target.value) })}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                    <span className="text-sm text-muted-foreground">คะแนน</span>
                                </div>
                                <p className="text-[10px] text-muted-foreground mt-1">* เมื่อเก็บคะแนน ระบบจะคำนวณสัดส่วนคะแนนนี้จากคะแนนเต็มที่ระบุตอนกรอก</p>
                            </div>
                            <div className="flex gap-3 pt-2">
                                <button type="button" onClick={() => setAddColumnModal(false)} className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted transition">ยกเลิก</button>
                                <button type="submit" className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition">เพิ่มช่อง</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}