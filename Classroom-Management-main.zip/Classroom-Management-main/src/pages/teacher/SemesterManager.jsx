import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Plus, Trash2, CheckCircle, Archive, Copy } from 'lucide-react';
import { Link } from 'react-router-dom';
import { alerts } from '@/utils/alerts';
import { useSemester } from '@/lib/SemesterContext';
import { useAuth } from '@/lib/AuthContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';

import { playClick, playDelete } from '@/lib/sound';

const CURRENT_THAI_YEAR = String(new Date().getFullYear() + 543);

export default function SemesterManager({ adminMode = false }) {
    const { user } = useAuth();
    const { activeSemester, setActiveSemester, allSemesters, reloadSemesters, semesterLabel } = useSemester();
    const [form, setForm] = useState({ academic_year: CURRENT_THAI_YEAR, semester: 1 });
    const [showNew, setShowNew] = useState(false);
    const [saving, setSaving] = useState(false);

    // Carry-forward state
    const [carryFromSem, setCarryFromSem] = useState(null);
    const [classrooms, setClassrooms] = useState([]);
    const [selectedRooms, setSelectedRooms] = useState([]);
    const [carryTargetSem, setCarryTargetSem] = useState(null);

    useEffect(() => {
        if (carryFromSem && user) {
            base44.entities.Classroom.filter({
                ...(adminMode ? {} : { teacher_id: user.id }),
                semester_academic_year: carryFromSem.academic_year,
                semester_number: carryFromSem.semester,
            }).then(setClassrooms);
        }
    }, [carryFromSem, user]);

    async function handleCreateSemester(e) {
        e.preventDefault();
        const exists = allSemesters.find(
            s => s.academic_year === form.academic_year && s.semester === Number(form.semester)
        );
        if (exists) {
            alerts.error('มีเทอมนี้อยู่แล้ว', `ปีการศึกษา ${form.academic_year} เทอม ${form.semester} ถูกสร้างไปแล้ว`);
            return;
        }
        setSaving(true);
        try {
            const newSem = await base44.entities.Semester.create({
                teacher_id: user.id,
                academic_year: form.academic_year,
                semester: Number(form.semester),
                label: `ปีการศึกษา ${form.academic_year} เทอม ${form.semester}`,
                is_active: false,
            });
            await reloadSemesters();
            setShowNew(false);
            alerts.success('สร้างเทอมสำเร็จ', semesterLabel(newSem));
        } catch (err) {
            alerts.error('เกิดข้อผิดพลาด', err.message);
        } finally {
            setSaving(false);
        }
    }

    async function handleSetActive(sem) {
        setActiveSemester(sem);
        alerts.success('เปลี่ยนเทอมสำเร็จ', `ตอนนี้ดูข้อมูล: ${semesterLabel(sem)}`);
    }

    async function handleDelete(sem) {
        if (!await alerts.confirmDanger('ลบเทอม', `ลบ ${semesterLabel(sem)}?\n\nข้อมูลทั้งหมดในเทอมนี้จะยังอยู่ในฐานข้อมูล แต่เทอมจะหายจากรายการ`)) return;
        await base44.entities.Semester.delete(sem.id);
        if (activeSemester?.id === sem.id) setActiveSemester(null);
        reloadSemesters();
    }

    async function handleReset(sem) {
        if (user?.role !== 'admin') {
            alerts.error('สิทธิ์ไม่เพียงพอ', 'เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถรีเซ็ตข้อมูลเทอมได้');
            return;
        }

        const choice = await alerts.confirmDanger(
            `Reset ข้อมูลเทอม ${semesterLabel(sem)}`,
            `จะลบข้อมูลทั้งหมดใน ${semesterLabel(sem)} ออกถาวร:\n• ห้องเรียนและนักเรียน\n• รายวิชา งานมอบหมาย และคะแนน\n• แต้มสะสมและของรางวัล\n\nยืนยันหรือไม่?`
        );
        if (!choice) return;

        setSaving(true);
        try {
            const filter = {
                semester_academic_year: sem.academic_year,
                semester_number: sem.semester
            };

            const isGlobalAdmin = user.role === 'admin';
            const [cls, stds] = await Promise.all([
                base44.entities.Classroom.filter({ ...filter, ...(isGlobalAdmin ? {} : { teacher_id: user.id }) }),
                base44.entities.Student.filter({ ...filter, ...(isGlobalAdmin ? {} : { teacher_id: user.id }) }),
            ]);

            const clsIds = cls.map(c => c.id);
            const stdIds = stds.map(s => s.student_id);

            // Fetch everything tied to this semester across all users if admin
            const [allAssignments, allScores, allPoints, allRewards, allClaims, allSubmissions, allNotifications, allSubjects, allMaterials, allInfections, allRequests] = await Promise.all([
                base44.entities.Assignment.filter(filter),
                base44.entities.ScoreRecord.filter(filter),
                base44.entities.PointTransaction.filter(filter),
                base44.entities.Reward.filter(filter),
                base44.entities.RewardClaim.filter(filter),
                base44.entities.Submission.filter(filter),
                base44.entities.Notification.filter(filter),
                base44.entities.Subject.filter(filter),
                base44.entities.Material.filter(filter),
                base44.entities.Infection.filter(filter),
                base44.entities.ItemRequest.filter(filter),
            ]);

            // Additional filtering for safety (by classroom or student IDs)
            // Materials can be linked to multiple classrooms
            const materialsToDelete = allMaterials.filter(m => 
                (m.classroom_ids || []).some(cid => clsIds.includes(cid)) ||
                (m.semester_academic_year === sem.academic_year && m.semester_number === sem.semester)
            );

            const assignmentsToDelete = allAssignments.filter(a => !a.classroom_id || clsIds.includes(a.classroom_id) || (a.semester_academic_year === sem.academic_year && a.semester_number === sem.semester));
            const submissionsToDelete = allSubmissions.filter(s => stdIds.includes(s.student_id) || assignmentsToDelete.some(a => a.id === s.assignment_id));
            const scoresToDelete = allScores.filter(s => stdIds.includes(s.student_id) || (s.classroom_id && clsIds.includes(s.classroom_id)) || (s.semester_academic_year === sem.academic_year && s.semester_number === sem.semester));
            const pointsToDelete = allPoints.filter(p => stdIds.includes(p.student_id) || (p.semester_academic_year === sem.academic_year && p.semester_number === sem.semester));
            const rewardsToDelete = allRewards.filter(r => !r.classroom_id || clsIds.includes(r.classroom_id) || (r.semester_academic_year === sem.academic_year && r.semester_number === sem.semester));
            const claimsToDelete = allClaims.filter(c => stdIds.includes(c.student_id) || (c.semester_academic_year === sem.academic_year && c.semester_number === sem.semester));
            const notificationsToDelete = allNotifications.filter(n => stdIds.includes(n.student_id) || (n.semester_academic_year === sem.academic_year && n.semester_number === sem.semester));

            // Delete in order
            await Promise.all([
                ...submissionsToDelete.map(s => base44.entities.Submission.delete(s.id)),
                ...scoresToDelete.map(s => base44.entities.ScoreRecord.delete(s.id)),
                ...pointsToDelete.map(p => base44.entities.PointTransaction.delete(p.id)),
                ...claimsToDelete.map(c => base44.entities.RewardClaim.delete(c.id)),
                ...rewardsToDelete.map(r => base44.entities.Reward.delete(r.id)),
                ...notificationsToDelete.map(n => base44.entities.Notification.delete(n.id)),
                ...materialsToDelete.map(m => base44.entities.Material.delete(m.id)),
                ...allInfections.map(i => base44.entities.Infection.delete(i.id)),
                ...allRequests.map(r => base44.entities.ItemRequest.delete(r.id)),
            ]);

            await Promise.all([
                ...assignmentsToDelete.map(a => base44.entities.Assignment.delete(a.id)),
                ...allSubjects.map(s => base44.entities.Subject.delete(s.id)),
            ]);

            await Promise.all([
                ...cls.map(c => base44.entities.Classroom.delete(c.id)),
                ...stds.map(s => base44.entities.Student.delete(s.id)),
            ]);

            alerts.success('Reset เรียบร้อย', `ลบข้อมูลทั้งหมดในเทอม ${semesterLabel(sem)} แล้ว`);
            reloadSemesters();
        } catch (err) {
            console.error('Reset error:', err);
            alerts.error('เกิดข้อผิดพลาดในการ Reset', err.message);
        } finally {
            setSaving(false);
        }
    }

    async function handleCarryForward() {
        if (!selectedRooms.length || !carryTargetSem) {
            alerts.error('ไม่ครบ', 'กรุณาเลือกห้องเรียนและเทอมปลายทาง');
            return;
        }
        if (!await alerts.confirm('ย้ายห้องเรียน', `ย้าย ${selectedRooms.length} ห้อง ไปยัง ${semesterLabel(carryTargetSem)}?\n(คะแนนและงานเก่าจะไม่ถูกโอน)`)) return;
        try {
            const roomsToClone = classrooms.filter(c => selectedRooms.includes(c.id));
            await Promise.all(roomsToClone.map(c => base44.entities.Classroom.create({
                name: c.name,
                level: c.level,
                room_number: c.room_number,
                academic_year: c.academic_year,
                semester: c.semester,
                subject_ids: c.subject_ids,
                student_ids: c.student_ids,
                semester_academic_year: carryTargetSem.academic_year,
                semester_number: carryTargetSem.semester,
            })));
            alerts.success('ย้ายสำเร็จ', `โอน ${selectedRooms.length} ห้องไปยัง ${semesterLabel(carryTargetSem)}`);
            setCarryFromSem(null);
            setSelectedRooms([]);
            setCarryTargetSem(null);
        } catch (err) {
            alerts.error('เกิดข้อผิดพลาด', err.message);
        }
    }

    async function handleCleanupOrphaned() {
        if (!await alerts.confirmDanger(
            'ล้างข้อมูลตกค้าง',
            'ระบบจะลบข้อมูลที่ไม่ได้ผูกกับปีการศึกษาใดๆ ออกทั้งหมด:\n• ห้องเรียน/นักเรียน/วิชาที่ไม่มีเทอม\n• คะแนน/งาน/แต้มที่ไม่มีเทอม\n\nยืนยันหรือไม่?'
        )) return;

        if (!await alerts.confirmDanger('ยืนยันอีกครั้ง', 'ข้อมูลที่ไม่มีเทอมจะหายไปถาวร!')) return;

        setSaving(true);
        try {
            const entitiesToClean = [
                'Assignment', 'ScoreRecord', 'PointTransaction', 'Submission', 
                'Subject', 'Classroom', 'Student', 'Reward', 'RewardClaim', 
                'Material', 'Infection', 'ItemRequest', 'Notification', 'StudentItem'
            ];

            let totalDeleted = 0;
            for (const entityName of entitiesToClean) {
                try {
                    // Fetch items where semester_academic_year IS NULL or EMPTY STRING
                    const items = await base44.entities[entityName].list();
                    const orphaned = items.filter(item => 
                        !item.semester_academic_year || 
                        item.semester_academic_year === '' || 
                        item.semester_academic_year === 'null'
                    );

                    if (orphaned.length > 0) {
                        await Promise.all(orphaned.map(item => base44.entities[entityName].delete(item.id)));
                        totalDeleted += orphaned.length;
                    }
                } catch (e) {
                    console.warn(`Skipping cleanup for ${entityName}: ${e.message}`);
                    // Skip tables that don't have the semester columns
                }
            }

            alerts.success('ทำความสะอาดเรียบร้อย', `ลบข้อมูลตกค้างทั้งหมด ${totalDeleted} รายการแล้ว`);
            reloadSemesters();
        } catch (err) {
            console.error('Cleanup error:', err);
            alerts.error('เกิดข้อผิดพลาดในการทำความสะอาด', err.message);
        } finally {
            setSaving(false);
        }
    }

    const sorted = [...allSemesters].sort((a, b) => {
        if (a.academic_year !== b.academic_year) return b.academic_year.localeCompare(a.academic_year);
        return b.semester - a.semester;
    });

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-3xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <div className="flex-1">
                        <h1 className="text-2xl font-bold">{adminMode ? 'จัดการปีการศึกษา (ระบบส่วนกลาง)' : 'จัดการปีการศึกษา'}</h1>
                        <p className="text-sm text-muted-foreground">เทอมที่ดูอยู่: <span className="font-semibold text-primary">{semesterLabel(activeSemester) || 'ยังไม่ได้เลือก'}</span></p>
                    </div>
                    {user?.role === 'admin' && (
                        <div className="flex gap-2">
                            <button onClick={handleCleanupOrphaned} disabled={saving}
                                className="flex items-center gap-1.5 border border-destructive/30 text-destructive px-3 py-2 rounded-xl text-sm font-medium hover:bg-destructive/10 transition">
                                <Trash2 size={16} /> ล้างข้อมูลตกค้าง
                            </button>
                            <button onClick={() => { playClick(); setShowNew(!showNew)} }
                                className="flex items-center gap-1.5 bg-primary text-primary-foreground px-3 py-2 rounded-xl text-sm font-medium hover:opacity-90 transition">
                                <Plus size={16} /> เพิ่มปีการศึกษา
                            </button>
                        </div>
                    )}
                </div>

                {/* New Semester Form */}
                {showNew && (
                    <div className="bg-card border border-border rounded-2xl p-5 mb-4">
                        <h2 className="font-bold mb-3">สร้างเทอมใหม่</h2>
                        <form onSubmit={handleCreateSemester} className="flex flex-wrap gap-3 items-end">
                            <div>
                                <label className="block text-xs font-medium mb-1">ปีการศึกษา (พ.ศ.)</label>
                                <input type="number" min="2560" max="2580" value={form.academic_year}
                                    onChange={e => setForm({ ...form, academic_year: e.target.value })}
                                    className="border border-input rounded-xl px-3 py-2 bg-background text-sm w-28 focus:outline-none focus:ring-2 focus:ring-ring" />
                            </div>
                            <div>
                                <label className="block text-xs font-medium mb-1">เทอม</label>
                                <select value={form.semester} onChange={e => setForm({ ...form, semester: Number(e.target.value) })}
                                    className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                                    <option value={1}>เทอม 1</option>
                                    <option value={2}>เทอม 2</option>
                                </select>
                            </div>
                            <button type="submit" disabled={saving}
                                className="bg-primary text-primary-foreground px-5 py-2 rounded-xl text-sm font-medium hover:opacity-90 disabled:opacity-50">
                                {saving ? 'กำลังสร้าง...' : 'สร้าง'}
                            </button>
                            <button type="button" onClick={() => setShowNew(false)}
                                className="border border-border px-4 py-2 rounded-xl text-sm hover:bg-muted">
                                ยกเลิก
                            </button>
                        </form>
                    </div>
                )}

                {/* Carry Forward Modal */}
                {carryFromSem && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                        <div className="bg-card rounded-2xl shadow-xl w-full max-w-lg p-6">
                            <h2 className="text-lg font-bold mb-1">ย้ายห้องเรียนไปเทอมถัดไป</h2>
                            <p className="text-sm text-muted-foreground mb-4">จาก: {semesterLabel(carryFromSem)}</p>

                            <div className="mb-4">
                                <label className="block text-sm font-medium mb-2">เทอมปลายทาง</label>
                                <select value={carryTargetSem?.id || ''} onChange={e => setCarryTargetSem(allSemesters.find(s => s.id === e.target.value) || null)}
                                    className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                                    <option value="">-- เลือกเทอมปลายทาง --</option>
                                    {allSemesters.filter(s => s.id !== carryFromSem.id).map(s => (
                                        <option key={s.id} value={s.id}>{semesterLabel(s)}</option>
                                    ))}
                                </select>
                            </div>

                            <div className="mb-4">
                                <label className="block text-sm font-medium mb-2">เลือกห้องเรียนที่ต้องการย้าย ({selectedRooms.length}/{classrooms.length})</label>
                                <div className="grid gap-2 max-h-48 overflow-y-auto">
                                    {classrooms.length === 0 && <p className="text-sm text-muted-foreground py-4 text-center">ไม่มีห้องเรียนในเทอมนี้</p>}
                                    {classrooms.map(c => (
                                        <label key={c.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-muted cursor-pointer">
                                            <input type="checkbox" checked={selectedRooms.includes(c.id)}
                                                onChange={e => setSelectedRooms(prev => e.target.checked ? [...prev, c.id] : prev.filter(id => id !== c.id))}
                                                className="w-4 h-4" />
                                            <span className="text-sm font-medium">{c.name}</span>
                                        </label>
                                    ))}
                                </div>
                                {classrooms.length > 0 && (
                                    <button type="button" onClick={() => setSelectedRooms(s => s.length === classrooms.length ? [] : classrooms.map(c => c.id))}
                                        className="mt-2 text-xs text-primary hover:underline">
                                        {selectedRooms.length === classrooms.length ? 'ยกเลิกทั้งหมด' : 'เลือกทั้งหมด'}
                                    </button>
                                )}
                            </div>

                            <div className="flex gap-3">
                                <button onClick={() => { setCarryFromSem(null); setSelectedRooms([]); setCarryTargetSem(null); }}
                                    className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted">ยกเลิก</button>
                                <button onClick={handleCarryForward}
                                    className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90">
                                    ย้ายห้องเรียน
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Semester List */}
                <div className="grid gap-3">
                    {sorted.length === 0 && (
                        <div className="text-center py-16 text-muted-foreground border-2 border-dashed border-border rounded-2xl">
                            <p>ยังไม่มีปีการศึกษา</p>
                            <p className="text-sm mt-1">กดปุ่ม "เพิ่มปีการศึกษา" เพื่อเริ่มต้น</p>
                        </div>
                    )}
                    {sorted.map(sem => {
                        const isActive = activeSemester?.id === sem.id;
                        return (
                            <div key={sem.id} className={`bg-card border rounded-2xl p-5 transition-all ${isActive ? 'border-primary ring-2 ring-primary/20' : 'border-border'}`}>
                                <div className="flex items-center gap-3">
                                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${isActive ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                                        <span className="text-sm font-bold">{sem.semester}</span>
                                    </div>
                                    <div className="flex-1">
                                        <p className="font-bold">{semesterLabel(sem)}</p>
                                        {isActive && <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">กำลังดูอยู่</span>}
                                    </div>
                                    <div className="flex gap-2 flex-wrap justify-end">
                                        {!isActive && (
                                            <button onClick={() => handleSetActive(sem)}
                                                className="flex items-center gap-1 text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-xl hover:opacity-90">
                                                <CheckCircle size={13} /> เลือกเทอมนี้
                                            </button>
                                        )}
                                        {user?.role === 'admin' && (
                                            <>
                                                <button onClick={() => { setCarryFromSem(sem); setSelectedRooms([]); }}
                                                    className="flex items-center gap-1 text-xs border border-border px-3 py-1.5 rounded-xl hover:bg-muted">
                                                    <Copy size={13} /> ย้ายห้อง→
                                                </button>
                                                <button onClick={() => handleReset(sem)}
                                                    className="flex items-center gap-1 text-xs border border-amber-300 text-amber-700 px-3 py-1.5 rounded-xl hover:bg-amber-50">
                                                    <Archive size={13} /> Reset
                                                </button>
                                                <button onClick={() => handleDelete(sem)}
                                                    className="flex items-center gap-1 text-xs border border-destructive/30 text-destructive px-3 py-1.5 rounded-xl hover:bg-destructive/10">
                                                    <Trash2 size={13} /> ลบ
                                                </button>
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>

                <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-2xl text-sm text-amber-800">
                    <p className="font-bold mb-1">⚠️ หมายเหตุสำคัญ</p>
                    <ul className="space-y-1 list-disc list-inside">
                        <li>การ Reset จะลบ ห้องเรียน นักเรียน และวิชาในเทอมนั้น <strong>ถาวร</strong></li>
                        <li>คะแนน/งาน/แต้ม ที่ผูกกับนักเรียนจะยังอยู่ในฐานข้อมูล แต่อาจแสดงผลไม่ครบ</li>
                        <li>ย้ายห้องเรียน = โอนเฉพาะโครงสร้างห้อง ไม่โอนคะแนนหรืองาน</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}
