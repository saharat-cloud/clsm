import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Bell, AlertTriangle, Clock, CheckCircle, Send } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { useSemester } from '@/lib/SemesterContext';

export default function StudentStatus() {
    const { user } = useAuth();
    const [classrooms, setClassrooms] = useState([]);
    const [students, setStudents] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [submissions, setSubmissions] = useState([]);
    const [selectedClassroom, setSelectedClassroom] = useState('');
    const [sending, setSending] = useState(null); // student object OR classroom object
    const [sendMode, setSendMode] = useState('individual'); // 'individual', 'room_all', 'room_pending'
    const [msgTitle, setMsgTitle] = useState('');
    const [msgBody, setMsgBody] = useState('');
    const [sent, setSent] = useState(false);

    const { activeSemester } = useSemester();

    useEffect(() => {
        async function load() {
            if (!user) return;
            const filter = { 
                ...(activeSemester ? { 
                    semester_academic_year: activeSemester.academic_year, 
                    semester_number: activeSemester.semester 
                } : {}),
                teacher_id: user.id 
            };

            const adminFilter = {
                ...(activeSemester ? { 
                    semester_academic_year: activeSemester.academic_year, 
                    semester_number: activeSemester.semester 
                } : {}),
                teacher_id: 'kanit_admin'
            };

            const [cls, std, asgn, subs] = await Promise.all([
                base44.entities.Classroom.filter(adminFilter),
                base44.entities.Student.filter(adminFilter),
                base44.entities.Assignment.filter(filter),
                base44.entities.Submission.filter(filter),
            ]);
            setClassrooms(cls);
            setStudents(std);
            setAssignments(asgn);
            setSubmissions(subs);
            if (cls.length > 0) setSelectedClassroom(cls[0].id);
            else setSelectedClassroom('');
        }
        load();
    }, [user, activeSemester]);

    const now = new Date();
    const soon = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000); // 3 days

    const classroom = classrooms.find(c => c.id === selectedClassroom);
    const classStudents = classroom ? students.filter(s => (classroom.student_ids || []).includes(s.id)) : [];
    const classAssignments = assignments.filter(a => a.classroom_id === selectedClassroom);

    function getStudentStatus(student) {
        const pending = [];
        const overdue = [];
        classAssignments.forEach(a => {
            const sub = submissions.find(s => s.assignment_id === a.id && s.student_id === student.student_id);
            if (!sub) {
                const due = new Date(a.due_date);
                if (due < now) overdue.push(a);
                else if (due <= soon) pending.push(a);
            }
        });
        return { pending, overdue };
    }

    async function handleSendNotification(e) {
        e.preventDefault();
        
        let targetStudentIds = [];
        
        if (sendMode === 'individual') {
            targetStudentIds = [sending.student_id];
        } else {
            // Bulk send
            if (sendMode === 'room_all') {
                targetStudentIds = classStudents.map(s => s.student_id);
            } else if (sendMode === 'room_pending') {
                targetStudentIds = classStudents.filter(s => {
                    const status = getStudentStatus(s);
                    return status.pending.length > 0 || status.overdue.length > 0;
                }).map(s => s.student_id);
            }
        }
        
        if (targetStudentIds.length === 0) {
            setSent(true);
            setTimeout(() => { setSent(false); setSending(null); setMsgTitle(''); setMsgBody(''); }, 1500);
            return;
        }

        const notifications = targetStudentIds.map(student_id => ({
            teacher_id: user.id,
            student_id,
            title: msgTitle,
            message: msgBody,
            type: 'assignment_reminder',
            is_read: false,
        }));
        
        // Supabase bulk insert
        await base44.entities.Notification.bulkCreate(notifications);
        
        setSent(true);
        setTimeout(() => { setSent(false); setSending(null); setMsgTitle(''); setMsgBody(''); }, 1500);
    }

    function openNotify(student) {
        setSendMode('individual');
        setSending(student);
        const { pending, overdue } = getStudentStatus(student);
        setMsgTitle('แจ้งเตือนงานค้าง');
        setMsgBody(
            overdue.length > 0
                ? `คุณมีงานที่เลยกำหนดส่งแล้ว ${overdue.length} ชิ้น กรุณาส่งงานโดยด่วน`
                : `คุณมีงานที่ใกล้ครบกำหนดส่ง ${pending.length} ชิ้น กรุณาส่งงานก่อนครบกำหนด`
        );
    }

    function openRoomNotify() {
        setSendMode('room_all');
        setSending(classroom);
        setMsgTitle(`ประกาศถึงห้อง ${classroom.name}`);
        setMsgBody('');
    }

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-5xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <div>
                        <h1 className="text-2xl font-bold">สถานะงานของนักเรียน</h1>
                        <p className="text-muted-foreground text-sm">ติดตามและแจ้งเตือนนักเรียน</p>
                    </div>
                </div>

                {/* Classroom selector */}
                <div className="flex gap-2 flex-wrap mb-6">
                    {classrooms.map(c => (
                        <button key={c.id} onClick={() => setSelectedClassroom(c.id)}
                            className={`px-4 py-2 rounded-xl text-sm font-medium transition ${selectedClassroom === c.id ? 'bg-primary text-primary-foreground' : 'bg-card border border-border hover:bg-muted'}`}>
                            {c.name}
                        </button>
                    ))}
                </div>

                {/* Stats */}
                {classroom && (
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-6">
                        {[
                            { label: 'นักเรียนทั้งหมด', value: classStudents.length, color: 'text-foreground' },
                            { label: 'งานค้างเลยกำหนด', value: classStudents.filter(s => getStudentStatus(s).overdue.length > 0).length, color: 'text-destructive' },
                            { label: 'ใกล้ครบกำหนด', value: classStudents.filter(s => getStudentStatus(s).pending.length > 0).length, color: 'text-orange-500' },
                        ].map(stat => (
                            <div key={stat.label} className="bg-card border border-border rounded-2xl p-4 text-center">
                                <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
                                <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
                            </div>
                        ))}
                        <div className="bg-card border border-border rounded-2xl p-4 flex flex-col items-center justify-center gap-2 hover:bg-muted/50 transition cursor-pointer" onClick={openRoomNotify}>
                            <div className="w-12 h-12 bg-primary/10 text-primary rounded-full flex items-center justify-center">
                                <Bell size={24} />
                            </div>
                            <p className="text-sm font-semibold text-primary">แจ้งเตือนทั้งห้อง</p>
                        </div>
                    </div>
                )}

                {/* Student list */}
                <div className="grid gap-3">
                    {classStudents.map(student => {
                        const { pending, overdue } = getStudentStatus(student);
                        const total = classAssignments.length;
                        const submitted = classAssignments.filter(a =>
                            submissions.some(s => s.assignment_id === a.id && s.student_id === student.student_id)
                        ).length;
                        const pct = total > 0 ? (submitted / total) * 100 : 100;

                        return (
                            <div key={student.id} className="bg-card border border-border rounded-2xl p-4">
                                <div className="flex items-center gap-4">
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-1">
                                            <p className="font-semibold">{student.first_name} {student.last_name}</p>
                                            <span className="text-xs text-muted-foreground font-mono">{student.student_id}</span>
                                            {overdue.length > 0 && (
                                                <span className="flex items-center gap-1 text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">
                                                    <AlertTriangle size={10} /> เลยกำหนด {overdue.length}
                                                </span>
                                            )}
                                            {pending.length > 0 && overdue.length === 0 && (
                                                <span className="flex items-center gap-1 text-xs bg-orange-100 text-orange-600 px-2 py-0.5 rounded-full">
                                                    <Clock size={10} /> ใกล้ครบ {pending.length}
                                                </span>
                                            )}
                                            {overdue.length === 0 && pending.length === 0 && (
                                                <span className="flex items-center gap-1 text-xs bg-green-100 text-green-600 px-2 py-0.5 rounded-full">
                                                    <CheckCircle size={10} /> ปกติ
                                                </span>
                                            )}
                                        </div>
                                        {/* Progress bar */}
                                        <div className="flex items-center gap-2">
                                            <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                                                <div className={`h-full rounded-full transition-all ${pct === 100 ? 'bg-green-500' : pct >= 50 ? 'bg-primary' : 'bg-orange-400'}`}
                                                    style={{ width: `${pct}%` }} />
                                            </div>
                                            <span className="text-xs text-muted-foreground whitespace-nowrap">{submitted}/{total} งาน</span>
                                        </div>
                                        {overdue.length > 0 && (
                                            <p className="text-xs text-destructive mt-1">
                                                งานค้าง: {overdue.map(a => a.title).join(', ')}
                                            </p>
                                        )}
                                    </div>
                                    {(overdue.length > 0 || pending.length > 0) && (
                                        <button onClick={() => openNotify(student)}
                                            className="flex items-center gap-2 bg-primary text-primary-foreground px-3 py-2 rounded-xl text-sm hover:opacity-90 transition whitespace-nowrap">
                                            <Bell size={14} /> แจ้งเตือน
                                        </button>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                    {classStudents.length === 0 && (
                        <div className="text-center py-16 text-muted-foreground">ยังไม่มีนักเรียนในห้องนี้</div>
                    )}
                </div>
            </div>

            {/* Notification modal */}
            {sending && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
                    <div className="bg-card rounded-2xl shadow-xl w-full max-w-md p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-lg font-bold">ส่งข้อความแจ้งเตือน</h2>
                            <button onClick={() => setSending(null)} className="text-muted-foreground hover:text-foreground">✕</button>
                        </div>
                        
                        {sendMode === 'individual' ? (
                            <p className="text-sm text-muted-foreground mb-4">ถึง: {sending.first_name} {sending.last_name}</p>
                        ) : (
                            <div className="mb-4">
                                <p className="text-sm font-medium mb-2">กลุ่มเป้าหมาย ({sending.name})</p>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                    <label className={`flex items-center gap-2 p-3 text-sm rounded-xl border cursor-pointer transition select-none ${sendMode === 'room_all' ? 'border-primary bg-primary/10 text-primary' : 'border-border'}`}>
                                        <input type="radio" className="hidden" 
                                            name="roomNotifyOpt"
                                            checked={sendMode === 'room_all'}
                                            onChange={() => setSendMode('room_all')} />
                                        ทุกคนในห้อง ({classStudents.length})
                                    </label>
                                    <label className={`flex items-center gap-2 p-3 text-sm rounded-xl border cursor-pointer transition select-none ${sendMode === 'room_pending' ? 'border-primary bg-primary/10 text-primary' : 'border-border'}`}>
                                        <input type="radio" className="hidden" 
                                            name="roomNotifyOpt"
                                            checked={sendMode === 'room_pending'}
                                            onChange={() => setSendMode('room_pending')} />
                                        เฉพาะคนค้าง/เลยกำหนด
                                    </label>
                                </div>
                            </div>
                        )}

                        {sent ? (
                            <div className="text-center py-6">
                                <CheckCircle size={40} className="text-green-500 mx-auto mb-2" />
                                <p className="font-semibold text-green-600">ส่งข้อความสำเร็จ!</p>
                            </div>
                        ) : (
                            <form onSubmit={handleSendNotification} className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium mb-1">หัวข้อ</label>
                                    <input required value={msgTitle} onChange={e => setMsgTitle(e.target.value)}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">ข้อความ</label>
                                    <textarea required value={msgBody} onChange={e => setMsgBody(e.target.value)} rows={4}
                                        className="w-full border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
                                </div>
                                <div className="flex gap-3">
                                    <button type="button" onClick={() => setSending(null)}
                                        className="flex-1 border border-border rounded-xl py-2 text-sm hover:bg-muted transition font-medium">ยกเลิก</button>
                                    <button type="submit"
                                        className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium hover:opacity-90 transition flex items-center justify-center gap-2">
                                        <Send size={14} /> ส่งข้อความ
                                    </button>
                                </div>
                            </form>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}