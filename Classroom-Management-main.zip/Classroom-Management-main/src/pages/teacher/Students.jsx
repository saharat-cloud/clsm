import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Pencil, Trash2, Upload, ArrowLeft, Search, Eye, EyeOff } from 'lucide-react';
import { Link } from 'react-router-dom';
import StudentModal from '@/components/teacher/StudentModal';
import ImportStudentsModal from '@/components/teacher/ImportStudentsModal';
import { playClick, playDelete } from '@/lib/sound';
import { alerts } from '@/utils/alerts';
import { useSemester } from '@/lib/SemesterContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';
import { useAuth } from '@/lib/AuthContext';

export default function Students({ adminMode = false }) {
    const { user } = useAuth();
    const { activeSemester, semesterLabel } = useSemester();
    const [students, setStudents] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [modal, setModal] = useState(null);
    const [showImport, setShowImport] = useState(false);
    const [search, setSearch] = useState('');
    const [filterCls, setFilterCls] = useState('');
    const [showPasswords, setShowPasswords] = useState({});
    const [selectedIds, setSelectedIds] = useState([]);
    const [loading, setLoading] = useState(true);

    async function load() {
        if (!user) return;
        setLoading(true);
        const filter = {
            ...(activeSemester ? { semester_academic_year: activeSemester.academic_year, semester_number: activeSemester.semester } : {}),
            ...(adminMode ? {} : { teacher_id: user.id })
        };
        const [stds, cls] = await Promise.all([
            base44.entities.Student.filter(filter),
            base44.entities.Classroom.filter(filter),
        ]);
        
        setStudents(stds);
        setClassrooms(cls);
        setLoading(false);
    }

    useEffect(() => { load(); }, [activeSemester]);

    async function handleDelete(id) {
        if (!await alerts.confirmDanger('ลบนักเรียน', 'ลบนักเรียนคนนี้?')) return;
        playDelete();
        await base44.entities.Student.delete(id);
        load();
    }

    const filtered = students.filter(s => {
        const matchSearch = !search || s.student_id?.includes(search) || s.first_name?.includes(search) || s.last_name?.includes(search) || s.nickname?.includes(search);
        const cls = classrooms.find(c => c.id === filterCls);
        const matchCls = !filterCls || (cls?.student_ids || []).includes(s.id);
        return matchSearch && matchCls;
    });

    function toggleSelect(id) {
        setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    }

    function toggleSelectAll() {
        if (selectedIds.length === filtered.length) setSelectedIds([]);
        else setSelectedIds(filtered.map(s => s.id));
    }

    async function handleBulkDelete() {
        if (selectedIds.length === 0) return;
        if (!await alerts.confirmDanger('ลบนักเรียนหลายคน', `ยืนยันการลบนักเรียน ${selectedIds.length} คนที่เลือก?`)) return;
        
        setLoading(true);
        try {
            await Promise.all(selectedIds.map(id => base44.entities.Student.delete(id)));
            alerts.success('ลบนักเรียนเรียบร้อยแล้ว');
            setSelectedIds([]);
            load();
        } catch (e) {
            alerts.error('ผิดพลาด', e.message);
            setLoading(false);
        }
    }

    const clsMap = Object.fromEntries(classrooms.map(c => [c.id, c]));

    if (loading) return <PageLoading />;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-5xl mx-auto px-4 py-8 pb-24">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <div>
                        <h1 className="text-2xl font-bold">{adminMode ? 'จัดการนักเรียน (ระบบส่วนกลาง)' : 'นักเรียน'}</h1>
                        <p className="text-muted-foreground text-sm">{semesterLabel(activeSemester) || 'ทุกเทอม'} • {filtered.length} คน</p>
                    </div>
                    {user?.role === 'admin' && (
                        <div className="ml-auto flex gap-2">
                            <button onClick={() => { playClick(); setShowImport(true); }}
                                className="flex items-center gap-2 border border-border px-3 py-2 rounded-xl text-sm hover:bg-muted transition">
                                <Upload size={16} /> Excel/CSV
                            </button>
                            <button onClick={() => { playClick(); setModal('create'); }}
                                className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl text-sm font-semibold hover:opacity-90 transition">
                                <Plus size={16} /> เพิ่มนักเรียน
                            </button>
                        </div>
                    )}
                </div>

                {/* Bulk Actions */}
                {user?.role === 'admin' && selectedIds.length > 0 && (
                    <div className="mb-4 flex items-center justify-between bg-destructive/10 border border-destructive/20 p-4 rounded-2xl animate-in slide-in-from-top-2">
                        <p className="text-sm font-bold text-destructive">เลือกนักเรียน {selectedIds.length} คน</p>
                        <button onClick={handleBulkDelete} className="flex items-center gap-2 bg-destructive text-white px-4 py-2 rounded-xl text-sm font-bold hover:opacity-90 transition">
                            <Trash2 size={16} /> ลบที่เลือกทั้งหมด
                        </button>
                    </div>
                )}

                {/* Filters */}
                <div className="flex gap-3 mb-4 flex-wrap">
                    <div className="relative flex-1 min-w-48">
                        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                        <input value={search} onChange={e => setSearch(e.target.value)}
                            placeholder="ค้นหาชื่อ หรือรหัสนักเรียน..."
                            className="w-full pl-9 pr-4 py-2 border border-input rounded-xl bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                    </div>
                    <select value={filterCls} onChange={e => setFilterCls(e.target.value)}
                        className="border border-input rounded-xl px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                        <option value="">ทุกห้อง</option>
                        {classrooms.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                </div>

                <div className="bg-card rounded-2xl border border-border overflow-hidden">
                    <table className="w-full text-sm">
                        <thead className="bg-muted/50">
                            <tr>
                                {user?.role === 'admin' && (
                                    <th className="px-4 py-3 w-10">
                                        <input type="checkbox" checked={selectedIds.length > 0 && selectedIds.length === filtered.length} onChange={toggleSelectAll} className="rounded border-border" />
                                    </th>
                                )}
                                <th className="text-left px-4 py-3 font-medium text-muted-foreground">รหัส</th>
                                <th className="text-left px-4 py-3 font-medium text-muted-foreground">ชื่อ-สกุล</th>
                                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">ชื่อเล่น</th>
                                <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">ห้อง</th>
                                <th className="px-5 py-3 text-left text-xs font-bold text-muted-foreground uppercase tracking-wider">สถานะ</th>
                                <th className="text-left px-4 py-3 font-medium text-muted-foreground">Password</th>
                                <th className="text-left px-4 py-3 font-medium text-muted-foreground">แต้ม</th>
                                <th className="px-4 py-3"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                            {filtered.map((s) => {
                                const studentClassrooms = (s.classroom_ids || []).map(cid => clsMap[cid]).filter(Boolean);
                                return (
                                    <tr key={s.id} className={`hover:bg-muted/30 transition-colors ${selectedIds.includes(s.id) ? 'bg-primary/5' : ''}`}>
                                        {user?.role === 'admin' && (
                                            <td className="px-4 py-3">
                                                <input type="checkbox" checked={selectedIds.includes(s.id)} onChange={() => toggleSelect(s.id)} className="rounded border-border" />
                                            </td>
                                        )}
                                        <td className="px-4 py-3 font-mono text-sm">{s.student_id}</td>
                                        <td className="px-4 py-3 font-medium">{s.first_name} {s.last_name}</td>
                                        <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{s.nickname || '-'}</td>
                                        <td className="px-4 py-3 hidden sm:table-cell">
                                            <div className="flex flex-wrap gap-1">
                                                {studentClassrooms.map(c => (
                                                    <span key={c.id} className="text-xs px-2 py-0.5 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-300 rounded-full">{c.name}</span>
                                                ))}
                                                {studentClassrooms.length === 0 && <span className="text-xs text-muted-foreground">-</span>}
                                            </div>
                                        </td>
                                        <td className="px-5 py-4 whitespace-nowrap">
                                            {(() => {
                                                if (!s.last_active_at) return <span className="text-xs text-muted-foreground">ไม่เคยเข้าใช้งาน</span>;
                                                const diff = Date.now() - new Date(s.last_active_at).getTime();
                                                const isOnline = diff < 15 * 60 * 1000;
                                                return (
                                                    <div className="flex items-center gap-2">
                                                        <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)] animate-pulse' : 'bg-muted-foreground/30'}`} />
                                                        <span className={`text-[11px] font-bold ${isOnline ? 'text-green-600' : 'text-muted-foreground'}`}>
                                                            {isOnline ? 'ออนไลน์' : new Date(s.last_active_at).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}
                                                        </span>
                                                    </div>
                                                );
                                            })()}
                                        </td>
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2">
                                                <span className="font-mono">{showPasswords[s.id] ? s.password : '••••••'}</span>
                                                <button onClick={() => setShowPasswords(p => ({ ...p, [s.id]: !p[s.id] }))}
                                                    className="text-muted-foreground hover:text-foreground">
                                                    {showPasswords[s.id] ? <EyeOff size={14} /> : <Eye size={14} />}
                                                </button>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3 whitespace-nowrap">
                                            <div className="flex items-center gap-3">
                                                <span className="font-bold text-amber-600">{s.total_points || 0}</span>
                                                {user?.role === 'admin' && (
                                                    <div className="flex items-center gap-1 ml-auto">
                                                        <button onClick={() => { playClick(); setModal(s); }} className="p-1.5 text-muted-foreground hover:text-primary rounded-lg hover:bg-muted transition"><Pencil size={15} /></button>
                                                        <button onClick={() => handleDelete(s.id)} className="p-1.5 text-muted-foreground hover:text-destructive rounded-lg hover:bg-destructive/10 transition"><Trash2 size={15} /></button>
                                                    </div>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                            {filtered.length === 0 && (
                                <tr><td colSpan={user?.role === 'admin' ? 8 : 7} className="text-center py-12 text-muted-foreground">ไม่พบข้อมูล</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {modal && (
                <StudentModal
                    student={modal === 'create' ? null : modal}
                    onClose={() => setModal(null)}
                    onSaved={() => { setModal(null); load(); }}
                />
            )}
            {showImport && (
                <ImportStudentsModal onClose={() => setShowImport(false)} onSaved={() => { setShowImport(false); load(); }} />
            )}
        </div>
    );
}