import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Pencil, Trash2, BookOpen, ArrowLeft, FileText, ClipboardList } from 'lucide-react';
import { Link } from 'react-router-dom';
import SubjectModal from '@/components/teacher/SubjectModal';
import { alerts } from '@/utils/alerts';
import { useSemester } from '@/lib/SemesterContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';
import { useAuth } from '@/lib/AuthContext';

export default function Subjects({ adminMode = false }) {
    const { user } = useAuth();
    const { activeSemester, semesterLabel } = useSemester();
    const [subjects, setSubjects] = useState([]);
    const [allTeachers, setAllTeachers] = useState([]);
    const [modal, setModal] = useState(null);
    const [loading, setLoading] = useState(true);

    async function load() {
        if (!user) return;
        setLoading(true);
        try {
            if (adminMode) {
                const [subs, teachers] = await Promise.all([
                    base44.entities.Subject.list(),
                    base44.entities.Teacher.list()
                ]);
                setSubjects(subs);
                setAllTeachers(teachers);
            } else {
                const filter = {
                    teacher_id: user.id,
                    ...(activeSemester ? { 
                        semester_academic_year: activeSemester.academic_year, 
                        semester_number: activeSemester.semester 
                    } : {})
                };
                const data = await base44.entities.Subject.filter(filter);
                setSubjects(data);
            }
        } catch (err) {
            console.error(err);
        }
        setLoading(false);
    }

    useEffect(() => { load(); }, [activeSemester]);

    async function handleDelete(id) {
        if (!await alerts.confirmDanger('ลบรายวิชา', 'ยืนยันการลบรายวิชานี้ใช่หรือไม่?')) return;
        await base44.entities.Subject.delete(id);
        load();
    }

    const filtered = subjects;

    if (loading) return <PageLoading />;

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-4xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-8">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground">
                        <ArrowLeft size={20} />
                    </Link>
                    <div>
                        <h1 className="text-2xl font-bold">{adminMode ? 'จัดการรายวิชา (ทั้งหมด)' : 'รายวิชา'}</h1>
                        <p className="text-muted-foreground text-sm">
                            {adminMode ? 'ระบบส่วนกลาง' : (semesterLabel(activeSemester) || 'ทุกเทอม')} • {filtered.length} วิชา
                        </p>
                    </div>
                    <div className="ml-auto flex gap-2">
                        <button
                            onClick={() => setModal('create')}
                            className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl text-sm font-medium hover:opacity-90 transition"
                        >
                            <Plus size={16} /> เพิ่มวิชา
                        </button>
                    </div>
                </div>

                <div className="grid gap-3">
                    {filtered.map((s) => (
                        <div key={s.id} className="bg-card border border-border rounded-2xl p-5 flex items-center gap-4">
                            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                                <BookOpen size={20} className="text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="font-semibold truncate">{s.name}</p>
                                <div className="flex items-center gap-2 overflow-hidden">
                                    <p className="text-sm text-muted-foreground truncate">{s.code} {s.credit ? `• ${s.credit} หน่วยกิต` : ''}</p>
                                    {adminMode && (
                                        <span className="text-[10px] bg-muted px-2 py-0.5 rounded-full font-medium text-muted-foreground truncate max-w-[150px]">
                                            ครู: {allTeachers.find(t => t.id === s.teacher_id)?.first_name || 'ไม่ระบุ'}
                                        </span>
                                    )}
                                </div>
                            </div>
                            <button onClick={() => setModal(s)} className="p-2 text-muted-foreground hover:text-primary transition" title="แก้ไขวิชา">
                                <Pencil size={16} />
                            </button>
                            <div className="flex border-l border-border ml-2 pl-2 gap-1">
                                <Link to={`/teacher/materials?subject=${s.id}`} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition flex items-center gap-1.5" title="เพิ่มเนื้อหา">
                                    <FileText size={16} />
                                    <span className="text-[10px] font-bold uppercase">เนื้อหา</span>
                                </Link>
                                <Link to={`/teacher/assignments/new?subject=${s.id}`} className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition flex items-center gap-1.5" title="สั่งงาน">
                                    <ClipboardList size={16} />
                                    <span className="text-[10px] font-bold uppercase">สั่งงาน</span>
                                </Link>
                            </div>
                            <button onClick={() => handleDelete(s.id)} className="p-2 text-muted-foreground hover:text-destructive transition ml-1" title="ลบวิชา">
                                <Trash2 size={16} />
                            </button>
                        </div>
                    ))}
                    {filtered.length === 0 && (
                        <div className="text-center py-16 text-muted-foreground">ยังไม่มีรายวิชา</div>
                    )}
                </div>
            </div>

            {modal && (
                <SubjectModal
                    subject={modal === 'create' ? null : modal}
                    onClose={() => setModal(null)}
                    onSaved={() => { setModal(null); load(); }}
                />
            )}
        </div>
    );
}