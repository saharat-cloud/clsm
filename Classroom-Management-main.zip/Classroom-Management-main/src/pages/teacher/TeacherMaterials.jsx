import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { alerts } from '@/utils/alerts';
import { useSemester } from '@/lib/SemesterContext';
import { FileText, Upload, Plus, Trash2, Globe, File, Image as ImageIcon, AlertTriangle, Pencil } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

export default function TeacherMaterials() {
    const { activeSemester } = useSemester();
    const { user } = useAuth();
    const [materials, setMaterials] = useState([]);
    const [classrooms, setClassrooms] = useState([]);
    const [subjects, setSubjects] = useState([]);
    const [loading, setLoading] = useState(true);
    
    const [isPosting, setIsPosting] = useState(false);
    const [editingMat, setEditingMat] = useState(null);
    const [filterSubject, setFilterSubject] = useState('');
    const [filterClassroom, setFilterClassroom] = useState('');
    const [filterTeacher, setFilterTeacher] = useState('');
    const [allTeachers, setAllTeachers] = useState([]);
    const [form, setForm] = useState({
        title: '', content: '', classroom_ids: [], subject_id: ''
    });
    const [reuseAttachmentUrls, setReuseAttachmentUrls] = useState([]);
    const [files, setFiles] = useState([]);
    const [uploading, setUploading] = useState(false);

    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const sub = params.get('subject');
        const cls = params.get('classroom');
        if (sub) setFilterSubject(sub);
        if (cls) setFilterClassroom(cls);
    }, []);

    useEffect(() => {
        loadData();
    }, [activeSemester, filterTeacher]);

    async function loadData() {
        if (!activeSemester || !user) return;
        setLoading(true);
        setMaterials([]);
        try {
            const isAdmin = user.role === 'admin';
            const [clsList, matList, subList, teacherList] = await Promise.all([
                base44.entities.Classroom.list(),
                isAdmin 
                    ? (filterTeacher ? base44.entities.Material.filter({ teacher_id: filterTeacher }) : base44.entities.Material.list())
                    : base44.entities.Material.filter({ teacher_id: user.id }),
                isAdmin ? base44.entities.Subject.list() : base44.entities.Subject.filter({ teacher_id: user.id }),
                isAdmin ? base44.entities.Teacher.list() : Promise.resolve([])
            ]);
            
            setSubjects(subList || []);
            setAllTeachers(teacherList || []);
            
            let filteredCls = clsList;
            if (user && user.id && !isAdmin) {
                filteredCls = clsList.filter(c => (c.teacher_id === user.id || c.teacher_ids?.includes(user.id)));
            }

            if (activeSemester) {
                // Defensive: string comparison and allow null for legacy rooms
                filteredCls = filteredCls.filter(c => 
                    !c.semester_academic_year || 
                    (String(c.semester_academic_year) === String(activeSemester.academic_year) && 
                     String(c.semester_number) === String(activeSemester.semester))
                );
            }
            
            setClassrooms(filteredCls.sort((a,b)=>a.name.localeCompare(b.name)));

            let filteredMats = matList;
            if (activeSemester) {
                filteredMats = matList.filter(m => 
                    !m.semester_academic_year ||
                    (String(m.semester_academic_year) === String(activeSemester.academic_year) && 
                     String(m.semester_number) === String(activeSemester.semester))
                );
            }
            setMaterials(filteredMats.sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()));
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }

    function handleFileChange(e) {
        if (e.target.files) {
            setFiles(Array.from(e.target.files));
        }
    }

    async function handleSubmit(e) {
        e.preventDefault();
        if (form.classroom_ids.length === 0) {
            alerts.error('กรุณาเลือกห้องเรียนอย่างน้อย 1 ห้อง');
            return;
        }

        // Check for subject-classroom mismatch
        if (form.subject_id) {
            const mismatchedRooms = classrooms
                .filter(c => form.classroom_ids.includes(c.id) && !(c.subject_ids || []).includes(form.subject_id))
                .map(c => c.name);
            
            if (mismatchedRooms.length > 0) {
                const proceed = await alerts.confirm(
                    'ยืนยันการโพสต์',
                    `วิชานี้ไม่ได้จัดตารางสอนในห้อง: ${mismatchedRooms.join(', ')} คุณต้องการโพสต์เนื้อหานี้ไปยังห้องดังกล่าวด้วยหรือไม่?`
                );
                if (!proceed) return;
            }
        }

        setUploading(true);
        try {
            const uploadedUrls = [...reuseAttachmentUrls];
            
            if (files.length > 0) {
                for (const f of files) {
                    const ext = f.name.split('.').pop();
                    const fileName = `materials/${Date.now()}_${Math.random().toString(36).substring(7)}.${ext}`;
                    
                    const { error: uploadError } = await supabase.storage
                        .from('assignments')
                        .upload(fileName, f);
                    if (uploadError) throw uploadError;

                    const { data } = supabase.storage.from('assignments').getPublicUrl(fileName);
                    uploadedUrls.push(data.publicUrl);
                }
            }

            const payload = {
                title: form.title,
                content: form.content,
                attachment_urls: uploadedUrls,
                classroom_ids: form.classroom_ids,
                subject_id: form.subject_id || null,
                teacher_id: user.id,
                semester_academic_year: activeSemester?.academic_year || '',
                semester_number: activeSemester?.semester || 1
            };

            if (editingMat) {
                await base44.entities.Material.update(editingMat.id, payload);
                alerts.success('อัพเดทเนื้อหาเรียบร้อยแล้ว');
            } else {
                const newMat = await base44.entities.Material.create(payload);
                setMaterials(prev => [newMat, ...prev]);
                alerts.success('โพสต์เนื้อหาเรียบร้อยแล้ว');
            }

            // Notify students
            const targetClassrooms = classrooms.filter(c => form.classroom_ids.includes(c.id));
            const studentIds = new Set();
            targetClassrooms.forEach(c => (c.student_ids || []).forEach(id => studentIds.add(id)));
            
            if (studentIds.size > 0) {
                const students = await base44.entities.Student.filter({ teacher_id: user.id });
                const targetStudents = students.filter(s => studentIds.has(s.id));
                const notifs = targetStudents.map(s => ({
                    teacher_id: user.id,
                    student_id: s.student_id,
                    title: '📚 เนื้อหาเรียนใหม่',
                    message: `ครูได้โพสต์เนื้อหาใหม่: ${form.title}`,
                    type: 'new_material',
                    is_read: false
                }));
                if (notifs.length > 0) {
                    await base44.entities.Notification.bulkCreate(notifs);
                }
            }

            loadData();
            setIsPosting(false);
            setEditingMat(null);
            setForm({ title: '', content: '', classroom_ids: [], subject_id: '' });
            setFiles([]);
            setReuseAttachmentUrls([]);
            
        } catch (err) {
            console.error(err);
            alerts.error('เกิดข้อผิดพลาด', 'ไม่สามารถโพสต์เนื้อหาได้');
        } finally {
            setUploading(false);
        }
    }

    async function handleDelete(id) {
        if (!await alerts.confirmDanger('ลบเนื้อหา', 'ยืนยันการลบเนื้อหานี้ใช่หรือไม่?')) return;
        try {
            await base44.entities.Material.delete(id);
            setMaterials(prev => prev.filter(m => m.id !== id));
            alerts.success('ลบเนื้อหาเรียบร้อยแล้ว');
        } catch (err) {
            console.error(err);
            alerts.error('ลบไม่สำเร็จ');
        }
    }

    function toggleClassroom(cid) {
        setForm(f => ({
            ...f,
            classroom_ids: f.classroom_ids.includes(cid) 
                ? f.classroom_ids.filter(id => id !== cid)
                : [...f.classroom_ids, cid]
        }));
    }

    function handleReuse(m) {
        setIsPosting(true);
        setEditingMat(m);
        setForm({
            title: m.title,
            content: m.content || '',
            subject_id: m.subject_id || '',
            classroom_ids: m.classroom_ids || []
        });
        setReuseAttachmentUrls(m.attachment_urls || []);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function getFileIcon(url) {
        if (url.match(/\.(jpeg|jpg|gif|png|webp)$/i)) return <ImageIcon size={20} className="text-blue-500" />;
        if (url.match(/\.(pdf)$/i)) return <FileText size={20} className="text-red-500" />;
        return <File size={20} className="text-gray-500" />;
    }

    return (
        <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold">เนื้อหาบทเรียน</h1>
                    <p className="text-muted-foreground mt-1 text-sm">แชร์ไฟล์ เอกสาร หรือประกาศให้นักเรียนในห้องเรียน</p>
                </div>
                <button 
                    onClick={() => {
                        setIsPosting(!isPosting);
                        if (!isPosting) {
                            setEditingMat(null);
                            setForm({ title: '', content: '', classroom_ids: [], subject_id: '' });
                            setFiles([]);
                            setReuseAttachmentUrls([]);
                        }
                    }}
                    className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-xl text-sm font-medium hover:opacity-90 transition shadow-sm"
                >
                    <Plus size={18} /> {isPosting ? 'ย่อหน้าต่าง' : 'โพสต์เนื้อหาใหม่'}
                </button>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-3 bg-muted/30 p-4 rounded-2xl border border-border/50">
                {user?.role === 'admin' && (
                    <div className="flex-1 min-w-[200px]">
                        <label className="text-[10px] font-bold uppercase text-muted-foreground ml-1 mb-1 block tracking-wider">แสดงเนื้อหาของคุณครู</label>
                        <select value={filterTeacher} onChange={e => setFilterTeacher(e.target.value)}
                            className="w-full bg-background border border-input rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-primary outline-none transition shadow-sm">
                            <option value="">คุณครูทุกคน (รวมศูนย์)</option>
                            {allTeachers.map(t => (
                                <option key={t.id} value={t.id}>{t.first_name} {t.last_name}</option>
                            ))}
                        </select>
                    </div>
                )}
                <div className="flex-1 min-w-[200px]">
                    <label className="text-[10px] font-bold uppercase text-muted-foreground ml-1 mb-1 block tracking-wider">แสดงเฉพาะวิชา</label>
                    <select value={filterSubject} onChange={e => setFilterSubject(e.target.value)}
                        className="w-full bg-background border border-input rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-primary outline-none transition shadow-sm">
                        <option value="">ทั้งหมดทุกวิชา</option>
                        {subjects.map(s => (
                            <option key={s.id} value={s.id}>[{s.code}] {s.name}</option>
                        ))}
                    </select>
                </div>
                <div className="flex-1 min-w-[200px]">
                    <label className="text-[10px] font-bold uppercase text-muted-foreground ml-1 mb-1 block tracking-wider">แสดงเฉพาะห้องเรียน</label>
                    <select value={filterClassroom} onChange={e => setFilterClassroom(e.target.value)}
                        className="w-full bg-background border border-input rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-primary outline-none transition shadow-sm">
                        <option value="">ทั้งหมดทุกห้อง</option>
                        {classrooms.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                    </select>
                </div>
            </div>

            {isPosting && (
                <div className="bg-card border border-border rounded-2xl p-6 shadow-sm animate-in fade-in slide-in-from-top-4">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="space-y-1.5">
                            <label className="text-sm font-medium">หัวข้อเนื้อหา <span className="text-red-500">*</span></label>
                            <input required value={form.title} onChange={e => setForm({...form, title: e.target.value})}
                                className="w-full px-3 py-2 border border-input rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary" 
                                placeholder="เช่น สไลด์ประกอบการสอน บทที่ 1"
                            />
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-sm font-medium">รายละเอียด / คำติชม / ลิงก์</label>
                            <textarea value={form.content} onChange={e => setForm({...form, content: e.target.value})}
                                rows={4} className="w-full px-3 py-2 border border-input rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                                placeholder="คำอธิบายเพิ่มเติม หรือแปะลิงก์ YouTube..."
                            />
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-sm font-medium">ไฟล์แนบ (PDF, Word, รูปภาพ ฯลฯ)</label>
                            <div className="border-2 border-dashed border-border rounded-xl p-6 text-center hover:bg-muted/50 transition">
                                <input type="file" multiple id="fileUpload" className="hidden" onChange={handleFileChange} />
                                <label htmlFor="fileUpload" className="cursor-pointer flex flex-col items-center gap-2">
                                    <div className="w-10 h-10 bg-primary/10 text-primary rounded-full flex items-center justify-center">
                                        <Upload size={20} />
                                    </div>
                                    <span className="text-sm font-medium text-primary">คลิกเพื่อเลือกไฟล์</span>
                                    <span className="text-xs text-muted-foreground">สามารถเลือกได้หลายไฟล์พร้อมกัน</span>
                                </label>
                                {files.length > 0 && (
                                    <div className="mt-4 flex flex-wrap gap-2 justify-center">
                                        {files.map((f, i) => (
                                            <span key={i} className="bg-background border border-input text-xs px-2.5 py-1.5 rounded-lg truncate max-w-[200px] flex items-center gap-1.5">
                                                <File size={14} className="text-muted-foreground" /> {f.name}
                                            </span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                                <label className="text-sm font-medium">ระบุวิชา (ถ้ามี)</label>
                                <select 
                                    value={form.subject_id} 
                                    onChange={e => setForm({...form, subject_id: e.target.value})}
                                    className="w-full px-3 py-2 border border-input rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                                >
                                    <option value="">-- ไม่ระบุวิชา --</option>
                                    {subjects.map(s => (
                                        <option key={s.id} value={s.id}>[{s.code}] {s.name}</option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-sm font-medium">แจกจ่ายให้ห้องเรียน <span className="text-red-500">*</span></label>
                            {classrooms.length === 0 ? (
                                <p className="text-sm text-amber-600 bg-amber-50 p-3 rounded-xl border border-amber-100">ย้งไม่มีห้องเรียนในภาคการศึกษานี้</p>
                            ) : (
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                                    {classrooms.map(c => {
                                        const isMismatch = form.subject_id && !(c.subject_ids || []).includes(form.subject_id);
                                        return (
                                            <div key={c.id} onClick={() => toggleClassroom(c.id)}
                                                className={`p-3 rounded-xl border text-sm text-center cursor-pointer transition select-none relative ${
                                                    form.classroom_ids.includes(c.id) 
                                                    ? 'bg-primary/10 border-primary text-primary font-bold' 
                                                    : 'bg-background hover:bg-muted font-medium'
                                                } ${isMismatch && form.classroom_ids.includes(c.id) ? 'ring-2 ring-amber-500 ring-offset-2' : ''}`}
                                            >
                                                {c.name}
                                                {isMismatch && (
                                                    <div className="absolute -top-1 -right-1 bg-amber-500 text-white rounded-full p-0.5 shadow-sm" title="ห้องนี้ไม่ได้เรียนวิชานี้">
                                                        <AlertTriangle size={12} />
                                                    </div>
                                                )}
                                                {isMismatch && form.classroom_ids.includes(c.id) && (
                                                    <p className="text-[9px] text-amber-600 mt-0.5 font-normal">ไม่มีวิชานี้</p>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>

                        <div className="flex gap-3 pt-2">
                            <button type="button" onClick={() => { setIsPosting(false); setEditingMat(null); }} className="px-4 py-2 border border-input rounded-xl text-sm font-medium hover:bg-muted transition flex-1">ยกเลิก</button>
                            <button type="submit" disabled={uploading || form.classroom_ids.length === 0} className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition flex-[2] disabled:opacity-50 flex items-center justify-center gap-2">
                                {uploading ? <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" /> : (editingMat ? <Pencil size={18} /> : <Upload size={18} />)}
                                {uploading ? 'กำลังประมวลผล...' : (editingMat ? 'บันทึกการแก้ไข' : 'โพสต์เนื้อหา')}
                            </button>
                        </div>
                    </form>
                </div>
            )}

            <div className="space-y-4">
                {loading && (
                    <div className="flex flex-col items-center justify-center py-20 bg-muted/5 rounded-2xl border border-dashed border-border">
                        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4" />
                        <p className="text-sm text-muted-foreground font-medium">กำลังโหลดข้อมูล...</p>
                    </div>
                )}

                {materials
                    .filter(m => !filterSubject || m.subject_id === filterSubject)
                    .filter(m => !filterClassroom || m.classroom_ids.includes(filterClassroom))
                    .length === 0 && !loading && (
                    <div className="text-center py-16 bg-muted/20 border border-dashed border-border rounded-2xl">
                        <FileText size={48} className="mx-auto text-muted-foreground/30 mb-4" />
                        <h3 className="text-lg font-bold text-muted-foreground">ยังไม่มีเนื้อหาบทเรียน</h3>
                        <p className="text-sm text-muted-foreground mt-1">เริ่มต้นโพสต์เนื้อหาให้นักเรียนได้อ่าน</p>
                    </div>
                )}
                
                {materials
                    .filter(m => !filterSubject || m.subject_id === filterSubject)
                    .filter(m => !filterClassroom || m.classroom_ids.includes(filterClassroom))
                    .map(m => (
                    <div key={m.id} className="bg-card border border-border rounded-2xl p-5 shadow-sm transition hover:shadow-md">
                        <div className="flex items-start justify-between gap-4">
                             <div className="flex-1 min-w-0">
                                <h3 className="text-base font-bold text-foreground flex items-center gap-2">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${m.id === editingMat?.id ? 'bg-amber-500 text-white' : 'bg-blue-100 text-blue-600'}`}>
                                        <FileText size={16} />
                                    </div>
                                    <span className="truncate">{m.title}</span>
                                    {m.subject_id && (
                                        <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-bold">
                                            {subjects.find(s => s.id === m.subject_id)?.code || 'Subject'}
                                        </span>
                                    )}
                                    {m.id === editingMat?.id && <span className="text-[10px] bg-amber-500 text-white px-2 py-0.5 rounded-full font-bold animate-pulse">กำลังแก้ไข...</span>}
                                </h3>
                                <p className="text-xs text-muted-foreground mt-1 ml-10">
                                    {new Date(m.created_at).toLocaleString('th-TH')}
                                </p>
                            </div>
                            <div className="flex items-center gap-1">
                                <button onClick={() => handleReuse(m)} title="แก้ไขหรืออัพเดทเนื้อหา" className="text-primary hover:bg-primary/10 p-2 rounded-xl transition flex items-center gap-1 text-xs font-bold">
                                    <Pencil size={14} /> แก้ไข/อัพเดต
                                </button>
                                <button onClick={() => handleDelete(m.id)} className="text-muted-foreground hover:text-red-500 hover:bg-red-50 p-2 rounded-xl transition">
                                    <Trash2 size={16} />
                                </button>
                            </div>
                        </div>

                        <div className="mt-4 ml-10">
                            {m.content && (
                                <div className="text-sm bg-muted/30 p-4 rounded-xl mb-4 whitespace-pre-wrap">
                                    {m.content}
                                </div>
                            )}

                            {m.attachment_urls && m.attachment_urls.length > 0 && (
                                <div className="flex flex-wrap gap-2 mb-4">
                                    {m.attachment_urls.map((url, i) => {
                                        const filename = decodeURIComponent(url.split('/').pop().split('?')[0]);
                                        return (
                                            <a key={i} href={url} target="_blank" rel="noreferrer" 
                                                className="flex items-center gap-2 bg-background border border-border hover:border-primary/50 hover:bg-primary/5 px-3 py-2 rounded-xl text-xs font-medium transition group"
                                            >
                                                {getFileIcon(url)}
                                                <span className="truncate max-w-[200px] text-muted-foreground group-hover:text-foreground">{filename}</span>
                                            </a>
                                        );
                                    })}
                                </div>
                            )}

                            <div className="flex flex-wrap gap-1.5">
                                {m.classroom_ids.map(cid => {
                                    const cls = classrooms.find(c => c.id === cid);
                                    return cls ? (
                                        <span key={cid} className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">
                                            {cls.name}
                                        </span>
                                    ) : null;
                                })}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
