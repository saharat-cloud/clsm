import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/api/supabaseClient';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, CheckCircle, ChevronRight, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';
import { PageLoading } from '@/components/ui/LoadingSpinner';

export default function TeacherNotifications() {
    const { user } = useAuth();
    const { toast } = useToast();
    const [pendingSubmissions, setPendingSubmissions] = useState([]);
    const [assignmentsMap, setAssignmentsMap] = useState({});
    const [studentsMap, setStudentsMap] = useState({});
    const [classroomsMap, setClassroomsMap] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function load() {
            try {
                const [cls, stds, asgns, subs] = await Promise.all([
                    base44.entities.Classroom.filter({ teacher_id: user.id }),
                    base44.entities.Student.filter({ teacher_id: user.id }),
                    base44.entities.Assignment.filter({ teacher_id: user.id }),
                    base44.entities.Submission.filter({ teacher_id: user.id })
                ]);

                // Create lookups
                const cMap = Object.fromEntries(cls.map(c => [c.id, c]));
                const sMap = Object.fromEntries(stds.map(s => [s.student_id, s]));
                const aMap = Object.fromEntries(asgns.map(a => [a.id, a]));

                // For teacher, all classrooms the teacher created are relevant,
                // but since the current base44 schema is somewhat flat, we just filter by available assignments.
                // An assignment has a classroom_id. So we check if the classroom exists.

                const validSubs = subs.filter(sub => {
                    const a = aMap[sub.assignment_id];
                    const needsAction = sub.status === 'submitted' || sub.edit_request_status === 'pending';
                    return a && cMap[a.classroom_id] && needsAction;
                });

                // Sort newest first
                validSubs.sort((a, b) => new Date(b.created_at || b.created_date || 0).getTime() - new Date(a.created_at || a.created_date || 0).getTime());

                setClassroomsMap(cMap);
                setStudentsMap(sMap);
                setAssignmentsMap(aMap);
                setPendingSubmissions(validSubs);
            } catch (err) {
                console.error("Error loading notifications:", err);
            } finally {
                setLoading(false);
            }
        }
        load();

        // Realtime: listen for new submissions and edit requests
        const channel = supabase
            .channel(`teacher-notif-submissions-${user.id}`)
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'submissions', filter: `teacher_id=eq.${user.id}` }, async (payload) => {
                const sub = payload.new;
                // Fetch assignment to validate it belongs to a known classroom
                try {
                    const [asgns, stds, cls] = await Promise.all([
                        base44.entities.Assignment.filter({ teacher_id: user.id }),
                        base44.entities.Student.filter({ teacher_id: user.id }),
                        base44.entities.Classroom.filter({ teacher_id: user.id }),
                    ]);
                    const aMap = Object.fromEntries(asgns.map(a => [a.id, a]));
                    const sMap = Object.fromEntries(stds.map(s => [s.student_id, s]));
                    const cMap = Object.fromEntries(cls.map(c => [c.id, c]));
                    const a = aMap[sub.assignment_id];
                    if (a && cMap[a.classroom_id]) {
                        setAssignmentsMap(prev => ({ ...prev, ...aMap }));
                        setStudentsMap(prev => ({ ...prev, ...sMap }));
                        setClassroomsMap(prev => ({ ...prev, ...cMap }));
                        setPendingSubmissions(prev => {
                            if (prev.find(s => s.id === sub.id)) return prev;
                            return [sub, ...prev];
                        });
                    }
                } catch { /* ignore */ }
            })
            .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'submissions', filter: `teacher_id=eq.${user.id}` }, async (payload) => {
                const updated = payload.new;
                const old = payload.old;
                
                const isNewEditReq = updated.edit_request_status === 'pending' && old?.edit_request_status !== 'pending';
                const isResubmission = updated.status === 'submitted' && old?.status !== 'submitted';
                
                if (isNewEditReq || isResubmission) {
                    // Try to load related metadata if we don't have it
                    if (!assignmentsMap[updated.assignment_id]) {
                        try {
                            const [asgns, stds, cls] = await Promise.all([
                                base44.entities.Assignment.filter({ teacher_id: user.id }),
                                base44.entities.Student.filter({ teacher_id: user.id }),
                                base44.entities.Classroom.filter({ teacher_id: user.id }),
                            ]);
                            setAssignmentsMap(Object.fromEntries(asgns.map(a => [a.id, a])));
                            setStudentsMap(Object.fromEntries(stds.map(s => [s.student_id, s])));
                            setClassroomsMap(Object.fromEntries(cls.map(c => [c.id, c])));
                        } catch { /* ignore */ }
                    }
                    
                    setPendingSubmissions(prev => {
                        const existing = prev.find(s => s.id === updated.id);
                        if (existing) return prev.map(s => s.id === updated.id ? { ...s, ...updated } : s);
                        return [updated, ...prev];
                    });
                }
            })
            .subscribe();

        return () => { supabase.removeChannel(channel); };
    }, []);

    const handleApproveEdit = async (e, sub) => {
        e.preventDefault();
        try {
            const asgn = assignmentsMap[sub.assignment_id];
            await base44.entities.Submission.update(sub.id, { edit_request_status: 'approved' });
            // Notify student in realtime
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: sub.student_id,
                title: '✅ ครูอนุมัติให้แก้ไขงาน',
                message: `งาน "${asgn?.title || ''}" ได้รับการอนุมัติให้แก้ไขแล้ว กรุณาส่งงานใหม่`,
                type: 'edit_approved',
                is_read: false,
            });
            setPendingSubmissions(prev => prev.filter(s => s.id !== sub.id));
            toast({ title: 'อนุมัติการแก้ไขงานแล้ว' });
        } catch (error) {
            toast({ title: 'เกิดข้อผิดพลาด', description: error.message, variant: 'destructive' });
        }
    };

    const handleRejectEdit = async (e, sub) => {
        e.preventDefault();
        try {
            const asgn = assignmentsMap[sub.assignment_id];
            await base44.entities.Submission.update(sub.id, { edit_request_status: 'rejected' });
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: sub.student_id,
                title: '❌ ครูปฏิเสธการแก้ไขงาน',
                message: `คำขอแก้ไขงาน "${asgn?.title || ''}" ถูกปฏิเสธ`,
                type: 'edit_rejected',
                is_read: false,
            });
            setPendingSubmissions(prev => prev.filter(s => s.id !== sub.id));
            toast({ title: 'ปฏิเสธการแก้ไขงานแล้ว' });
        } catch (error) {
            toast({ title: 'เกิดข้อผิดพลาด', description: error.message, variant: 'destructive' });
        }
    };

    if (loading) {
        return (
            <div className="fixed inset-0 flex items-center justify-center bg-background">
                <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin"></div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-2xl mx-auto px-4 py-8">
                <div className="flex items-center gap-3 mb-6">
                    <Link to="/teacher" className="text-muted-foreground hover:text-foreground"><ArrowLeft size={20} /></Link>
                    <h1 className="text-2xl font-bold">แจ้งเตือน (รอตรวจ)</h1>
                    {pendingSubmissions.length > 0 && (
                        <span className="bg-destructive text-destructive-foreground text-xs font-bold px-2 py-0.5 rounded-full">
                            {pendingSubmissions.length}
                        </span>
                    )}
                </div>

                <div className="grid gap-3">
                    {pendingSubmissions.map(sub => {
                        const asgn = assignmentsMap[sub.assignment_id];
                        const std = studentsMap[sub.student_id];
                        const cls = classroomsMap[asgn?.classroom_id];

                        if (!asgn || !std || !cls) return null;

                        const isEditRequest = sub.edit_request_status === 'pending';
                        
                        return (
                            <Link key={sub.id} to={`/teacher/assignments/${asgn.id}`}
                                className={`group p-4 rounded-2xl border ${isEditRequest ? 'border-amber-500/30 bg-amber-50/30 hover:bg-amber-50/50 hover:border-amber-500/50' : 'border-primary/20 bg-accent/20 hover:bg-accent/40 hover:border-primary/40'} transition flex flex-col sm:flex-row items-start gap-4 cursor-pointer relative overflow-hidden`}>
                                <div className={`absolute top-0 left-0 w-1 h-full ${isEditRequest ? 'bg-amber-500' : 'bg-primary'}`} />
                                <div className={`w-10 h-10 rounded-full ${isEditRequest ? 'bg-amber-500/10 text-amber-600' : 'bg-primary/10 text-primary'} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                                    <Clock size={18} />
                                </div>
                                <div className="flex-1 min-w-0 w-full">
                                    <div className="flex items-center gap-2 mb-1">
                                        <p className="font-semibold text-foreground text-sm truncate">{std.first_name} {std.last_name}</p>
                                        <span className="text-xs text-muted-foreground font-mono">{std.student_id}</span>
                                        <span className="text-[10px] bg-muted px-2 py-0.5 rounded-full truncate">{cls.name}</span>
                                    </div>
                                    <p className="text-sm text-muted-foreground">
                                        {isEditRequest ? (
                                            <>ขออนุมัติแก้ไขงาน <span className="text-foreground font-medium">"{asgn.title}"</span></>
                                        ) : (
                                            <>ส่งงาน <span className="text-foreground font-medium">"{asgn.title}"</span> แล้ว</>
                                        )}
                                    </p>
                                    <div className="flex items-center gap-3 mt-2">
                                        <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                            {new Date(sub.updated_at || sub.created_date || sub.created_at).toLocaleString('th-TH')}
                                        </span>
                                        <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${isEditRequest ? 'text-amber-600 bg-amber-50 border-amber-200' : 'text-orange-500 bg-orange-50 border-orange-100'}`}>
                                            {isEditRequest ? 'รอการอนุมัติ' : 'รอการตรวจ'}
                                        </span>
                                    </div>
                                    {isEditRequest && (
                                        <div className="flex items-center gap-2 mt-3" onClick={e => e.preventDefault()}>
                                            <button onClick={(e) => handleApproveEdit(e, sub)} className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-medium transition">
                                                อนุมัติการแก้ไข
                                            </button>
                                            <button onClick={(e) => handleRejectEdit(e, sub)} className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition">
                                                ไม่อนุมัติ
                                            </button>
                                        </div>
                                    )}
                                </div>
                                {!isEditRequest && (
                                    <div className="text-muted-foreground group-hover:text-primary transition h-full flex items-center pt-2 self-center sm:self-start">
                                        <ChevronRight size={20} />
                                    </div>
                                )}
                            </Link>
                        );
                    })}
                    {pendingSubmissions.length === 0 && (
                        <div className="text-center py-16 text-muted-foreground bg-card rounded-2xl border border-border">
                            <CheckCircle size={40} className="mx-auto mb-3 text-green-500/50" />
                            <p className="font-medium">ตรวจงานครบหมดแล้ว!</p>
                            <p className="text-sm mt-1 opacity-70">ไม่มีงานที่รอการตรวจในขณะนี้</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
