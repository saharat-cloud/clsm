import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { ArrowLeft, Upload, Check, User, ShieldCheck } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { alerts } from '@/utils/alerts';
import StudentAvatar from '@/components/ui/StudentAvatar';
import { GRADIENT_PRESETS, ANIMATION_PRESETS } from '@/utils/customizationPresets';
import { useAuth } from '@/lib/AuthContext';

export default function TeacherProfile() {
    const { user, updateUser } = useAuth();
    const navigate = useNavigate();
    const { toast } = useToast();
    const [teacher, setTeacher] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        load();
    }, []);

    async function load() {
        if (!user) return;
        try {
            const [fresh] = await base44.entities.Teacher.filter({ id: user.id });
            if (fresh) {
                setTeacher(fresh);
            }
        } catch (err) {
            console.error('Failed to load teacher:', err);
            setTeacher(user);
        }
    }

    async function handleAvatarUpload(e) {
        const file = e.target.files[0];
        if (!file) return;

        if (file.size > 800 * 1024) {
            alerts.error('ไฟล์มีขนาดใหญ่เกินไป', 'กรุณาอัปโหลดรูปภาพขนาดไม่เกิน 800KB');
            return;
        }

        setUploading(true);
        try {
            const ext = file.name.split('.').pop() || '';
            const fileName = `teacher_avatar_${Date.now()}.${ext}`;
            const filePath = `avatars/${fileName}`;

            const { error: uploadError } = await supabase.storage
                .from('rewards') 
                .upload(filePath, file);

            if (uploadError) throw uploadError;

            const { data } = supabase.storage.from('rewards').getPublicUrl(filePath);
            const avatar_url = data.publicUrl;

            const updated = await base44.entities.Teacher.update(teacher.id, { avatar_url });
            setTeacher(updated);
            updateUser(updated);
            toast({ title: 'อัปเดตรูปโปรไฟล์แล้ว' });
        } catch (err) {
            console.error(err);
            alerts.error('เกิดข้อผิดพลาดในการอัปโหลด');
        } finally {
            setUploading(false);
        }
    }

    async function updateProfile(data) {
        setSaving(true);
        try {
            const updated = await base44.entities.Teacher.update(teacher.id, data);
            setTeacher(updated);
            updateUser(updated);
            toast({ title: 'บันทึกการเปลี่ยนแปลงแล้ว' });
        } catch (err) {
            console.error(err);
            alerts.error('บันทึกไม่สำเร็จ');
        } finally {
            setSaving(false);
        }
    }

    if (!teacher) return (
        <div className="flex items-center justify-center min-h-[400px]">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
    );

    return (
        <div className="min-h-screen bg-background pb-12">
            <div className="max-w-4xl mx-auto px-4 py-8">
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-3">
                        <Link to="/teacher" className="p-2 rounded-full hover:bg-muted transition text-muted-foreground hover:text-foreground">
                            <ArrowLeft size={20} />
                        </Link>
                        <div>
                            <h1 className="text-2xl font-bold tracking-tight">จัดการโปรไฟล์ครู</h1>
                            <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <ShieldCheck size={14} className="text-primary" /> สิทธิ์ผู้ดูแลระบบ
                            </p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Preview Sidebar */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="sticky top-8 space-y-6">
                            <div className="bg-card border border-border rounded-3xl p-8 flex flex-col items-center text-center shadow-xl relative overflow-hidden group">
                                <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
                                
                                <div className="relative mb-6">
                                    <StudentAvatar student={teacher} size={120} showTitle={true} />
                                    <label className="absolute bottom-2 right-2 bg-primary text-primary-foreground p-2.5 rounded-full shadow-lg cursor-pointer hover:scale-110 active:scale-95 transition-all z-20 ring-4 ring-card">
                                        <Upload size={18} />
                                        <input type="file" className="hidden" accept="image/*" onChange={handleAvatarUpload} disabled={uploading} />
                                    </label>
                                    {uploading && (
                                        <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center z-10">
                                            <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin" />
                                        </div>
                                    )}
                                </div>

                                <div className="space-y-1">
                                    <h2 className={`text-2xl font-black student-name-${teacher.id}`}>
                                        {teacher.first_name} {teacher.last_name}
                                    </h2>
                                    <p className="text-xs font-mono text-muted-foreground bg-muted px-2 py-1 rounded inline-block mt-2 tracking-widest uppercase">
                                        ID: {teacher.username || teacher.id}
                                    </p>
                                </div>
                            </div>

                            <div className="bg-primary/5 border border-primary/10 rounded-2xl p-4 text-xs text-primary leading-relaxed">
                                💡 <strong>คำแนะนำ:</strong> การตั้งค่าโปรไฟล์นี้จะแสดงผลในทุกที่ที่ชื่อครูปรากฏ เช่น ในหน้าเนื้อหาบทเรียน งานมอบหมาย และการแจ้งเตือนถึงนักเรียน
                            </div>
                        </div>
                    </div>

                    {/* Editor Main Area */}
                    <div className="lg:col-span-2 space-y-10">
                        {/* Name & Title Editor */}
                        <section className="bg-card border border-border rounded-3xl p-6 shadow-sm">
                            <h3 className="text-sm font-black uppercase tracking-widest text-muted-foreground mb-6 flex items-center gap-2">
                                <div className="w-1.5 h-4 bg-primary rounded-full" /> ข้อมูลทั่วไป
                            </h3>
                            <div className="grid gap-5">
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-xs font-bold mb-1.5 block">ชื่อ</label>
                                        <input 
                                            value={teacher.first_name} 
                                            onChange={e => setTeacher({...teacher, first_name: e.target.value})}
                                            onBlur={() => updateProfile({ first_name: teacher.first_name })}
                                            className="w-full bg-muted/30 border border-border rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition" 
                                        />
                                    </div>
                                    <div>
                                        <label className="text-xs font-bold mb-1.5 block">นามสกุล</label>
                                        <input 
                                            value={teacher.last_name} 
                                            onChange={e => setTeacher({...teacher, last_name: e.target.value})}
                                            onBlur={() => updateProfile({ last_name: teacher.last_name })}
                                            className="w-full bg-muted/30 border border-border rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition" 
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="text-xs font-bold mb-1.5 block">ฉายา/ตำแหน่ง (Title)</label>
                                    <input 
                                        value={teacher.title}
                                        onChange={e => setTeacher({...teacher, title: e.target.value})}
                                        onBlur={() => updateProfile({ title: teacher.title })}
                                        placeholder="เช่น ครูประจำวิชา, Master Coder"
                                        className="w-full bg-muted/30 border border-border rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition" 
                                    />
                                </div>
                            </div>
                        </section>

                        {/* Animated Frames */}
                        <section className="bg-card border border-border rounded-3xl p-6 shadow-sm">
                            <h3 className="text-sm font-black uppercase tracking-widest text-muted-foreground mb-6 flex items-center gap-2">
                                <div className="w-1.5 h-4 bg-primary rounded-full" /> กรอบโปรไฟล์แอนิเมชั่น
                            </h3>
                            <div className="grid grid-cols-3 sm:grid-cols-5 gap-4">
                                <button onClick={() => updateProfile({ profile_frame: '' })}
                                    className={`aspect-square rounded-2xl border-2 flex flex-col items-center justify-center gap-1 transition-all ${!teacher.profile_frame ? 'bg-primary/5 border-primary text-primary shadow-inner' : 'bg-background border-border hover:border-muted-foreground/30 text-muted-foreground'}`}>
                                    <User size={28} className="opacity-30" />
                                    <span className="text-[10px] font-bold">ดั้งเดิม</span>
                                    {!teacher.profile_frame && <Check size={14} className="mt-1 bg-primary text-white rounded-full p-0.5" />}
                                </button>
                                {ANIMATION_PRESETS.map((f) => (
                                    <button 
                                        key={f.id} 
                                        onClick={() => updateProfile({ profile_frame: `animated:${f.id}` })}
                                        className={`relative aspect-square rounded-2xl border-2 overflow-hidden flex flex-col items-center justify-center gap-1 transition-all group ${teacher.profile_frame === `animated:${f.id}` ? 'border-primary ring-4 ring-primary/10 bg-primary/5' : 'border-border bg-background hover:bg-muted'}`}
                                    >
                                        <div className="text-2xl group-hover:scale-110 transition-transform">{f.icon}</div>
                                        <span className={`text-[9px] font-bold px-1 text-center truncate w-full ${teacher.profile_frame === `animated:${f.id}` ? 'text-primary' : 'text-muted-foreground'}`}>
                                            {f.name}
                                        </span>
                                        {teacher.profile_frame === `animated:${f.id}` && (
                                            <div className="absolute top-1 right-1 bg-primary text-white rounded-full p-0.5 shadow-md">
                                                <Check size={12} />
                                            </div>
                                        )}
                                    </button>
                                ))}
                            </div>
                        </section>

                        {/* Name Backgrounds */}
                        <section className="bg-card border border-border rounded-3xl p-6 shadow-sm">
                            <h3 className="text-sm font-black uppercase tracking-widest text-muted-foreground mb-6 flex items-center gap-2">
                                <div className="w-1.5 h-4 bg-primary rounded-full" /> สีพื้นหลังชื่อ (Gradients)
                            </h3>
                            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-3">
                                <button onClick={() => updateProfile({ name_bg_color: '' })}
                                    className={`aspect-square rounded-xl border-2 transition-all flex flex-col items-center justify-center gap-1 ${!teacher.name_bg_color ? 'border-primary bg-primary/5 text-primary shadow-inner' : 'border-border bg-background hover:border-muted-foreground/30 text-muted-foreground'}`}>
                                    <div className="w-5 h-5 rounded-full border border-dashed border-muted-foreground/40" />
                                    <span className="text-[9px] font-bold">เดิม</span>
                                </button>
                                {GRADIENT_PRESETS.map((g, idx) => (
                                    <button 
                                        key={idx} 
                                        onClick={() => updateProfile({ name_bg_color: g.value })}
                                        className={`relative aspect-square rounded-xl border-2 transition-all hover:scale-110 shadow-sm ${teacher.name_bg_color === g.value ? 'border-primary ring-4 ring-primary/10 scale-105' : 'border-white dark:border-zinc-800'}`}
                                        style={{ background: g.value }}
                                        title={g.name}
                                    >
                                        {teacher.name_bg_color === g.value && (
                                            <div className="absolute inset-0 flex items-center justify-center bg-black/10">
                                                <Check size={18} className="text-white drop-shadow-md" />
                                            </div>
                                        )}
                                    </button>
                                ))}
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            
            {saving && (
                <div className="fixed bottom-8 right-8 bg-zinc-900 dark:bg-zinc-100 text-zinc-100 dark:text-zinc-900 px-6 py-3 rounded-2xl text-sm font-bold shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-right-4">
                    <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    กำลังบันทึกการเปลี่ยนแปลง...
                </div>
            )}
        </div>
    );
}
