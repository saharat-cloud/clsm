import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { supabase } from '@/api/supabaseClient';
import { alerts } from '@/utils/alerts';
import { Bug, Skull, ShieldPlus, Activity, ShieldAlert, HeartPulse, X, ChevronDown, Layers, Users, FlaskConical, Heart, Check, Thermometer } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { useSemester } from '@/lib/SemesterContext';
import VirusTheme from '@/components/ui/VirusTheme';

export default function VirusDashboard() {
    const { user } = useAuth();
    const { activeSemester } = useSemester();
    const [classrooms, setClassrooms] = useState([]);
    const [activeClassroom, setActiveClassroom] = useState('');
    const [students, setStudents] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [infections, setInfections] = useState([]);
    const [loading, setLoading] = useState(true);

    const [infectModal, setInfectModal] = useState({ show: false, student: null });
    const [spreadModal, setSpreadModal] = useState({ show: false, sourceInfection: null, sourceStudent: null });
    const [selectedVictims, setSelectedVictims] = useState([]);
    const [form, setForm] = useState({
        assignment_id: '',
        spread_count: 1,
        penalty_type: 'points',
        penalty_amount: 10,
        reward_type: 'points',
        reward_amount: 5
    });
    const [submissions, setSubmissions] = useState([]);
    const [itemRequests, setItemRequests] = useState([]);
    const [allStudentItems, setAllStudentItems] = useState([]);
    const [stats, setStats] = useState({ infected: 0, pendingRequests: 0, totalAntivirus: 0 });
    const [refreshKey, setRefreshKey] = useState(0);

    useEffect(() => {
        loadBaseData();
    }, [activeSemester]);

    async function loadBaseData() {
        if (!user) return;
        setLoading(true);
        try {
            const cls = await base44.entities.Classroom.filter({ teacher_id: user.id });
            let filteredCls = cls;
            if (activeSemester) {
                filteredCls = cls.filter(c => c.semester_academic_year === activeSemester.academic_year && c.semester_number === activeSemester.semester);
            }
            setClassrooms(filteredCls.sort((a,b)=>a.name.localeCompare(b.name)));
            if (filteredCls.length > 0) setActiveClassroom(filteredCls[0].id);
        } catch (err) {
            console.error(err);
            if (err.message?.includes('relation "classrooms" does not exist')) {
                alerts.error('ไม่พบข้อมูลชั้นเรียน', 'กรุณาสร้างตารางข้อมูลใน Database ก่อนใช้งาน');
            }
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        if (!activeClassroom) return;
        if (!activeClassroom) return;
        
        loadClassroomData();

        // Realtime subscription for infections and item requests
        console.log('Joining Virus Dashboard Channel for classroom:', activeClassroom);
        const channel = supabase.channel(`virus_dashboard_${activeClassroom}`)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'infections', filter: `teacher_id=eq.${user.id}` }, (payload) => {
                console.log('Realtime infection change detected:', payload);
                setRefreshKey(prev => prev + 1);
                
                const eventType = payload.eventType;
                const newData = payload.new;

                if (eventType === 'INSERT' && (newData?.is_active)) {
                    base44.entities.Student.filter({ student_id: newData.student_id, teacher_id: user.id }).then(res => {
                        const name = res[0]?.first_name || newData.student_id;
                        alerts.info('🚀 ตรวจพบการติดเชื้อใหม่!', `${name} ติดเชื้อไวรัสตัวใหม่แล้ว`);
                    });
                } else if (eventType === 'UPDATE' && newData?.is_active === false) {
                    base44.entities.Student.filter({ student_id: newData.student_id, teacher_id: user.id }).then(res => {
                        const name = res[0]?.first_name || newData.student_id;
                        alerts.success('💉 นักเรียนรักษาหายแล้ว!', `${name} ได้รับการรักษาสิ่งปนเปื้อนเรียบร้อย`);
                    });
                }
            })
            .on('postgres_changes', { event: '*', schema: 'public', table: 'item_requests', filter: `teacher_id=eq.${user.id}` }, (payload) => {
                console.log('Realtime item_request change detected:', payload);
                setRefreshKey(prev => prev + 1);
            })
            .on('postgres_changes', { event: '*', schema: 'public', table: 'student_items', filter: `teacher_id=eq.${user.id}` }, (payload) => {
                console.log('Realtime student_items change detected:', payload);
                setRefreshKey(prev => prev + 1);
            })
            .subscribe((status) => {
                console.log(`Virus Dashboard Channel status: ${status}`);
            });

        return () => { 
            console.log('Leaving Virus Dashboard Channel');
            supabase.removeChannel(channel); 
        };
    }, [activeClassroom, refreshKey]);

    async function loadClassroomData(showLoading = true) {
        if (showLoading) setLoading(true);
        try {
            const cls = classrooms.find(c => c.id === activeClassroom);
            const studentIds = cls?.student_ids || [];

            const [allStds, allAsgns, allInfs, allSubs, allReqs] = await Promise.all([
                base44.entities.Student.filter({ teacher_id: user.id }),
                base44.entities.Assignment.filter({ classroom_id: activeClassroom, teacher_id: user.id }),
                base44.entities.Infection.filter({ classroom_id: activeClassroom, teacher_id: user.id }),
                base44.entities.Submission.filter({ classroom_id: activeClassroom, teacher_id: user.id }),
                base44.entities.ItemRequest.filter({ classroom_id: activeClassroom, teacher_id: user.id })
            ]);

            setStudents(allStds.filter(s => studentIds.includes(s.id)).sort((a,b)=>a.student_id.localeCompare(b.student_id)));
            setAssignments(allAsgns);
            setInfections(allInfs);
            setSubmissions(allSubs);
            setItemRequests(allReqs.filter(r => r.status === 'pending'));
            
            // Get Antivirus inventory for the classroom
            const { data: antivirusData } = await supabase
                .from('student_items')
                .select('*')
                .eq('item_type', 'antivirus')
                .eq('teacher_id', user.id)
                .gt('quantity', 0);

            setAllStudentItems(antivirusData || []);
            
            setStats({
                infected: allInfs.filter(i => i.is_active).length,
                pendingRequests: allReqs.filter(r => r.status === 'pending').length,
                totalAntivirus: (antivirusData || []).reduce((acc, curr) => {
                    const student = allStds.find(s => s.student_id === curr.student_id);
                    return student && studentIds.includes(student.id) ? acc + curr.quantity : acc;
                }, 0)
            });
        } catch (err) {
            console.error(err);
            if (err.message?.includes('does not exist')) {
                alerts.error('ไม่พบตารางข้อมูล', 'กรุณารัน SQL Setup ที่เตรียมไว้ให้ใน Supabase');
            } else {
                alerts.error('โหลดข้อมูลผิดพลาด', err.message);
            }
        } finally {
            if (showLoading) setLoading(false);
        }
    }

    function openInfectModal(student) {
        setInfectModal({ show: true, student });
        setForm({ assignment_id: '', spread_count: 1, penalty_type: 'points', penalty_amount: 10, reward_type: 'points', reward_amount: 5 });
    }

    async function handleInfect(e) {
        e.preventDefault();
        if (!form.assignment_id) return alerts.error('กรุณาเลือกงานที่ต้องทำ');
        
        try {
            await base44.entities.Infection.create({
                teacher_id: user.id,
                student_id: infectModal.student.student_id,
                classroom_id: activeClassroom,
                assignment_id: form.assignment_id,
                spread_count: Number(form.spread_count),
                penalty_type: form.penalty_type,
                penalty_amount: Number(form.penalty_amount),
                reward_type: form.reward_type,
                reward_amount: Number(form.reward_amount),
                is_active: true
            });
            
            // Send notification to student
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: infectModal.student.student_id,
                title: '☣️ คุณติดไวรัส!',
                message: `รีบเคลียร์งานที่กำหนดด่วน ก่อนที่ไวรัสจะแพร่และโดนหักคะแนน!`,
                type: 'virus_infected',
                is_read: false
            });

            alerts.success('ปล่อยไวรัสสำเร็จ!');
            setInfectModal({ show: false, student: null });
            loadClassroomData(false);
        } catch(err) {
            alerts.error('ผิดพลาด', err.message);
        }
    }

    async function handleCure(infectionId, studentId) {
        if (!await alerts.confirm('รักษานักเรียน', 'ยืนยันการใช้ยารักษาไวรัสให้นักเรียนคนนี้ใช่หรือไม่?')) return;
        try {
            await base44.entities.Infection.update(infectionId, { is_active: false, cured_at: new Date().toISOString() });
            
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: studentId,
                title: '💉 คุณได้รับการรักษาแล้ว',
                message: `ครูได้รักษาไวรัสให้คุณแล้ว (ไม่ได้รับรางวัลจากการรักษาโดยตรง)`,
                type: 'virus_cured',
                is_read: false
            });

            alerts.success('รักษาสำเร็จ!');
            loadClassroomData(false);
        } catch(err) {
            alerts.error('ผิดพลาด', err.message);
        }
    }

    // Determine student status
    const studentStatus = students.map(s => {
        const infs = infections.filter(i => i.student_id === s.student_id);
        const activeInf = infs.find(i => i.is_active);
        
        let isSubmitted = false;
        if (activeInf) {
            isSubmitted = submissions.some(sub => sub.student_id === s.student_id && sub.assignment_id === activeInf.assignment_id);
        }
        
        const items = allStudentItems.filter(i => i.student_id === s.student_id);
        const antivirusCount = items.reduce((acc, curr) => acc + curr.quantity, 0);
        
        return { ...s, activeInfection: activeInf, historyCount: infs.length, isSubmitted, antivirusCount };
    });

    async function handleSpread(e) {
        e.preventDefault();
        const { sourceInfection, sourceStudent } = spreadModal;
        if (selectedVictims.length === 0) return alerts.error('กรุณาเลือกเหยื่อที่จะแพร่เชื้อไปหา');

        try {
            // 1. Apply penalty to source student
            if (sourceInfection.penalty_type === 'points') {
                const [std] = await base44.entities.Student.filter({ student_id: sourceStudent.student_id });
                if (std) {
                    await base44.entities.PointTransaction.create({
                        teacher_id: user.id,
                        student_id: sourceStudent.student_id,
                        points: -sourceInfection.penalty_amount,
                        reason: `ไวรัสกำเริบ: ไม่ส่งงาน ${assignments.find(a=>a.id === sourceInfection.assignment_id)?.title || ''}`
                    });
                }
            } else {
                // Score penalty (deduct from ScoreRecord)
                await base44.entities.ScoreRecord.create({
                    teacher_id: user.id,
                    student_id: sourceStudent.student_id,
                    classroom_id: activeClassroom,
                    subject_id: assignments.find(a=>a.id === sourceInfection.assignment_id)?.subject_id || null,
                    score: -sourceInfection.penalty_amount,
                    max_score: 0,
                    score_type: 'บทลงโทษไวรัส',
                    note: `ไม่ส่งงานตามกำหนด`
                });
            }

            // 2. Infect victims
            await Promise.all(selectedVictims.map(vId => 
                base44.entities.Infection.create({
                    teacher_id: user.id,
                    student_id: vId,
                    classroom_id: activeClassroom,
                    assignment_id: sourceInfection.assignment_id,
                    spread_count: sourceInfection.spread_count,
                    penalty_type: sourceInfection.penalty_type,
                    penalty_amount: sourceInfection.penalty_amount,
                    is_active: true
                })
            ));

            // 3. Deactivate source infection
            await base44.entities.Infection.update(sourceInfection.id, { is_active: false });

            // 4. Notifications
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: sourceStudent.student_id,
                title: '☣️ ไวรัสระเบิดตัว!',
                message: `คุณไม่สามารถกำจัดไวรัสได้ทันเวลา จึงถูกลงโทษและแพร่เชื้อต่อ`,
                type: 'virus_spread_source',
                is_read: false
            });

            await Promise.all(selectedVictims.map(vId => 
                base44.entities.Notification.create({
                    teacher_id: user.id,
                    student_id: vId,
                    title: '☣️ ติดเชื้อจากเพื่อน!',
                    message: `ไวรัสจาก ${sourceStudent.first_name} ได้แพร่มาถึงคุณแล้ว!`,
                    type: 'virus_infected',
                    is_read: false
                })
            ));

            alerts.success('แพร่เชื้อสำเร็จ! บทลงโทษถูกบังคับใช้แล้ว');
            setSpreadModal({ show: false, sourceInfection: null, sourceStudent: null });
            setSelectedVictims([]);
            loadClassroomData(false);
        } catch(err) {
            alerts.error('ผิดพลาด', err.message);
        }
    }

    async function handleApproveRequest(req) {
        if (!await alerts.confirm('อนุมัติยารักษา', `คุณต้องการจัดส่งยาต้านไวรัสให้ ${students.find(s=>s.student_id === (req.requester_id || req.student_id))?.first_name || 'นักเรียน'} ใช่หรือไม่?`)) return;
        
        try {
            const studentTextId = req.requester_id || req.student_id;
            
            // 1. Give item to student
            const existingItems = await base44.entities.StudentItem.filter({ student_id: studentTextId, item_type: 'antivirus', teacher_id: user.id });
            if (existingItems.length > 0) {
                await base44.entities.StudentItem.update(existingItems[0].id, { quantity: existingItems[0].quantity + 1 });
            } else {
                await base44.entities.StudentItem.create({
                    teacher_id: user.id,
                    student_id: studentTextId,
                    item_type: 'antivirus',
                    quantity: 1
                });
            }

            // 2. Update request status
            await base44.entities.ItemRequest.update(req.id, { status: 'fulfilled', helper_id: 'teacher' });

            // 3. Notify student
            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: studentTextId,
                title: '🧪 ยาจากเข็มครูส่งถึงแล้ว!',
                message: `ครูได้อนุมัติยาต้านไวรัสให้คุณแล้ว รีบเข้าไปใช้ในกระเป๋าไอเทมนะ!`,
                type: 'request_approved',
                is_read: false
            });

            alerts.success('ส่งยาให้เรียบร้อยแล้ว!');
            loadClassroomData(false);
        } catch(err) {
            alerts.error('ผิดพลาด', err.message);
        }
    }

    async function handleGiftItem(student) {
        if (!await alerts.confirm('มอบยาพิเศษ', `ส่งมอบยาต้านไวรัสให้ ${student.first_name} โดยตรง 1 กล่อง?`)) return;

        try {
            const existingItems = await base44.entities.StudentItem.filter({ student_id: student.student_id, item_type: 'antivirus', teacher_id: user.id });
            if (existingItems.length > 0) {
                await base44.entities.StudentItem.update(existingItems[0].id, { quantity: existingItems[0].quantity + 1 });
            } else {
                await base44.entities.StudentItem.create({
                    teacher_id: user.id,
                    student_id: student.student_id,
                    item_type: 'antivirus',
                    quantity: 1
                });
            }

            await base44.entities.Notification.create({
                teacher_id: user.id,
                student_id: student.student_id,
                title: '🎁 ของขวัญพิเศษจากแล็บ!',
                message: `ครูได้มอบยาต้านไวรัสให้คุณเป็นกรณีพิเศษ!`,
                type: 'item_received',
                is_read: false
            });

            alerts.success('มอบยาสำเร็จ!');
            loadClassroomData(false);
        } catch(err) {
            alerts.error('ผิดพลาด', err.message);
        }
    }

    // Remove the second definition of studentStatus that was here


    return (
        <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6">
            <VirusTheme active={true} />
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-black text-white p-6 rounded-3xl shadow-lg relative overflow-hidden border border-green-500/30">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(34,197,94,0.15),transparent_50%)] animate-pulse" />
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
                
                <div className="relative z-10 flex items-center gap-4">
                    <div className="w-14 h-14 bg-green-500/20 text-green-400 rounded-2xl flex items-center justify-center border border-green-500/50 shadow-[0_0_15px_rgba(34,197,94,0.4)]">
                        <Bug size={32} />
                    </div>
                    <div>
                        <h1 className="text-2xl font-black tracking-wider text-green-400 drop-shadow-[0_0_5px_rgba(34,197,94,0.8)] uppercase">ห้องทดลองไวรัส</h1>
                        <p className="text-sm text-green-500/80 font-medium">ระบบควบคุมและแพร่กระจายเชื้อ</p>
                    </div>
                </div>
                
                <div className="relative z-10 flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
                    {classrooms.length > 0 ? (
                        <select 
                            value={activeClassroom} onChange={(e) => setActiveClassroom(e.target.value)}
                            className="bg-zinc-900 border border-green-500/30 text-green-400 text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-green-400 focus:ring-1 focus:ring-green-400 w-full md:w-64 font-medium"
                        >
                            {classrooms.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    ) : (
                        <span className="text-amber-500 text-sm italic">⚠️ ไม่มีห้องเรียนในปีการศึกษานี้</span>
                    )}
                </div>
            </div>

            {loading ? (
                <div className="flex flex-col items-center justify-center py-20">
                    <div className="w-12 h-12 border-4 border-green-500/20 border-t-green-500 rounded-full animate-spin"></div>
                    <p className="mt-4 text-green-500 font-bold animate-pulse">กำลังวิจัยไวรัส...</p>
                </div>
            ) : classrooms.length === 0 ? (
                <div className="text-center py-20 bg-zinc-900/50 rounded-3xl border border-dashed border-zinc-800">
                    <Layers size={48} className="mx-auto text-zinc-700 mb-4 opacity-50" />
                    <h3 className="text-lg font-bold text-zinc-500">ไม่พบห้องเรียน</h3>
                    <p className="text-sm text-zinc-600 mt-1">กรุณาเลือกปีการศึกษาอื่น หรือเพิ่มห้องเรียนก่อน</p>
                </div>
            ) : students.length === 0 ? (
                <div className="text-center py-20 bg-zinc-900/50 rounded-3xl border border-dashed border-zinc-800">
                    <Users size={48} className="mx-auto text-zinc-700 mb-4 opacity-50" />
                    <h3 className="text-lg font-bold text-zinc-500">ไม่พบนักเรียน</h3>
                    <p className="text-sm text-zinc-600 mt-1">ห้องเรียนนี้ยังไม่มีชื่อนักเรียน</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                    {/* Left: Stats & Medicine Requests */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="bg-zinc-950 border border-green-500/20 rounded-[2rem] p-6 relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/5 rounded-bl-full -mr-10 -mt-10 pointer-events-none" />
                            <h3 className="text-xs font-black text-green-500/60 uppercase tracking-widest mb-4 flex items-center gap-2">
                                <Activity size={14} /> สถานะแล็บวันนี้
                            </h3>
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <span className="text-sm text-zinc-400">ติดเชื้อสะสม:</span>
                                    <span className="text-xl font-black text-green-400">{stats.infected} <span className="text-[10px] font-medium opacity-50 uppercase">Students</span></span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-sm text-zinc-400">ยารักษาในห้อง:</span>
                                    <span className="text-xl font-black text-blue-400">{stats.totalAntivirus} <span className="text-[10px] font-medium opacity-50 uppercase">Doses</span></span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-sm text-zinc-400">คำขอยารออยู่:</span>
                                    <span className="text-xl font-black text-amber-400">{stats.pendingRequests} <span className="text-[10px] font-medium opacity-50 uppercase">Pending</span></span>
                                </div>
                            </div>
                        </div>

                        <div className="bg-zinc-950 border border-green-500/20 rounded-[2rem] overflow-hidden flex flex-col min-h-[400px]">
                            <div className="bg-green-500/5 p-5 border-b border-green-500/10 flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <FlaskConical size={18} className="text-green-500" />
                                    <h3 className="font-bold text-sm text-green-500 uppercase tracking-tight">ศูนย์รับปรุงยา</h3>
                                </div>
                                {itemRequests.length > 0 && <span className="bg-amber-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-bounce">{itemRequests.length}</span>}
                            </div>
                            
                            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
                                {itemRequests.length === 0 ? (
                                    <div className="flex flex-col items-center justify-center py-10 text-center opacity-30">
                                        <Heart size={40} className="text-zinc-500 mb-2" />
                                        <p className="text-xs font-bold text-zinc-500 uppercase">ไม่มีการขอยาต้านไวรัส</p>
                                    </div>
                                ) : (
                                    itemRequests.map(req => {
                                        const std = students.find(s => s.student_id === (req.requester_id || req.student_id));
                                        return (
                                            <div key={req.id} className="bg-zinc-900/50 border border-green-500/10 rounded-2xl p-3 flex flex-col gap-3 group hover:border-green-500/30 transition">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-8 h-8 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center font-bold text-xs">
                                                        {std?.first_name?.charAt(0) || '?'}
                                                    </div>
                                                    <div className="min-w-0">
                                                        <p className="text-xs font-bold text-green-300 truncate">{std?.first_name || 'ไม่ทราบชื่อ'}</p>
                                                        <p className="text-[10px] text-zinc-500">{new Date(req.created_at).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })} น.</p>
                                                    </div>
                                                </div>
                                                <button 
                                                    onClick={() => handleApproveRequest(req)}
                                                    className="w-full bg-green-500/10 hover:bg-green-500 text-green-400 hover:text-white border border-green-500/30 rounded-xl py-2 text-[10px] font-black uppercase tracking-widest transition flex items-center justify-center gap-2"
                                                >
                                                    <Check size={14} /> อนุมัติยา
                                                </button>
                                            </div>
                                        );
                                    })
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Right: Student Grid */}
                    <div className="lg:col-span-3">
                        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                            {studentStatus.map(s => {
                            const isInfected = !!s.activeInfection;
                            
                            return (
                                <div key={s.id} className={`group relative border rounded-[2rem] p-6 overflow-hidden transition-all duration-500 ${
                                    isInfected 
                                    ? 'bg-zinc-950 border-green-500 shadow-[0_10px_40px_rgba(34,197,94,0.3)]' 
                                    : 'bg-zinc-900/40 border-zinc-800 hover:border-green-500/30 shadow-none'
                                }`}>
                                    {isInfected && (
                                        <>
                                            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(34,197,94,0.1),transparent_70%)] z-0" />
                                            <div className="absolute flex space-x-6 top-0 left-0 w-[200%] animate-[marquee_12s_linear_infinite] opacity-5 pointer-events-none select-none">
                                                {[...Array(12)].map((_, i) => <span key={i} className="text-3xl text-green-400 font-black italic tracking-tighter">BIOHAZARD FOUND</span>)}
                                            </div>
                                        </>
                                    )}
                                    
                                    <div className="relative z-10 flex items-start gap-4">
                                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl shadow-2xl transition-transform group-hover:scale-105 ${
                                            isInfected ? 'bg-green-500 text-black' : 'bg-zinc-800 text-zinc-500 border border-zinc-700'
                                        }`}>
                                            {isInfected ? <Skull size={28} className="animate-pulse" /> : s.student_id.slice(-3)}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex justify-between items-start">
                                                <h3 className={`font-black truncate text-lg tracking-tight ${isInfected ? 'text-green-400' : 'text-zinc-300'}`}>
                                                    {s.first_name}
                                                </h3>
                                                <div className="flex items-center gap-2">
                                                    {s.antivirusCount > 0 && (
                                                        <div className="flex items-center gap-1 text-blue-400 bg-blue-400/10 px-2 py-0.5 rounded-md border border-blue-400/20" title="มียาครอบครอง">
                                                            <FlaskConical size={12} />
                                                            <span className="text-[10px] font-bold">{s.antivirusCount}</span>
                                                        </div>
                                                    )}
                                                    <button 
                                                        onClick={() => handleGiftItem(s)}
                                                        title="จัดส่งยาพิเศษ"
                                                        className={`p-1.5 rounded-lg transition-colors ${isInfected ? 'text-green-500 hover:bg-green-500/20' : 'text-zinc-600 hover:bg-zinc-800 hover:text-green-500'}`}
                                                    >
                                                        <Thermometer size={16} />
                                                    </button>
                                                </div>
                                            </div>
                                            <p className={`text-xs font-bold font-mono tracking-tighter ${isInfected ? 'text-green-500/60' : 'text-zinc-600'}`}>
                                                CODEX: {s.student_id}
                                            </p>
                                            
                                            {isInfected ? (
                                                <div className="mt-4 flex gap-2">
                                                    <button 
                                                        onClick={() => handleCure(s.activeInfection.id, s.student_id)}
                                                        className="flex-1 bg-green-500 hover:bg-green-400 text-black rounded-xl text-[10px] font-black py-2.5 flex items-center justify-center gap-1.5 transition-all shadow-[0_5px_15px_rgba(34,197,94,0.3)] uppercase tracking-widest"
                                                    >
                                                        <HeartPulse size={14} /> ฉีดวัคซีน
                                                    </button>
                                                    {!s.isSubmitted && (
                                                        <button 
                                                            onClick={() => {
                                                                setSpreadModal({ show: true, sourceInfection: s.activeInfection, sourceStudent: s });
                                                                setSelectedVictims([]);
                                                            }}
                                                            className="flex-1 bg-zinc-900 hover:bg-red-500/20 text-red-500 border border-red-500/50 rounded-xl text-[10px] font-black py-2.5 flex items-center justify-center gap-1.5 transition-all uppercase tracking-widest"
                                                        >
                                                            <Skull size={14} /> ระเบิด ({s.activeInfection.spread_count})
                                                        </button>
                                                    )}
                                                </div>
                                            ) : (
                                                <div className="mt-4">
                                                    <button 
                                                        onClick={() => openInfectModal(s)}
                                                        className="w-full bg-zinc-800 hover:bg-green-500/10 text-zinc-500 hover:text-green-500 border border-zinc-700 hover:border-green-500/50 rounded-xl text-[10px] font-black py-2.5 transition-all uppercase tracking-widest"
                                                    >
                                                        ทดสอบไวรัส
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                    
                                    {isInfected && s.activeInfection && (
                                        <div className="relative z-10 mt-4 bg-black/60 rounded-2xl p-4 border border-green-500/20 text-[10px] text-green-300 font-bold space-y-2 uppercase tracking-wide">
                                            <div className="flex justify-between gap-4">
                                                <span className="opacity-40">Target Protocol:</span>
                                                <span className="text-green-400 truncate max-w-[120px]" title={assignments.find(a=>a.id === s.activeInfection.assignment_id)?.title}>
                                                    {assignments.find(a=>a.id === s.activeInfection.assignment_id)?.title || 'UNKNOWN'}
                                                </span>
                                            </div>
                                            <div className="flex justify-between items-center">
                                                <span className="opacity-40">Progression:</span>
                                                <span className={`px-2 py-0.5 rounded-full ${s.isSubmitted ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-500 animate-pulse'}`}>
                                                    {s.isSubmitted ? 'DECRYPTED' : 'ANALYZING...'}
                                                </span>
                                            </div>
                                            <div className="flex justify-between border-t border-green-500/10 pt-2">
                                                <span className="opacity-40">Penalty:</span>
                                                <span className="text-red-500">-{s.activeInfection.penalty_amount} {s.activeInfection.penalty_type}</span>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                        </div>
                    </div>
                </div>
            )}

            {/* Spread Modal */}
            {spreadModal.show && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in">
                    <div className="bg-zinc-950 w-full max-w-lg rounded-[2rem] shadow-2xl overflow-hidden border border-red-500/50 block">
                        <div className="bg-red-500/10 border-b border-red-500/20 p-6 flex items-center gap-3">
                            <div className="w-12 h-12 rounded-2xl bg-red-500/20 text-red-500 flex items-center justify-center border border-red-500/50">
                                <Skull size={24} className="animate-bounce" />
                            </div>
                            <div className="flex-1">
                                <h2 className="text-xl font-black text-red-500 tracking-wider">แพร่กระจายไวรัส!</h2>
                                <p className="text-sm text-zinc-400">จาก: {spreadModal.sourceStudent?.first_name} ({spreadModal.sourceStudent?.activeInfection?.spread_count} คน)</p>
                            </div>
                            <button onClick={() => setSpreadModal({ show: false, sourceInfection: null, sourceStudent: null })} className="text-zinc-500 hover:text-white p-2 transition">
                                <X size={24} />
                            </button>
                        </div>

                        <form onSubmit={handleSpread} className="p-6 space-y-6">
                            <p className="text-sm text-zinc-400 bg-red-500/5 p-4 rounded-2xl border border-red-500/20">
                                เลือกเพื่อนร่วมห้องที่จะติดเชื้อต่อ ไวรัสจะคงเงื่อนไขเดิม (งานเดิม/บทลงโทษเดิม) 
                                และ <span className="text-red-500 font-bold">หักแต้ม/คะแนน</span> ผู้ติดเชื้อคนเดิมทันที!
                            </p>

                            <div className="space-y-3">
                                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex justify-between">
                                    <span>เลือกเหยื่อ ({selectedVictims.length} / {spreadModal.sourceInfection?.spread_count})</span>
                                    {selectedVictims.length >= (spreadModal.sourceInfection?.spread_count || 0) && <span className="text-red-500">เต็มจำนวนแล้ว</span>}
                                </label>
                                <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                                    {students.filter(s => s.student_id !== spreadModal.sourceStudent?.student_id && !infections.some(inf => inf.student_id === s.student_id && inf.is_active)).map(s => (
                                        <div 
                                            key={s.id} 
                                            onClick={() => {
                                                if (selectedVictims.includes(s.student_id)) {
                                                    setSelectedVictims(v => v.filter(id => id !== s.student_id));
                                                } else if (selectedVictims.length < spreadModal.sourceInfection?.spread_count) {
                                                    setSelectedVictims(v => [...v, s.student_id]);
                                                }
                                            }}
                                            className={`p-3 rounded-xl border-2 text-sm cursor-pointer transition flex items-center gap-2 ${
                                                selectedVictims.includes(s.student_id) 
                                                ? 'bg-red-500/20 border-red-500 text-red-400 font-bold' 
                                                : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:border-zinc-700'
                                            }`}
                                        >
                                            <div className={`w-2 h-2 rounded-full ${selectedVictims.includes(s.student_id) ? 'bg-red-500 animate-ping' : 'bg-zinc-700'}`} />
                                            <span className="truncate">{s.first_name}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <button type="submit" disabled={selectedVictims.length === 0} 
                                className="w-full bg-red-600 text-white font-black py-4 rounded-2xl shadow-[0_10px_30px_rgba(220,38,38,0.3)] hover:bg-red-500 disabled:opacity-30 disabled:grayscale transition text-lg tracking-widest">
                                ระเบิดการแพร่เชื้อ!!!
                            </button>
                        </form>
                    </div>
                </div>
            )}

            {/* Infect Modal */}
            {infectModal.show && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
                    <div className="bg-card w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-border block">
                        <div className="bg-destructive/5 border-b border-destructive/10 p-5 flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-destructive/10 text-destructive flex items-center justify-center">
                                <Bug size={20} />
                            </div>
                            <div className="flex-1">
                                <h2 className="text-lg font-bold text-destructive">แพร่เชื้อไวรัส</h2>
                                <p className="text-sm text-muted-foreground">เป้าหมาย: {infectModal.student?.first_name} {infectModal.student?.last_name}</p>
                            </div>
                            <button onClick={() => setInfectModal({ show: false, student: null })} className="text-muted-foreground hover:bg-muted p-2 rounded-full transition">
                                <X size={20} />
                            </button>
                        </div>
                        
                        <form onSubmit={handleInfect} className="p-5 space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-1.5">เงื่อนไข (ทำงานให้เสร็จภายในวันนี้)</label>
                                <select required value={form.assignment_id} onChange={e => setForm({...form, assignment_id: e.target.value})}
                                    className="w-full bg-background border border-input rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-destructive">
                                    <option value="">-- เลือกงานมอบหมาย --</option>
                                    {assignments.map(a => <option key={a.id} value={a.id}>{a.title}</option>)}
                                </select>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium mb-1.5">รางวัลหากรอดชีวิต</label>
                                    <div className="flex items-center relative">
                                        <input type="number" min={0} required value={form.reward_amount} onChange={e => setForm({...form, reward_amount: Number(e.target.value)})}
                                            className="w-full bg-background border border-input rounded-xl pl-3 pr-[70px] py-2 text-sm focus:ring-2 focus:ring-green-500" />
                                        <select value={form.reward_type} onChange={e => setForm({...form, reward_type: e.target.value})}
                                            className="absolute right-0 bg-muted border-l border-input rounded-r-xl px-2 py-2 text-sm focus:outline-none focus:ring-0 appearance-none h-full outline-none">
                                            <option value="points">แต้ม</option>
                                            <option value="score">คะแนน</option>
                                        </select>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1.5">บทลงโทษหากไม่รอด</label>
                                    <div className="flex items-center relative">
                                        <input type="number" min={1} required value={form.penalty_amount} onChange={e => setForm({...form, penalty_amount: Number(e.target.value)})}
                                            className="w-full bg-background border border-input rounded-xl pl-3 pr-[70px] py-2 text-sm focus:ring-2 focus:ring-destructive" />
                                        <select value={form.penalty_type} onChange={e => setForm({...form, penalty_type: e.target.value})}
                                            className="absolute right-0 bg-muted border-l border-input rounded-r-xl px-2 py-2 text-sm focus:outline-none focus:ring-0 appearance-none h-full outline-none">
                                            <option value="points">แต้ม</option>
                                            <option value="score">คะแนน</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium mb-1.5">อัตราการแพร่กระจาย</label>
                                <div className="flex items-center relative">
                                    <input type="number" min={0} required value={form.spread_count} onChange={e => setForm({...form, spread_count: Number(e.target.value)})}
                                        className="w-full bg-background border border-input rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-destructive pr-8" />
                                    <span className="absolute right-3 text-sm text-muted-foreground">คน</span>
                                </div>
                            </div>
                            
                            <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl flex gap-3 text-amber-800 text-sm mt-2">
                                <ShieldAlert size={20} className="flex-shrink-0 text-amber-600" />
                                <p>หากนักเรียนส่งงานนี้ไม่สำเร็จภายในวันนี้ ไวรัสจะแพร่และนักเรียนจะถูกลงโทษ</p>
                            </div>

                            <button type="submit" className="w-full bg-destructive text-destructive-foreground font-bold rounded-xl py-3 mt-4 hover:bg-destructive/90 transition shadow-[0_4px_15px_rgba(239,68,68,0.3)]">
                                เริ่มการแพร่เชื้อ!
                            </button>
                        </form>
                    </div>
                </div>
            )}
            
            <style dangerouslySetInnerHTML={{ __html: `
                @keyframes marquee {
                    0% { transform: translateX(0); }
                    100% { transform: translateX(-50%); }
                }
                .custom-scrollbar::-webkit-scrollbar {
                    width: 4px;
                }
                .custom-scrollbar::-webkit-scrollbar-thumb {
                    background: #333;
                    border-radius: 10px;
                }
            `}} />
        </div>
    );
}
