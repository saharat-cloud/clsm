import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const MySwal = withReactContent(Swal);

export const alerts = {
    // Cute success alert
    success: (title, text = '') => {
        return MySwal.fire({
            icon: 'success',
            title: title,
            text: text,
            confirmButtonText: 'ตกลง',
            confirmButtonColor: '#10b981', // Emerald 500
            customClass: {
                popup: 'rounded-2xl',
                confirmButton: 'rounded-xl px-4 py-2 font-medium',
            }
        });
    },

    // Cute error alert
    error: (title, text = '') => {
        return MySwal.fire({
            icon: 'error',
            title: title,
            text: text,
            confirmButtonText: 'ตกลง',
            confirmButtonColor: '#ef4444', // Red 500
            customClass: {
                popup: 'rounded-2xl',
                confirmButton: 'rounded-xl px-4 py-2 font-medium',
            }
        });
    },

    // Cute info alert (replaces window.alert)
    info: (title, text = '') => {
        return MySwal.fire({
            icon: 'info',
            title: title,
            text: text,
            confirmButtonText: 'ตกลง',
            confirmButtonColor: '#3b82f6', // Blue 500
            customClass: {
                popup: 'rounded-2xl',
                confirmButton: 'rounded-xl px-4 py-2 font-medium',
            }
        });
    },

    // Cute confirm dialog (replaces window.confirm)
    // Returns true if confirmed, false otherwise
    confirm: async (title, text = '') => {
        const result = await MySwal.fire({
            title: title,
            text: text,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#f59e0b', // Amber 500
            cancelButtonColor: '#94a3b8', // Slate 400
            confirmButtonText: 'ยืนยัน',
            cancelButtonText: 'ยกเลิก',
            reverseButtons: true,
            customClass: {
                popup: 'rounded-3xl shadow-2xl',
                confirmButton: 'rounded-xl px-5 py-2.5 font-bold shadow-md hover:opacity-90 transition',
                cancelButton: 'rounded-xl px-5 py-2.5 font-medium hover:opacity-90 transition',
                title: 'text-xl',
            }
        });
        return result.isConfirmed;
    },
    
    // Danger confirm dialog (for deletions)
    confirmDanger: async (title, text = "การกระทำนี้ไม่สามารถย้อนกลับได้!") => {
        const result = await MySwal.fire({
            title: title,
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444', // Red 500
            cancelButtonColor: '#94a3b8', // Slate 400
            confirmButtonText: 'ใช่, ฉันแน่ใจ!',
            cancelButtonText: 'ยกเลิก',
            reverseButtons: true,
            customClass: {
                popup: 'rounded-3xl shadow-2xl border-2 border-red-100',
                confirmButton: 'rounded-xl px-5 py-2.5 font-bold shadow-md hover:bg-red-600 transition',
                cancelButton: 'rounded-xl px-5 py-2.5 font-medium hover:opacity-90 transition',
            }
        });
        return result.isConfirmed;
    },

    // Cute prompt dialog (replaces window.prompt)
    prompt: async (title, label = '', placeholder = '') => {
        const { value } = await MySwal.fire({
            title: title,
            input: 'text',
            inputLabel: label,
            inputPlaceholder: placeholder,
            showCancelButton: true,
            confirmButtonColor: '#3b82f6', // Blue 500
            cancelButtonColor: '#94a3b8', // Slate 400
            confirmButtonText: 'ตกลง',
            cancelButtonText: 'ยกเลิก',
            reverseButtons: true,
            customClass: {
                popup: 'rounded-3xl shadow-2xl',
                confirmButton: 'rounded-xl px-5 py-2.5 font-bold shadow-md hover:opacity-90 transition',
                cancelButton: 'rounded-xl px-5 py-2.5 font-medium hover:opacity-90 transition',
                input: 'rounded-xl border-border focus:ring-primary',
                title: 'text-xl',
            }
        });
        return value || null; // Return null if cancelled or empty
    }
};
