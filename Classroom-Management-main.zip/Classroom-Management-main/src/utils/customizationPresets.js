/**
 * Profile Customization Presets
 * Shared between Teacher Profile and Reward Management
 */

export const GRADIENT_PRESETS = [
    // Vibrant Series
    { name: 'Sunset Glow', value: 'linear-gradient(to right, #ff5f6d, #ffc371)' },
    { name: 'Ocean Breeze', value: 'linear-gradient(to right, #2193b0, #6dd5ed)' },
    { name: 'Forest Fresh', value: 'linear-gradient(to right, #56ab2f, #a8e063)' },
    { name: 'Berry Bliss', value: 'linear-gradient(to right, #cc2b5e, #753a88)' },
    { name: 'Rose Petal', value: 'linear-gradient(to right, #ee9ca7, #ffdde1)' },
    { name: 'Lime Zest', value: 'linear-gradient(to right, #9bff33, #33ff9b)' },
    { name: 'Space Neon', value: 'linear-gradient(to right, #833ab4, #fd1d1d, #fcb045)' },
    { name: 'Synthwave', value: 'linear-gradient(to right, #ff00cc, #3333ff)' },
    { name: 'Mango Tango', value: 'linear-gradient(to right, #ff8c00, #ff0080)' },
    { name: 'Cyber Lime', value: 'linear-gradient(to right, #00ff00, #00ffff)' },
    { name: 'Ultra Ultraviolet', value: 'linear-gradient(to right, #654ea3, #eaafc8)' },
    
    // Dark Series
    { name: 'Midnight City', value: 'linear-gradient(to bottom, #232526, #414345)' },
    { name: 'Obsidian Glow', value: 'linear-gradient(to bottom, #000000, #434343)' },
    { name: 'Deep Emerald', value: 'linear-gradient(to right, #051937, #004d7a, #008793, #00bf72, #a8eb12)' },
    { name: 'Dark Phoenix', value: 'linear-gradient(to right, #1e1e1e, #8e0e00)' },
    { name: 'Vampire Byte', value: 'linear-gradient(to right, #0f0c29, #302b63, #24243e)' },
    { name: 'Deep Sea', value: 'linear-gradient(to right, #000428, #004e92)' },
    { name: 'Royal Purple', value: 'linear-gradient(to right, #42275a, #734b6d)' },

    // Pastel/Soft Series
    { name: 'Cotton Candy', value: 'linear-gradient(to right, #ff9a9e, #fecfef)' },
    { name: 'Mint Sorbet', value: 'linear-gradient(to top, #96fbc4 0%, #f9f586 100%)' },
    { name: 'Sky Dreams', value: 'linear-gradient(to top, #a18cd1 0%, #fbc2eb 100%)' },
    { name: 'Peach Tea', value: 'linear-gradient(120deg, #f6d365 0%, #fda085 100%)' },
    { name: 'Lavender Mist', value: 'linear-gradient(to right, #eecda3, #ef629f)' },
    { name: 'Cloud Nine', value: 'linear-gradient(to top, #cfd9df 0%, #e2ebf0 100%)' },
    { name: 'Aqua Cyan', value: 'linear-gradient(to right, #b2fefa, #0ed2f7)' },

    // Premium Series
    { name: 'Pure Gold', value: 'linear-gradient(to right, #bf953f, #fcf6ba, #b38728, #fbf5b7, #aa771c)' },
    { name: 'Silver Silk', value: 'linear-gradient(to right, #bdc3c7, #2c3e50)' },
    { name: 'Champagne', value: 'linear-gradient(to right, #f7e7bd, #e7c062)' },
    { name: 'Diamond Shine', value: 'linear-gradient(to right, #e6e9f0 0%, #eef1f5 100%)' },
    { name: 'Twilight Ember', value: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }
];

export const ANIMATION_PRESETS = [
    { id: 'glow-gold', name: 'Golden Glow', icon: '✨' },
    { id: 'rainbow-spin', name: 'Rainbow Spin', icon: '🌈' },
    { id: 'fire', name: 'Fire Spirit', icon: '🔥' },
    { id: 'stars', name: 'Diamond Shine', icon: '💎' },
    { id: 'cyberpunk', name: 'Cyberpunk Neon', icon: '⚡' },
    { id: 'void-pulse', name: 'Void Pulse', icon: '🌌' },
    { id: 'emerald-glow', name: 'Emerald Glow', icon: '🌿' },
    { id: 'ice-crystal', name: 'Ice Crystal', icon: '❄️' },
    { id: 'neon-wave', name: 'Neon Wave', icon: '🌊' },
    { id: 'lightning-bolt', name: 'Lightning Bolt', icon: '⚡' },
    { id: 'gold-royal', name: 'Gold Royal', icon: '👑' },
    { id: 'ruby-flare', name: 'Ruby Flare', icon: '🔻' },
    { id: 'phantom-fade', name: 'Phantom Fade', icon: '👻' },
    { id: 'cyber-orange', name: 'Cyber Orange', icon: '🔸' },
    { id: 'magic-pink', name: 'Magic Pink', icon: '💖' }
];

export const getAnimationLabel = (id) => {
    const p = ANIMATION_PRESETS.find(a => a.id === id);
    return p ? p.name : id;
};
