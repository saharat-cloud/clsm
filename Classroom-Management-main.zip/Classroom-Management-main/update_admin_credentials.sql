-- Update admin credentials
UPDATE teachers 
SET username = 'admin', 
    password = 'adminadmin3939' 
WHERE username = 'kanit' OR role = 'admin';
