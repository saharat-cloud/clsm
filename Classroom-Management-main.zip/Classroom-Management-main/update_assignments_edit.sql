-- SQL Script to update Classroom Management schema for Assignment Edit Requests

-- Add edit_request_status to submissions to track edit approvals
ALTER TABLE public.submissions 
ADD COLUMN IF NOT EXISTS edit_request_status TEXT; -- 'pending', 'approved', 'rejected', or null

-- To apply this update, copy and paste this script into the Supabase SQL Editor and run it.
