-- SQL Script to update Classroom Management schema

-- 1. Create or ensure rewards and reward_claims exist (in case setup_rewards.sql wasn't run)
CREATE TABLE IF NOT EXISTS public.rewards (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    classroom_id UUID REFERENCES public.classrooms(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    points_required INTEGER NOT NULL DEFAULT 0,
    stock INTEGER NOT NULL DEFAULT 0,
    image_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
DROP POLICY IF EXISTS "Allow public access to rewards" ON public.rewards;
CREATE POLICY "Allow public access to rewards" ON public.rewards FOR ALL USING (true);

CREATE TABLE IF NOT EXISTS public.reward_claims (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    student_id TEXT NOT NULL,
    reward_id UUID REFERENCES public.rewards(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
ALTER TABLE public.reward_claims ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow public access to reward_claims" ON public.reward_claims;
CREATE POLICY "Allow public access to reward_claims" ON public.reward_claims FOR ALL USING (true);

-- 2. Add new columns for the reward updates
ALTER TABLE public.rewards 
ADD COLUMN IF NOT EXISTS reward_type TEXT DEFAULT 'item';

-- 3. Add column for archiving classrooms (Next Semester Feature)
ALTER TABLE public.classrooms 
ADD COLUMN IF NOT EXISTS is_archived BOOLEAN DEFAULT false;

-- 4. Add archiving to Students and Subjects to support complete semester hiding
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS is_archived BOOLEAN DEFAULT false;
ALTER TABLE public.subjects ADD COLUMN IF NOT EXISTS is_archived BOOLEAN DEFAULT false;

-- 5. Create storage bucket and allow public access
INSERT INTO storage.buckets (id, name, public) 
VALUES ('rewards', 'rewards', true) 
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "Public access to rewards bucket" ON storage.objects;
CREATE POLICY "Public access to rewards bucket" ON storage.objects FOR SELECT TO public USING ( bucket_id = 'rewards' );

DROP POLICY IF EXISTS "Allow generic uploads to rewards bucket" ON storage.objects;
CREATE POLICY "Allow generic uploads to rewards bucket" ON storage.objects FOR INSERT TO public WITH CHECK ( bucket_id = 'rewards' );

DROP POLICY IF EXISTS "Allow updates to rewards bucket" ON storage.objects;
CREATE POLICY "Allow updates to rewards bucket" ON storage.objects FOR UPDATE TO public WITH CHECK ( bucket_id = 'rewards' );

DROP POLICY IF EXISTS "Allow deletes to rewards bucket" ON storage.objects;
CREATE POLICY "Allow deletes to rewards bucket" ON storage.objects FOR DELETE TO public USING ( bucket_id = 'rewards' );

-- IMPORTANT: Please COPY this ENTIRE script again and run it in the Supabase SQL Editor to apply these missing fixes!
