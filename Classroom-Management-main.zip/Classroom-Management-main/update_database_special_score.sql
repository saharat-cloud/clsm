-- SQL Script to update Classroom Management schema for Special Scores (คะแนนพิเศษ) & Real-time Notifications

-- 1. Add score_amount column to rewards table to store how much score a "points" reward gives
ALTER TABLE public.rewards 
ADD COLUMN IF NOT EXISTS score_amount INTEGER DEFAULT 1;

-- 2. Enable Realtime for the reward_claims table so students get notified
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND schemaname = 'public' 
        AND tablename = 'reward_claims'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.reward_claims;
    END IF;
END $$;

-- 3. Add extra_score_types column to classrooms to store custom score columns
ALTER TABLE public.classrooms 
ADD COLUMN IF NOT EXISTS extra_score_types JSONB DEFAULT '[]'::jsonb;

-- To apply this update, copy and paste this script into the Supabase SQL Editor and run it.
